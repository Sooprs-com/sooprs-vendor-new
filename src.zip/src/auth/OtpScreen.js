import {
  Image,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  ScrollView,
  Platform,
} from 'react-native';
import React, {useState, useRef, useEffect} from 'react';
import Colors from '../assets/commonCSS/Colors';
import CustomHeader from '../components/CustomHeader';
import Images from '../assets/image';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import Toast from 'react-native-toast-message';
import {useNavigation, useRoute} from '@react-navigation/native';

const OtpScreen = () => {
  const [otp, setOtp] = useState(['', '', '', '']);
  const [timer, setTimer] = useState(30);
  const [canResend, setCanResend] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const inputRefs = useRef([]);
  const route = useRoute();
  const navigation = useNavigation();
  const {profileType, email} = route?.params;

  const showAlert = (type, text1, text2) => {
    Toast.show({
      type: type,
      text1: text1,
      text2: text2,
      position: 'top',
    });
  };

  useEffect(() => {
    handleResend();
  }, []);

  useEffect(() => {
    if (timer > 0) {
      const interval = setInterval(() => {
        setTimer(prevTimer => prevTimer - 1);
      }, 1000);

      return () => clearInterval(interval);
    } else {
      setCanResend(true);
    }
  }, [timer]);

  const handleOtpChange = (value, index) => {
    if (/^\d?$/.test(value)) {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);

      if (value && index < otp.length - 1) {
        inputRefs.current[index + 1].focus();
      }
    }
  };

  const handleKeyPress = (key, index) => {
    if (key === 'Backspace' && index > 0 && !otp[index]) {
      inputRefs.current[index - 1].focus();
    }
  };

  const handleResend = async () => {
    if (canResend) {
      setIsResending(true);
      setTimer(30);
      setCanResend(false);
      try {
        const formData = new FormData();
        formData.append('email', email);
        const response = await fetch(
          'https://sooprs.com/api2/public/index.php/resendOtp',
          {
            method: 'POST',
            body: formData,
          },
        );
        const result = await response.json();
        if (response.ok) {
          if (result.status == 400) {
            showAlert('error', 'Error', result?.msg);
            return;
          }
          showAlert('success', 'Success', result?.msg);
        } else {
          showAlert('error', 'Error', result?.msg);
        }
      } catch (error) {
        showAlert('error', 'Error', error);
        console.error(error);
      } finally {
        setIsResending(false);
      }
    }
  };

  const handleVerifyOtp = async () => {
    if (otp.includes('')) {
      Alert.alert('Error', 'Please fill all the OTP fields.');
    } else {
      setIsVerifying(true);
      const otpString = otp.join('');
      try {
        const formData = new FormData();
        formData.append('email', email);
        formData.append('otp', otpString);
        const response = await fetch(
          'https://sooprs.com/api2/public/index.php/verifyOtp',
          {
            method: 'POST',
            body: formData,
          },
        );
        const result = await response.json();
        if (response.ok) {
          if (result.status == 400) {
            showAlert('error', 'Error', result?.msg);
            return;
          }
          showAlert('success', 'Success', result?.msg);
          navigation.navigate('Login', {profileType: profileType});
        } else {
          showAlert('error', 'Error', result?.msg);
        }
      } catch (error) {
        Alert.alert('Error', 'An error occurred while verifying OTP.');
        console.error(error);
      } finally {
        setIsVerifying(false);
      }
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <CustomHeader backButton imageTitle />
      <KeyboardAvoidingView behavior={'padding'} style={{flex: 1}}>
        <ScrollView contentContainerStyle={{flexGrow: 1}}>
          <View>
            <Text style={styles.title}>Enter OTP</Text>
            <Image
              source={Images.otpBackground}
              style={{height: hp(35), width: wp(90), alignSelf: 'center'}}
              resizeMode="contain"
            />
          </View>
          <View style={styles.otpContainer}>
            <View style={styles.otpBoxesContainer}>
              {otp.map((digit, index) => (
                <TextInput
                  key={index}
                  ref={ref => (inputRefs.current[index] = ref)}
                  style={styles.otpBox}
                  value={digit}
                  cursorColor={Colors.black}
                  onChangeText={value => handleOtpChange(value, index)}
                  onKeyPress={({nativeEvent}) =>
                    handleKeyPress(nativeEvent.key, index)
                  }
                  keyboardType="numeric"
                  maxLength={1}
                  textAlign="center"
                />
              ))}
            </View>

            <TouchableOpacity
              style={styles.verifyButton}
              onPress={handleVerifyOtp}
              disabled={isVerifying}>
              {isVerifying ? (
                <ActivityIndicator color={Colors.white} />
              ) : (
                <Text style={styles.verifyText}>Verify OTP</Text>
              )}
            </TouchableOpacity>

            <Text style={styles.resendText} onPress={() => handleResend()}>
              {isResending ? (
                <ActivityIndicator color={Colors.sooprsblue} />
              ) : canResend ? (
                'Resend OTP'
              ) : (
                `Resend in ${timer}s`
              )}
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

export default OtpScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  otpContainer: {
    marginTop: hp(5),
    alignItems: 'center',
  },
  title: {
    fontSize: 20,
    color: Colors.black,
    textAlign: 'center',
    marginVertical: hp(3),
    fontWeight: '500',
  },
  otpBoxesContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: wp(60),
    marginVertical: hp(2),
  },
  otpBox: {
    borderWidth: 1,
    borderColor: Colors.grey,
    borderRadius: 5,
    width: wp(12),
    height: hp(6),
    fontSize: 18,
    color: Colors.black,
  },
  verifyButton: {
    marginTop: hp(2),
    paddingVertical: hp(1),
    paddingHorizontal: wp(5),
    backgroundColor: Colors.sooprsblue,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  verifyText: {
    color: Colors.white,
    fontSize: 16,
  },
  resendText: {
    color: Colors.sooprsblue,
    fontSize: 16,
    textDecorationLine: 'underline',
    marginVertical: 8,
    alignSelf: 'center',
  },
});
