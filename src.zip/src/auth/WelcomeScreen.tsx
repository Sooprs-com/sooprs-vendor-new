import React, { useEffect, useRef, useState } from 'react';
import {
  StyleSheet,
  View,
  StatusBar,
  ActivityIndicator,
  Text,
  Image,
  TouchableOpacity,
  Animated,
} from 'react-native';
import Video from 'react-native-video';
import LinearGradient from 'react-native-linear-gradient';
import Images from '../assets/image';
import { hp, wp } from '../assets/commonCSS/GlobalCSS';
import Colors from '../assets/commonCSS/Colors';
import FSize from '../assets/commonCSS/FSize';

const WelcomeScreen = ({ navigation }: { navigation: any }) => {
  const [videoLoaded, setVideoLoaded] = useState(false);
  const [hasNavigated, setHasNavigated] = useState(false);
  const videoRef = useRef<any>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  // Animated values for 3 dots
  const dot1Opacity = useRef(new Animated.Value(0.3)).current;
  const dot2Opacity = useRef(new Animated.Value(0.3)).current;
  const dot3Opacity = useRef(new Animated.Value(0.3)).current;

  const navigateToProfileSelection = () => {
    if (!hasNavigated) {
      setHasNavigated(true);
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
      navigation.navigate('EnterMobileNumber');
    }
  };

  useEffect(() => {
    // Navigate to ProfileSelection after 5 seconds (fallback)
    timerRef.current = setTimeout(() => {
      navigateToProfileSelection();
    }, 100000);

    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [navigation]);

  // Animate dots in sequence: dot1 -> dot2 -> dot3 -> repeat
  useEffect(() => {
    const animateDots = () => {
      // Reset all to low opacity
      Animated.parallel([
        Animated.timing(dot1Opacity, {
          toValue: 0.3,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(dot2Opacity, {
          toValue: 0.3,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(dot3Opacity, {
          toValue: 0.3,
          duration: 200,
          useNativeDriver: true,
        }),
      ]).start(() => {
        // Animate dot 1
        Animated.timing(dot1Opacity, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }).start(() => {
          // Animate dot 2
          Animated.timing(dot2Opacity, {
            toValue: 1,
            duration: 300,
            useNativeDriver: true,
          }).start(() => {
            // Animate dot 3
            Animated.timing(dot3Opacity, {
              toValue: 1,
              duration: 300,
              useNativeDriver: true,
            }).start(() => {
              // Reset and repeat
              setTimeout(() => {
                animateDots();
              }, 300);
            });
          });
        });
      });
    };

    animateDots();
  }, [dot1Opacity, dot2Opacity, dot3Opacity]);

  const handleVideoEnd = () => {
    // Navigate when video ends
    navigateToProfileSelection();
  };

  const handleVideoLoad = () => {
    setVideoLoaded(true);
  };

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor={Colors.sooprsblue} />
      <View style={styles.container}>
        {!videoLoaded && (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={Colors.white} />
          </View>
        )}
        <Video
          ref={videoRef}
          source={require('../assets/images/e4a79f19-665e-4078-a2db-1214a20e0096.mp4')}
          style={styles.video}
          resizeMode="cover"
          onEnd={handleVideoEnd}
          onLoad={handleVideoLoad}
          repeat={false}
          paused={false}
          muted={false}
          rate={2.0}
        />
        
        {/* Gradient Shadow Background */}
        <LinearGradient
          colors={['transparent', 'rgba(0,0,0,0.5)', 'rgba(0,0,0,0.8)', 'rgba(0,0,0,0.95)']}
          style={styles.gradientOverlay}
        />
        
        {/* Bottom Overlay Design */}
        <View style={styles.bottomOverlay}>
          {/* <View style={styles.logoContainer}>
            <Image source={Images.Sooprslogo} style={styles.logo} />
          </View>
          <Text style={styles.tagline}>
            Your Best & Trusted Service Marketplace
          </Text> */}
          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={styles.getStartedButton}
              onPress={navigateToProfileSelection}
              activeOpacity={0.8}>
              <View style={styles.buttonTextContainer}>
                <Text style={styles.getStartedText}>Getting Started</Text>
                <View style={styles.dotsContainer}>
                  <Animated.Text style={[styles.dot, { opacity: dot1Opacity }]}>.</Animated.Text>
                  <Animated.Text style={[styles.dot, { opacity: dot2Opacity }]}>.</Animated.Text>
                  <Animated.Text style={[styles.dot, { opacity: dot3Opacity }]}>.</Animated.Text>
                </View>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </>
  );
};

export default WelcomeScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.sooprsblue,
  },
  video: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  loadingContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.sooprsblue,
    zIndex: 1,
  },
  gradientOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: hp(40),
    zIndex: 1,
  },
  bottomOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingBottom: hp(6),
    paddingHorizontal: wp(6),
    alignItems: 'center',
    zIndex: 2,
  },
  logoContainer: {
    marginBottom: hp(2),
    alignItems: 'center',
  },
  logo: {
    width: wp(50),
    height: hp(12),
    resizeMode: 'contain',
  },
  tagline: {
    fontSize: FSize.fs16,
    color: Colors.white,
    textAlign: 'center',
    marginBottom: hp(3),
    fontWeight: '400',
    paddingHorizontal: wp(10),
    lineHeight: hp(2.5),
  },
  buttonContainer: {
    width: '100%',
    paddingHorizontal: wp(4),
  },
  getStartedButton: {
    width: '100%',
    backgroundColor: Colors.sooprsblue,
    paddingVertical: hp(1),
    borderRadius: wp(3),
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  getStartedText: {
    color: Colors.white,
    fontSize: FSize.fs18,
    fontWeight: '600',
  },
  buttonTextContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  dotsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: wp(1),
  },
  dot: {
    color: Colors.white,
    fontSize: FSize.fs24,
    fontWeight: 'bold',
    marginHorizontal: wp(0.5),
  },
});

