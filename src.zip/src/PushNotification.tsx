import AsyncStorage from '@react-native-async-storage/async-storage';
import messaging from '@react-native-firebase/messaging';
import { PermissionsAndroid, Platform } from 'react-native';
import { mobile_siteConfig } from './services/mobile-siteConfig';
// import { mobile_siteConfig } from './Services/mobile-siteConfig';


export async function requestUserPermissionPushNotification() {

    if (Platform.OS === 'android' && Platform.Version >= 33) {
        const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS);
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
            getFCMToken();
            return
        } else {
            console.log('Permission denied by user.');
            return
        }
    } else {
        const authStatus = await messaging().requestPermission();
        const enabled =
            authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
            authStatus === messaging.AuthorizationStatus.PROVISIONAL;

        if (enabled) {
            console.log('Authorization status:', authStatus);
            getFCMToken();
        }
    }
}

// Get FCM Token
const getFCMToken = async () => {
    try {
        await messaging().registerDeviceForRemoteMessages();

        let fcmToken = await AsyncStorage.getItem(mobile_siteConfig.FCM_TOKEN)
        if (!!fcmToken) {
            console.log("OLD FCM_TOKEN FOUND", fcmToken)
        } else {
            const token = await messaging().getToken();
            await AsyncStorage.setItem(mobile_siteConfig.FCM_TOKEN, token)
            console.log("NEW FCM_TOKEN", token)
        }
    } catch (error) {
        console.log("error during generating token", error)
    }
}