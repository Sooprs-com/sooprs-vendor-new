import { Dimensions } from "react-native";

export const DeviceHeight=Dimensions.get('window').height;
export const DeviceWidth=Dimensions.get('window').width;