import {configureStore} from '@reduxjs/toolkit';
import {
  FLUSH,
  PAUSE,
  PERSIST,
  persistReducer,
  persistStore,
  PURGE,
  REGISTER,
  REHYDRATE,
} from 'redux-persist';
import mmkvStorage from './Engine';
import Reducers from './Reducers';
const config = {
  key: 'root',
  storage: mmkvStorage,
};

const persistReduce = persistReducer(config, Reducers);

const store = configureStore({
  reducer: persistReduce,
  middleware: getDefaultMiddleware =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
      },
    }),
});
const persistor = persistStore(store);
export {store, persistor};
