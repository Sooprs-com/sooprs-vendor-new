import types from './Constants';
export const setUserDetails = data => {
  return {
    type: types.USER_DETAILS,
    payload: data,
  };
};
export const setIsProfessional = data => {
  return {
    type: types.IS_PROFESSIONAL,
    payload: data,
  };
};
export const setUserId = data => {
  return {
    type: types.USERID,
    payload: data,
  };
};
export const setProjectFilter = data => {
  return {
    type: types.PROJECT_FILTER,
    payload: data,
  };
};
export const setFcmToken = data => {
  return {
    type: types.FCM_TOKEN,
    payload: data,
  };
};
export const setLoginTimeStamp = data => {
  return {
    type: types.LOGIN_TIMESTAMP,
    payload: data,
  };
};

export const setAuthToken = data => {
  return {
    type: types.TOKEN,
    payload: data,
  };
};
//  URBAN CLAP Actions
export const setUserAddress = data => {
  return {
    type: types.USER_ADDRESS,
    payload: data,
  };
};
export const setRecentAddresses = data => {
  return {
    type: types.RECENT_ADDRESSES,
    payload: data,
  };
};
