import {AndroidCategory} from '@notifee/react-native';
import types from './Constants';

const initialState = {
  getUserDetails: {},
  getIfProfessional: 0,
  getUserId: '',
  getProjectFilters: {},
  getFcmToken: '',
  getLoginTimeStamp: '',
  getUserAddress: '',
  getRecentAddress: [],
  getAuthToken: '',
};

const Reducers = (state = initialState, action) => {
  switch (action.type) {
    case types.USER_DETAILS:
      return {
        ...state,
        getUserDetails: action.payload,
      };
    case types.IS_PROFESSIONAL:
      return {
        ...state,
        getIfProfessional: action.payload,
      };
    case types.USERID:
      return {
        ...state,
        getUserId: action.payload,
      };
    case types.PROJECT_FILTER:
      return {
        ...state,
        getProjectFilters: action.payload,
      };
    case types.FCM_TOKEN:
      return {
        ...state,
        getFcmToken: action.payload,
      };
    case types.LOGIN_TIMESTAMP:
      return {
        ...state,
        getLoginTimeStamp: action.payload,
      };
    case types.TOKEN:
      return {
        ...state,
        getAuthToken: action.payload,
      };
    // UC Reducers
    case types.USER_ADDRESS:
      return {
        ...state,
        getUserAddress: action.payload,
      };
    case types.RECENT_ADDRESSES:
      return {
        ...state,
        getRecentAddress: action.payload,
      };
    default:
      return state;
  }
};

export default Reducers;
