import React from 'react';
import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { useNotification } from '../contexts/NotificationContext';

// Example component showing different notification types
const NotificationExamples: React.FC = () => {
  const { showNotification } = useNotification();

  const showSimpleNotification = () => {
    showNotification({
      id: 'simple-1',
      title: 'Simple Notification',
      body: 'This is a basic notification with default OK/Cancel buttons.',
    });
  };

  const showCustomButtonNotification = () => {
    showNotification({
      id: 'custom-1',
      title: 'New Message',
      body: 'You have received a new message from John.',
      actionButtons: {
        okText: 'View Message',
        cancelText: 'Later',
        showCancel: true,
      },
    });
  };

  const showSingleButtonNotification = () => {
    showNotification({
      id: 'single-1',
      title: 'Update Available',
      body: 'A new app update is available. Please update to get latest features.',
      actionButtons: {
        okText: 'Update Now',
        showCancel: false,
      },
    });
  };

  const showImportantNotification = () => {
    showNotification({
      id: 'important-1',
      title: 'Important Alert',
      body: 'Your account security needs attention. Please verify your identity.',
      priority: 'high',
      actionButtons: {
        okText: 'Verify Now',
        cancelText: 'Remind Later',
        showCancel: true,
      },
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Notification Examples</Text>
      
      <TouchableOpacity style={styles.button} onPress={showSimpleNotification}>
        <Text style={styles.buttonText}>Show Simple Notification</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.button} onPress={showCustomButtonNotification}>
        <Text style={styles.buttonText}>Show Custom Buttons</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.button} onPress={showSingleButtonNotification}>
        <Text style={styles.buttonText}>Show Single Button</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.button} onPress={showImportantNotification}>
        <Text style={styles.buttonText}>Show Important Alert</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 30,
  },
  button: {
    backgroundColor: '#007AFF',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default NotificationExamples;
