import React, {useEffect, useRef} from 'react';
import {
  View,
  Text,
  Modal,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  StatusBar,
  Animated,
  Easing,
} from 'react-native';
import { useNotification } from '../contexts/NotificationContext';

const { width, height } = Dimensions.get('window');
const AnimatedTouchableOpacity = Animated.createAnimatedComponent(TouchableOpacity);
const AnimatedText = Animated.createAnimatedComponent(Text);

const CustomNotificationAlert: React.FC = () => {
  const { notification, handleNotificationOk, handleNotificationCancel } = useNotification();
  const rejectAnim = useRef(new Animated.Value(0)).current;
  const acceptAnim = useRef(new Animated.Value(0)).current;
  const heroPulse = useRef(new Animated.Value(0)).current;
  const rejectLoopRef = useRef<Animated.CompositeAnimation | null>(null);
  const acceptLoopRef = useRef<Animated.CompositeAnimation | null>(null);
  const heroLoopRef = useRef<Animated.CompositeAnimation | null>(null);

  const startLoop = (
    value: Animated.Value,
    loopRef: React.MutableRefObject<Animated.CompositeAnimation | null>,
  ) => {
    loopRef.current = Animated.loop(
      Animated.sequence([
        Animated.timing(value, {
          toValue: 1,
          duration: 220,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(value, {
          toValue: -1,
          duration: 220,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(value, {
          toValue: 0,
          duration: 220,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ]),
    );

    loopRef.current.start();
  };

  const stopLoop = (
    loopRef: React.MutableRefObject<Animated.CompositeAnimation | null>,
    value: Animated.Value,
  ) => {
    if (loopRef.current) {
      loopRef.current.stop();
      loopRef.current = null;
    }

    value.stopAnimation();
    value.setValue(0);
  };

  useEffect(() => {
    if (notification) {
      startLoop(rejectAnim, rejectLoopRef);
      startLoop(acceptAnim, acceptLoopRef);
      heroLoopRef.current = Animated.loop(
        Animated.sequence([
          Animated.timing(heroPulse, {
            toValue: 1,
            duration: 900,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
          Animated.timing(heroPulse, {
            toValue: 0,
            duration: 900,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
        ]),
      );
      heroLoopRef.current.start();
    } else {
      stopLoop(rejectLoopRef, rejectAnim);
      stopLoop(acceptLoopRef, acceptAnim);
      if (heroLoopRef.current) {
        heroLoopRef.current.stop();
        heroLoopRef.current = null;
      }
      heroPulse.stopAnimation();
      heroPulse.setValue(0);
    }

    return () => {
      stopLoop(rejectLoopRef, rejectAnim);
      stopLoop(acceptLoopRef, acceptAnim);
      if (heroLoopRef.current) {
        heroLoopRef.current.stop();
        heroLoopRef.current = null;
      }
      heroPulse.stopAnimation();
      heroPulse.setValue(0);
    };
  }, [notification, rejectAnim, acceptAnim, heroPulse]);

  const getWiggleStyle = (value: Animated.Value, intensity = 1) => ({
    transform: [
      {
        translateY: value.interpolate({
          inputRange: [-1, 0, 1],
          outputRange: [-3 * intensity, 0, 3 * intensity],
        }),
      },
      {
        scale: value.interpolate({
          inputRange: [-1, 0, 1],
          outputRange: [1 - 0.02 * intensity, 1, 1 - 0.02 * intensity],
        }),
      },
    ],
  });

  if (!notification) {
    return null;
  }

  const heroAnimatedStyle = {
    transform: [
      {
        translateY: heroPulse.interpolate({
          inputRange: [0, 1],
          outputRange: [0, -6],
        }),
      },
    ],
    opacity: heroPulse.interpolate({
      inputRange: [0, 1],
      outputRange: [1, 0.85],
    }),
  };

  return (
    <Modal
      visible={!!notification}
      transparent={true}
      animationType="fade"
      statusBarTranslucent={true}
    >
      <StatusBar backgroundColor="rgba(0,0,0,0.5)" barStyle="light-content" />
      <View style={styles.overlay}>
        <View style={styles.alertContainer}>
          <View style={styles.topAccent} />

          {/* Animated New Lead Banner */}
          <View style={styles.leadHeroContainer}>
            <Animated.View style={[styles.heroContent, heroAnimatedStyle]}>
              <AnimatedText style={styles.heroTitle}>New Lead</AnimatedText>
              <Text style={styles.heroSubtitle}>Fresh load opportunity has arrived</Text>
            </Animated.View>
          </View>

          {/* Notification Content */}
          <View style={styles.contentContainer}>
            <Text style={styles.leadTitle}>Door-to-door cargo shipment</Text>

            <Text style={styles.leadDescription}>
              Looking for a reliable transporter to move fragile goods safely.
            </Text>

            {/* <View style={styles.metaRow}>
              <View style={styles.metaChip}>
                <Text style={styles.metaChipText}>Fragile goods</Text>
              </View>
              <View style={[styles.metaChip, styles.metaChipHighlight]}>
                <Text style={[styles.metaChipText, styles.metaChipHighlightText]}>Priority</Text>
              </View>
            </View> */}

            <View style={styles.routeCard}>
              <View style={styles.routeRow}>
                <Text style={styles.routeIcon}>📍</Text>
                <View style={styles.routeTextContainer}>
                  <Text style={styles.routeLabel}>Pickup</Text>
                  <Text style={styles.routeValue}>Delhi</Text>
                </View>
              </View>
              <View style={styles.routeDivider} />
              <View style={styles.routeRow}>
                <Text style={styles.routeIcon}>🎯</Text>
                <View style={styles.routeTextContainer}>
                  <Text style={styles.routeLabel}>Drop</Text>
                  <Text style={styles.routeValue}>Allahabad</Text>
                </View>
              </View>
            </View>

            <View style={styles.priceTag}>
              <Text style={styles.priceLabel}>Offered Price</Text>
              <Text style={styles.leadPrice}>₹18,500</Text>
            </View>

            <Text style={styles.secondaryNote}>Vehicle must report by tomorrow 8:00 AM</Text>
          </View>

          {/* Action Buttons */}
          <View style={styles.buttonContainer}>
            {notification.actionButtons?.showCancel !== false && (
              <AnimatedTouchableOpacity
                style={[
                  styles.button,
                  styles.cancelButton,
                  !notification.actionButtons?.showCancel && styles.singleButton,
                  getWiggleStyle(rejectAnim, 0.25),
                ]}
                onPress={handleNotificationCancel}
                activeOpacity={0.7}
              >
                <Text style={styles.cancelButtonText}>
                  {notification.actionButtons?.cancelText || 'Reject'}
                </Text>
              </AnimatedTouchableOpacity>
            )}

            <AnimatedTouchableOpacity
              style={[
                styles.button,
                styles.okButton,
                notification.actionButtons?.showCancel === false && styles.singleButton,
                getWiggleStyle(acceptAnim),
              ]}
              onPress={handleNotificationOk}
              activeOpacity={0.9}
            >
              <Text style={styles.okButtonText}>
                {notification.actionButtons?.okText || 'Accept'}
              </Text>
            </AnimatedTouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  alertContainer: {
    backgroundColor: 'white',
    borderRadius: 18,
    width: width * 0.85,
    maxWidth: 400,
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    overflow: 'hidden',
  },
  topAccent: {
    height: 6,
    width: '100%',
    backgroundColor: '#3B82F6',
  },
  leadHeroContainer: {
    marginHorizontal: 20,
    marginTop: 20,
    marginBottom: 18,
    borderRadius: 20,
    overflow: 'hidden',
    height: 120,
    backgroundColor: '#3B82F6',
    justifyContent: 'center',
    alignItems: 'flex-start',
    paddingHorizontal: 24,
  },
  heroContent: {
    paddingTop: 22,
  },
  heroTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: '#FFFFFF',
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  heroSubtitle: {
    marginTop: 8,
    fontSize: 13,
    color: '#E0ECFF',
    fontWeight: '600',
    opacity: 0.75,
  },
  contentContainer: {
    paddingHorizontal: 20,
    paddingBottom: 20,
    alignItems: 'flex-start',
  },
  leadBadge: {
    backgroundColor: '#E8F5E9',
    borderRadius: 20,
    paddingVertical: 6,
    paddingHorizontal: 14,
    marginBottom: 12,
  },
  leadBadgeText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#2E7D32',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  leadTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1a1a1a',
    marginBottom: 8,
  },
  leadDescription: {
    fontSize: 14,
    color: '#4A4E57',
    lineHeight: 20,
    marginBottom: 16,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  metaChip: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 16,
    backgroundColor: '#F1F5F9',
    marginRight: 8,
  },
  metaChipText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#475569',
  },
  metaChipHighlight: {
    backgroundColor: '#FEF3C7',
  },
  metaChipHighlightText: {
    color: '#B45309',
  },
  routeCard: {
    width: '100%',
    backgroundColor: '#F8FAFC',
    borderRadius: 16,
    paddingVertical: 10,
    paddingHorizontal: 14,
    marginBottom: 18,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  routeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 2,
  },
  routeIcon: {
    fontSize: 18,
    marginRight: 10,
  },
  routeTextContainer: {
    flex: 1,
  },
  routeLabel: {
    fontSize: 12,
    color: '#64748B',
    textTransform: 'uppercase',
    letterSpacing: 0.6,
    marginBottom: 2,
  },
  routeValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1F2933',
  },
  routeDivider: {
    height: 1,
    backgroundColor: '#E2E8F0',
    marginVertical: 8,
  },
  leadPrice: {
    fontSize: 24,
    fontWeight: '800',
    color: '#1E3A8A',
  },
  priceTag: {
    width: '100%',
    backgroundColor: '#EEF2FF',
    borderRadius: 16,
    paddingVertical: 16,
    paddingHorizontal: 18,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#C7D2FE',
  },
  priceLabel: {
    fontSize: 12,
    color: '#6366F1',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    marginBottom: 6,
    fontWeight: '700',
  },
  secondaryNote: {
    fontSize: 13,
    color: '#475569',
    backgroundColor: '#F1F5F9',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 12,
  },
  buttonContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 20,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#EEF2FF',
  },
  button: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
    shadowColor: '#1E293B',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.18,
    shadowRadius: 6,
  },
  cancelButton: {
    backgroundColor: '#EF4444',
    marginRight: 12,
    borderWidth: 0,
    borderColor: 'transparent',
    shadowColor: '#EF4444',
    shadowOpacity: 0.3,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 6 },
  },
  okButton: {
    backgroundColor: '#22C55E',
    marginLeft: 12,
    shadowColor: '#22C55E',
    shadowOpacity: 0.35,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 6 },
  },
  singleButton: {
    marginRight: 0,
    marginLeft: 0,
  },
  cancelButtonText: {
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: '600',
    letterSpacing: 0.4,
  },
  okButtonText: {
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: '700',
    letterSpacing: 0.5,
  },
});

export default CustomNotificationAlert;
