import React, {useEffect, useState} from 'react';
import {
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  FlatList,
  ScrollView,
} from 'react-native';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import Images from '../assets/image';
import FSize from '../assets/commonCSS/FSize';
import ButtonNew from './ButtonNew';
import Colors from '../assets/commonCSS/Colors';
import Toast from 'react-native-toast-message';
import {useIsFocused} from '@react-navigation/native';
import Icons from './Icons';
import NewHeader from './NewHeader';
import {useDispatch, useSelector} from 'react-redux';
import {getDataWithToken} from '../services/mobile-api';
import {mobile_siteConfig} from '../services/mobile-siteConfig';
import {setUserDetails} from '../Redux/Actions';
import CustomButton from './CustomButton';

const ManageExperience = ({navigation, route}: {navigation: any}) => {
  const getUserDetails = useSelector(state => state?.getUserDetails);
  const [experienceData, setExperienceData] = useState<any[]>(
    getUserDetails?.experience_details ?? [],
  );
  const dispatch = useDispatch();
  const [noExperienceMessage, setNoExperienceMessage] = useState<string>('');
  const isFocused = useIsFocused();
  useEffect(() => {
    setExperienceData(getUserDetails?.experience_details ?? []);
  }, [isFocused]);
  const removeExperience = async eId => {
    const formData = new FormData();
    formData.append('exp_id', eId);

    try {
      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/delete_exp',
        {
          method: 'POST',
          body: formData,
        },
      );

      const res = await response.json();

      if (res.status === 200) {
        console.log('portfolio data fetched:::::::::::', res.msg);
        setExperienceData(prev => {
          return prev.filter(item => item.id != eId);
        });
        getUserData(res?.msg);
      } else if (res.status === 400) {
        Toast.show({
          type: 'error',
          text1: res.msg,
        });
      }
    } catch (error) {
      console.log('Error fetching portfolio:', error);
      Toast.show({
        type: 'error',
        text1: 'Something went wrong!',
      });
    }
  };
  const getUserData = async msg => {
    try {
      const response = await getDataWithToken(mobile_siteConfig.USER_DETAILS);
      if (response?.status == 200) {
        dispatch(setUserDetails(response?.data));
        Toast.show({
          type: 'success',
          text1: 'Success',
          text2: msg,
        });
      }
    } catch (error) {
      console.log('error in gettting user details', error);
    } finally {
    }
  };
  const renderExperienceItem = ({item}: {item: any}) => (
    <View style={styles.card}>
      <TouchableOpacity
        style={{position: 'absolute', right: 16, top: 8}}
        onPress={() => removeExperience(item?.id)}>
        <Image source={Images.deleteIcon} style={{height: 25, width: 25}} />
      </TouchableOpacity>
      <View style={styles.cardHeader}>
        <Text style={styles.designation}>{item.designation}</Text>
        <Text style={styles.organization}>{item.organization}</Text>
        <Text style={styles.date}>
          {item.from_date.replace(/-/g, '/')} -{' '}
          {item.to_date.replace(/-/g, '/')}
        </Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <NewHeader header={'Manage Experience'} navigation={navigation} />
      <ScrollView contentContainerStyle={styles.section} nestedScrollEnabled>
        {noExperienceMessage ? (
          <View style={styles.noExperienceContainer}>
            <Text style={styles.noExperienceText}>{noExperienceMessage}</Text>
          </View>
        ) : (
          <FlatList
            data={experienceData}
            renderItem={renderExperienceItem}
            keyExtractor={item => item.id.toString()}
            contentContainerStyle={styles.listContainer}
            nestedScrollEnabled
            ListEmptyComponent={
              <Image
                source={Images.emptyExperience}
                style={{
                  height: hp(40),
                  width: wp(65),
                  alignSelf: 'center',
                  marginTop: hp(10),
                }}
                resizeMode="contain"
              />
            }
          />
        )}
      </ScrollView>
      <View
        style={{
          position: 'absolute',
          alignSelf: 'center',
          bottom: hp(4),
          flex: 1,
        }}>
        <CustomButton
          buttonStyle={{width: wp(90)}}
          onButtonPress={() => navigation.navigate('AddExperience')}
          buttonText={'Add Experience'}
        />
      </View>
    </View>
  );
};

export default ManageExperience;

const styles = StyleSheet.create({
  to: {
    color: Colors.black,
  },
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  section: {
    marginHorizontal: wp(5),
    paddingVertical: hp(3),
  },
  headerSection: {
    marginHorizontal: wp(5),
    // marginVertical: hp(1),
    flexDirection: 'row',
    alignItems: 'center',
    gap: wp(2),
  },
  backArrow: {
    width: wp(8),
    height: hp(8),
  },
  headerTitle: {
    color: Colors.black,
    fontWeight: '500',
    fontSize: FSize.fs16,
  },
  listContainer: {
    paddingBottom: hp(3), // Ensure space for the Add Experience button
  },
  card: {
    backgroundColor: Colors.white, // Changed to white for better visibility
    borderRadius: wp(4),

    paddingVertical: hp(2),
    paddingHorizontal: wp(3),
    marginVertical: hp(1),
    marginHorizontal: wp(1),
    shadowColor: Colors.black,
    shadowOpacity: 0.1,
    shadowRadius: 5,
    shadowOffset: {width: 0, height: 2},
    elevation: 2,
  },
  cardHeader: {
    // flexDirection: 'row',
    // justifyContent: 'space-between',
  },
  designation: {
    fontSize: FSize.fs18,
    fontWeight: 'bold',
    width: wp(47),
    color: Colors.black, // Made it bold for emphasis
  },
  organization: {
    fontSize: FSize.fs14,
    color: Colors.gray,
    marginTop: hp(0.5),
  },
  date: {
    fontSize: FSize.fs12,
    color: Colors.gray,
    marginTop: hp(1),
  },
  currentlyWorking: {
    marginTop: hp(0.5),
    fontSize: FSize.fs12,
    color: Colors.sooprsblue,
  },
  noExperienceContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  noExperienceText: {
    fontSize: FSize.fs16,
    color: Colors.gray,
    textAlign: 'center',
  },
});
