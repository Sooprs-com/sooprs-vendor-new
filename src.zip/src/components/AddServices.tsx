import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Image,
  Modal,
  TouchableWithoutFeedback,
  FlatList,
  ScrollView,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import Images from '../assets/image';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import Colors from '../assets/commonCSS/Colors';
import FSize from '../assets/commonCSS/FSize';
import AsyncStorage from '@react-native-async-storage/async-storage';
import ButtonNew from './ButtonNew';
import Toast from 'react-native-toast-message';
import {useIsFocused, useRoute} from '@react-navigation/native';
import NewHeader from './NewHeader';
import NewButton from './NewButton';
import {useDispatch, useSelector} from 'react-redux';
import {getDataWithToken} from '../services/mobile-api';
import {mobile_siteConfig} from '../services/mobile-siteConfig';
import {setProjectFilter, setUserDetails} from '../Redux/Actions';

const AddServices = ({navigation}: {navigation: any}) => {
  const getUserDetails = useSelector(state => state?.getUserDetails);
  const dispatch = useDispatch();
  const [services, setServices] = useState([]);
  const [selectedService, setSelectedService] = useState('');
  const [addedServices, setaddedServices] = useState(getUserDetails?.services);
  const getUserId = useSelector(state => state?.getUserId);
  const [serviceId, setServiceId] = useState(null);
  const [visible, setVisible] = useState(false);
  const getProjectFilters = useSelector(state => state?.getProjectFilters);
  const isCompany = getUserDetails?.is_company;
  const isFocused = useIsFocused();
  console.log(getProjectFilters);
  useEffect(() => {
    fetchServices();
  }, [isFocused]);
  const fetchServices = async () => {
    try {
      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/sr_services_all',
        {
          method: 'POST',
        },
      );
      const data = await response.json();

      if (data.msg) {
        console.log('services data::::::', data.msg[0]);
        if (isCompany === '0') {
          const formattedData = data.msg
            .filter(service => service.flag <= 6)
            .map(service => ({
              id: service.id,
              service_name: service.service_name,
            }));

          console.log('formatted', formattedData);
          setServices(formattedData);
        } else {
          const formattedData = data.msg.map(service => ({
            id: service.id,
            service_name: service.service_name,
          }));
          setServices(formattedData);
        }
      } else {
        console.log('error fetching services::::::::', data.msg);
      }
    } catch (error) {
      console.error('Error fetching services:', error);
      Toast.show({
        type: 'error',
        text1: 'Failed to fetch services',
        text2: 'Please try again later.',
      });
    }
  };

  const addService = async () => {
    if (!serviceId) return; // Validate before proceeding

    const formData = new FormData();
    formData.append('service[]', serviceId);
    formData.append('profid', getUserId);

    try {
      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/addServForm',
        {
          method: 'POST',
          body: formData,
        },
      );
      const res = await response.json();
      if (res.status === 200) {
        // Show success toast with res.msg
        const newService = services?.find(service => service?.id === serviceId);
        setaddedServices(prevServices => {
          if (prevServices?.length > 0) {
            return [...prevServices, newService];
          }
          return [newService];
        });
        // console.log('services69',res)
        getUserData('Your service was successfully added.');
        setVisible(false);
      } else {
        // Show error toast
        console.error('Error:', res.msg);
        Toast.show({
          type: 'error',
          text1: 'Error Adding Service',
          text2: res.message || 'Something went wrong.',
        });
      }
    } catch (error) {
      console.error('Error adding service:', error);
      Toast.show({
        type: 'error',
        text1: 'Error',
        text2: 'Failed to add service. Please try again.',
      });
    }
  };

  const removeService = async serviceId => {
    // console.log('userId',getUserId)
    const formData = new FormData();
    formData.append('dataSerValue', serviceId);
    formData.append('dataPrfValue', getUserId);

    try {
      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/remove_professional_service',
        {
          method: 'POST',
          body: formData,
        },
      );

      const res = await response.json();

      if (res.status === 200) {
        // Remove skill from local state
        setaddedServices(prevServ =>
          prevServ.filter(service => service.id !== serviceId),
        );
        getUserData(res?.msg || 'Failed to remove skill.');
      } else {
        Toast.show({
          type: 'error',
          text1: 'Error',
          text2: res.msg || 'Failed to remove skill.',
        });
      }
    } catch (error) {
      console.error('Error removing skill:', error);
      Toast.show({
        type: 'error',
        text1: 'Error',
        text2: 'An error occurred. Please try again.',
      });
    }
  };
  // check and remove selectedfilter
  const checkandRemoveFilter = (services = []) => {
    const hasService = services.some(
      item => item.id == getProjectFilters?.categories,
    );
    if (!hasService) {
      dispatch(setProjectFilter({...getProjectFilters, categories: null}));
    }
  };
  const getUserData = async msg => {
    try {
      const response = await getDataWithToken(mobile_siteConfig.USER_DETAILS);
      if (response?.status == 200) {
        dispatch(setUserDetails(response?.data));
        // handle the project filter category if removed from here it must also removed from filterselection
        checkandRemoveFilter(response?.data?.services);
        Toast.show({
          type: 'success',
          text1: 'Success',
          text2: msg,
        });
      }
    } catch (error) {
      console.log('error in gettting user details', error);
    } finally {
    }
  };
  const openModal = () => setVisible(true);
  const closeModal = () => setVisible(false);
  return (
    <View style={{flex: 1}}>
      <NewHeader header={'Add Services'} navigation={navigation} />
      <ScrollView
        style={styles.container}
        contentContainerStyle={{paddingBottom: hp(8)}}>
        <View style={styles.services}>
          <Text style={styles.serviceText}>Services</Text>

          <FlatList
            data={addedServices}
            keyExtractor={item => item.id}
            numColumns={2} // Two columns
            renderItem={({item}) => (
              <View style={styles.serviceCard}>
                <Text style={styles.serviceCardText}>{item.service_name}</Text>
                <TouchableOpacity
                  onPress={() => removeService(item.id)}
                  style={styles.crossIconContainer}>
                  <Image
                    source={Images.crossIcon}
                    style={styles.crossIcon}
                    resizeMode="contain"
                  />
                </TouchableOpacity>
              </View>
            )}
            columnWrapperStyle={styles.row}
            nestedScrollEnabled
            ListEmptyComponent={
              <Image
                source={Images.emptyServices}
                style={{
                  height: hp(40),
                  width: wp(65),
                  alignSelf: 'center',
                  marginTop: hp(10),
                }}
                resizeMode="contain"
              />
            }
          />

          {/* Add Service Button */}

          {/* Modal */}
          <Modal
            visible={visible}
            transparent={true}
            animationType="fade"
            onRequestClose={closeModal}>
            <TouchableWithoutFeedback onPress={closeModal}>
              <View style={styles.modalOverlay}>
                <TouchableWithoutFeedback>
                  <View style={styles.modalContent}>
                    {/* Close Icon */}
                    <View style={styles.modalsec}>
                      <TouchableOpacity
                        onPress={closeModal}
                        style={styles.closeIconContainer}>
                        <Image
                          source={Images.crossIcon}
                          style={styles.crossIcon}
                          resizeMode="contain"
                        />
                      </TouchableOpacity>
                      {/* Modal Title */}
                      <Text style={styles.modalTitle}>Add Service</Text>
                    </View>

                    {/* Custom Scrollable Dropdown */}
                    <Text style={styles.labelText}>Select Service</Text>
                    <FlatList
                      data={services}
                      keyExtractor={item => item.id}
                      renderItem={({item}) => (
                        <TouchableOpacity
                          onPress={() => {
                            setSelectedService(item.service_name);
                            setServiceId(item.id);
                          }}
                          style={[
                            styles.serviceItem,
                            selectedService === item.service_name &&
                              styles.selectedService,
                          ]}>
                          <Text
                            style={[
                              styles.serviceNewText,
                              selectedService === item.service_name &&
                                styles.selectedServiceText,
                            ]}>
                            {item.service_name}
                          </Text>
                        </TouchableOpacity>
                      )}
                      style={styles.servicesList}
                    />

                    {/* Submit Button */}
                    <TouchableOpacity
                      onPress={addService}
                      style={styles.submitBtn}>
                      <Text style={styles.submitText}>Submit</Text>
                    </TouchableOpacity>
                  </View>
                </TouchableWithoutFeedback>
              </View>
            </TouchableWithoutFeedback>
          </Modal>
        </View>
      </ScrollView>
      <View
        style={{
          position: 'absolute',
          alignSelf: 'center',
          bottom: hp(4),
          flex: 1,
        }}>
        <NewButton text={'Add Services'} onPress={openModal} />
      </View>
    </View>
  );
};

export default AddServices;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  headerSection: {
    marginHorizontal: wp(5),
    marginVertical: hp(1),
    flexDirection: 'row',
    alignItems: 'center',
    gap: wp(2),
  },
  backArrow: {
    width: wp(8),
    height: hp(8),
  },
  headerTitle: {
    color: Colors.black,
    fontWeight: '500',
    fontSize: FSize.fs16,
  },

  services: {
    marginVertical: hp(2),
    marginHorizontal: wp(7),
  },
  serviceText: {
    color: Colors.sooprsblue,
    fontWeight: '500',
    fontSize: FSize.fs22,
  },
  row: {
    justifyContent: 'space-between',
  },
  serviceCard: {
    marginTop: hp(3),
    backgroundColor: Colors.lightgrey1,
    padding: wp(3),
    borderRadius: wp(2),
    marginBottom: hp(1),
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 4,
    justifyContent: 'space-between',
  },
  crossIconContainer: {
    marginLeft: wp(2),
  },
  crossIcon: {
    width: 20,
    height: 20,
  },
  serviceCardText: {
    width: wp(30),
    fontSize: FSize.fs14,
    color: Colors.black,
  },
  noServicesText: {
    fontSize: FSize.fs14,
    color: Colors.gray,
    textAlign: 'center',
    marginTop: hp(5),
  },
  addService: {
    marginTop: hp(5),
    alignItems: 'center',
    // position:'absolute',
    // bottom:0
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: wp(80),
    backgroundColor: '#FFF',
    padding: wp(5),
    borderRadius: wp(2),
  },
  closeIconContainer: {
    alignSelf: 'flex-end',
  },
  modalTitle: {
    fontSize: FSize.fs18,
    fontWeight: 'bold',
    marginBottom: hp(2),
    color: Colors.black,
  },
  modalsec: {
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  labelText: {
    fontSize: FSize.fs14,
    marginVertical: hp(1),
    color: Colors.sooprsblue,
  },
  servicesList: {
    maxHeight: hp(25),
  },
  serviceItem: {
    padding: hp(2),
    borderBottomWidth: 1,
    borderColor: Colors.lightGrey,
  },
  selectedService: {
    backgroundColor: Colors.sooprsblue,
  },
  selectedServiceText: {
    color: Colors.white,
  },
  serviceNewText: {
    fontSize: FSize.fs14,
    color: Colors.black,
  },
  submitBtn: {
    marginTop: hp(3),
    backgroundColor: '#0077FF',
    padding: wp(3),
    alignItems: 'center',
    borderRadius: wp(2),
  },
  submitText: {
    color: '#FFFFFF',
    fontSize: FSize.fs16,
    fontWeight: 'bold',
  },
});
