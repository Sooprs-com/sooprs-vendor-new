import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import {DeviceWidth} from '../Utilities';
import Colors from '../assets/commonCSS/Colors';
import Images from '../assets/image';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import {useNavigation} from '@react-navigation/native';

const CustomHeader = ({title = '', backButton = false, imageTitle = false}) => {
  const navigation = useNavigation();
  return (
    <View style={styles.container}>
      {/* Back Arrow */}
      {backButton && (
        <TouchableOpacity
          style={{position: 'absolute', left: wp(3)}}
          onPress={() => navigation.goBack()}>
          <Image
            source={Images.backArrow}
            style={styles.backArrow}
            resizeMode="contain"
          />
        </TouchableOpacity>
      )}
      {/* Title */}
      {title && <Text style={styles.title}>{title}</Text>}
      {imageTitle && (
        <Image
          source={Images.Sooprslogo}
          style={{height: hp(8), width: wp(70)}}
          resizeMode="contain"
        />
      )}
    </View>
  );
};

export default CustomHeader;

const styles = StyleSheet.create({
  container: {
    width: DeviceWidth,
    backgroundColor: Colors.white,
    height: hp(8),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop:hp(3)
  },
  backArrow: {
    height: hp(5),
    width: wp(9),
  },
  title: {
    fontSize: hp(2.5),
    color: Colors.sooprsblue,
    fontWeight: '600',
  },
});
