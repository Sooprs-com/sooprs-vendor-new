import React, {useState, useEffect, useCallback} from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Linking,
  ActivityIndicator,
  RefreshControl,
  Image,
  Alert,
} from 'react-native';
import {useFocusEffect} from '@react-navigation/native'; // Import useFocusEffect
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import FSize from '../assets/commonCSS/FSize';
import Colors from '../assets/commonCSS/Colors';
import {mobile_siteConfig} from '../services/mobile-siteConfig';
import {getDataFromAsyncStorage} from '../services/CommonFunction';
import Images from '../assets/image';
import he from 'he';
import NewHeader from './NewHeader';
const ContactDetailScreen = ({navigation, route}) => {
  const {inProfileSection = false} = route?.params || {};
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const decodeHtmlEntities = str => {
    return he.decode(str); // Decodes HTML entities (e.g. &#39; -> ')
  };
  // Fetch Contacts Data
  const fetchContacts = async () => {
    setLoading(true);
    const getUserId = await getDataFromAsyncStorage(mobile_siteConfig.UID);
    const formData = new FormData();
    formData.append('id', getUserId);

    try {
      const response = await fetch(
        `${mobile_siteConfig.BASE_URL}${mobile_siteConfig.INDEX}${mobile_siteConfig.GET_CONTACTS}`,
        {
          method: 'POST',
          body: formData,
        },
      );

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const result = await response.json();
      if (result.status === 200 && result.msg === 'Success') {
        const map = new Map();
        const removeDuplicates = result?.data?.filter(item => {
          if (!map.has(item.id)) {
            map.set(item.id);
            return true; // Keep the item in the array
          }
          return false; // Skip duplicate
        });
        setData(removeDuplicates);
      } else {
        setData([]);
      }
    } catch (error) {
      console.error('Error fetching contacts:', error);
      setData([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Dial Contact Number
  const handleDial = mobile => {
    Linking.openURL(`tel:${mobile}`);
  };
  const openWhatsApp = phoneNumber => {
    const whatsappURL = `whatsapp://send?phone=${phoneNumber}`;

    Linking.canOpenURL(whatsappURL)
      .then(supported => {
        if (supported) {
          return Linking.openURL(whatsappURL);
        } else {
          Alert.alert('Error', 'WhatsApp is not installed on your device.');
        }
      })
      .catch(err => console.error('Error:', err));
  };
  // handle card press
  const handleNavigation = (screenName, params = {}) => {
    navigation.navigate('ProfessionalStack', {screen: screenName, params});
  };
  const handleCardPress = item => {
    // console.log('itemDetails===>', item);
    handleNavigation('ProjectDetails', {
      id: item.id,
      cScreen: true,
      contactNumber: item.mobile,
      hideChat: true,
      // isCompany,
    });
  };
  // Render Contact Item
  const renderItem = ({item, index}) => {
    const [date, time] = item?.created_at.split(' ');
    return (
      <TouchableOpacity
        style={styles.card}
        onPress={() => handleCardPress(item)}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
          }}>
          <View style={{width: wp(60)}}>
            <Text style={{color: Colors.black}}>
              {decodeHtmlEntities(item.project_title)}
            </Text>
          </View>
          <View>
            <Text
              style={{
                textAlign: 'right',
                color: Colors.gray,
                fontWeight: '500',
              }}>
              {time ?? ''}
            </Text>
            <Text
              style={{
                color: Colors.gray,
                fontWeight: '500',
                textAlign: 'right',
              }}>
              {date ?? ''}
            </Text>
          </View>
        </View>
        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
          <TouchableOpacity
            onPress={() => openWhatsApp(item.mobile)}
            style={{flexDirection: 'row', marginVertical: 20, flex: 1}}>
            <Image
              source={Images.whatsAppIcon}
              style={{height: 25, width: 25}}
              resizeMode="contain"
            />
            <Text
              style={{
                color: Colors.sooprsblue,
                textDecorationLine: 'underline',
                marginLeft: 8,
              }}>
              Chat now
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{flexDirection: 'row', marginTop: 20}}
            onPress={() => handleDial(item.mobile)}>
            <Image
              source={Images.phoneIcon1}
              style={{height: 22, width: 22}}
              resizeMode="contain"
            />
            <Text
              style={{color: Colors.black, fontSize: 16, fontWeight: '500'}}>
              {item?.mobile}
            </Text>
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    );
  };

  // Show Loading Spinner
  const renderLoading = () => (
    <View style={styles.centered}>
      <ActivityIndicator size="large" color={Colors.sooprsblue} />
    </View>
  );

  // Show Empty State
  const RenderEmptyState = () => (
    <Image
      source={Images.nodata}
      style={{
        height: hp(40),
        width: wp(65),
        alignSelf: 'center',
        marginTop: hp(10),
      }}
      resizeMode="contain"
    />
  );

  // Handle Pull-to-Refresh
  const handleRefresh = () => {
    setRefreshing(true);
    fetchContacts();
  };

  // Fetch data on screen focus
  useFocusEffect(
    useCallback(() => {
      fetchContacts();
    }, []),
  );

  return (
    <View style={styles.container}>
      <NewHeader
        header={'My leads'}
        hideBackButton={!inProfileSection}
        navigation={navigation}
      />
      {/* Main Content */}
      {loading ? (
        renderLoading()
      ) : (
        <FlatList
          data={data}
          keyExtractor={(item, index) => index.toString()}
          renderItem={renderItem}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={<RenderEmptyState />}
          ListHeaderComponent={<View style={{marginTop: 20}} />}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              colors={[Colors.sooprsblue]}
            />
          }
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  headerSection: {
    marginHorizontal: wp(5),
    marginVertical: hp(1),
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconStyle: {width: 35, height: 35, marginRight: 8},
  headerTitle: {
    color: Colors.black,
    fontWeight: '500',
    fontSize: FSize.fs16,
  },
  card: {
    alignSelf: 'center',
    alignItems: 'center',
    width: wp(90),
    backgroundColor: Colors.white,
    paddingHorizontal: wp(4),
    paddingTop: 10,
    marginBottom: 15,
    borderWidth: 1,
    borderRadius: 10,
    borderColor: Colors.lightGrey,
  },
  title: {
    fontSize: FSize.fs16,
    fontWeight: 'bold',
    color: Colors.black,
    marginBottom: hp(0.5),
  },
  date: {
    fontSize: FSize.fs14,
    color: Colors.gray,
    marginBottom: hp(0.5),
  },
  mobile: {
    fontSize: FSize.fs15,
    color: Colors.sooprsblue,
  },
  emptyText: {
    fontSize: FSize.fs16,
    color: Colors.gray,
    textAlign: 'center',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContent: {
    paddingBottom: hp(5),
  },
});

export default ContactDetailScreen;
