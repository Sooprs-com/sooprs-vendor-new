import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import Materials from 'react-native-vector-icons/MaterialCommunityIcons';
import { TouchableOpacity } from 'react-native-gesture-handler';
const Icons = ({name, color, size,style,iconPress=()=>{}}) => {
  return (
    <TouchableOpacity style={{...style}} onPress={iconPress}>
      <Materials name={name} color={color} size={size} />
    </TouchableOpacity>
  )
};

export default Icons;

const styles = StyleSheet.create({});
