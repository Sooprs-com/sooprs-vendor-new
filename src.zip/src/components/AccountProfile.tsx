import {
  Image,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Alert,
  NativeModules,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import FSize from '../assets/commonCSS/FSize';
import Colors from '../assets/commonCSS/Colors';
import Images from '../assets/image';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {CommonActions, useIsFocused} from '@react-navigation/native';
import {mobile_siteConfig} from '../services/mobile-siteConfig';
import DeviceInfo from 'react-native-device-info';
import {Icon} from 'react-native-paper';
const AccountProfile = ({
  navigation,
  isClient,
  name,
  profileImage,
  isCompany,
}: {
  navigation: any;
  isClient: any;
  name: any;
  profileImage: any;
  isCompany: any;
}) => {
  const appVersion = DeviceInfo.getVersion();
  const confirmLogout = async () => {
    try {
      // Remove token and buyer status from AsyncStorage

      await AsyncStorage.removeItem(mobile_siteConfig.TOKEN);
      await AsyncStorage.removeItem(mobile_siteConfig.IS_BUYER);
      await AsyncStorage.removeItem(mobile_siteConfig.fcmToken);
      // Set login status to FALSE
      await AsyncStorage.setItem(mobile_siteConfig.IS_LOGIN, 'FALSE');

      // Reset navigation stack to Authentication screen
      const reset = CommonActions.reset({
        index: 0,
        routes: [{name: 'Authentication'}],
      });
      navigation.dispatch(reset);
      // console.log('User successfully logged out.');
    } catch (error) {
      console.error('Logout Error: ', error);
      Alert.alert(
        'Error',
        'An error occurred while logging out. Please try again.',
      );
    }
  };

  const handleLogout = () => {
    Alert.alert('Logout', 'Are you sure you want to logout?', [
      {
        text: 'No',
        onPress: () => console.log('Logout cancelled'),
        style: 'cancel',
      },
      {
        text: 'Yes',
        onPress: async () => {
          try {
            await confirmLogout();
          } catch (error) {
            console.error('Error confirming logout: ', error);
          }
        },
      },
    ]);
  };
  const ProfileItems = [
    {
      id: 1,
      icon: Images.detailsIcon,
      text1: 'Details',
      navigateToSubScreen: true,
      navigateTo: '',
      subFields: [
        {
          text: 'Manage Details',
          navigateTo: 'ManageDetails',
          icon: Images.manageDetailsIcone,
        },
        !isClient &&
          isCompany == '0' && {
            text: 'Manage Acadmics',
            navigateTo: 'ManageAcademics',
            icon: Images.mAcademics,
          },
        !isClient && {
          text: 'Portfolio',
          navigateTo: 'ManagePortfolio',
          icon: Images.mPortfolio,
        },
        !isClient && {
          text: 'Services',
          navigateTo: 'AddServices',
          icon: Images.mServices,
        },
        !isClient &&
          isCompany == '0' && {
            text: 'Skills',
            navigateTo: 'AddSkills',
            icon: Images.mSkills,
          },
        !isClient &&
          isCompany == '0' && {
            text: 'Resume',
            navigateTo: 'ManageResume',
            icon: Images.mResume,
          },
        !isClient &&
          isCompany == '0' && {
            text: 'Experience',
            navigateTo: 'ManageExperience',
            icon: Images.mExp,
          },
      ].filter(Boolean),
    },
    !isClient && {
      id: 2,
      icon: Images.wallet1,
      text1: 'Credits',
      navigateToSubScreen: false,
      navigateTo: 'AddCredits',
      subFields: [{text: 'Credited'}, {text: 'Debited'}],
    },
    {
      id: 3,
      icon: Images.gigsIcone,
      text1: 'Gigs',
      navigateToSubScreen: true,
      navigateTo: '',
      subFields: [
        !isClient && {
          text: 'My Gigs',
          navigateTo: 'MyGigs',
          icon: Images.mTran,
        },
        !isClient && {
          text: 'Gigs Sold',
          navigateTo: 'GigSoldPurchased',
          icon: Images.mTran,
        },
        {
          text: 'Purchased Gigs',
          navigateTo: 'GigSoldPurchased',
          icon: Images.mTran,
        },
      ].filter(Boolean),
    },
    isCompany == '1' && {
      id: 4,
      icon: Images.subscription1,
      text1: 'Subscription',
      navigateToSubScreen: false,
      navigateTo: 'SubscriptionScreen',
      subFields: [
        // {text: 'Gigs Sold', navigateTo: 'GigSoldPurchased'},
        // {text: 'Purchased Gigs', navigateTo: 'GigSoldPurchased'},
      ],
    },
    isCompany == '0' && {
      id: 5,
      icon: Images.phoneIcon1,
      text1: 'My Leads',
      navigateTo: 'ContactDetails',
      navigateToSubScreen: false,
      subFields: [{text: 'Purchased Leads'}],
    },
    {
      id: 6,
      icon: Images.settings1,
      text1: 'Settings',
      navigateToSubScreen: true,
      navigateTo: '',
      subFields: [
        {text: 'Password', navigateTo: 'ManagePassword', icon: Images.passwordIcone},
        {
          text: 'Bank Details',
          navigateTo: 'BankDetails',
          icon: Images.bankDetailsIcone,
        },

        // {text: 'kyc', navigateTo: ''},
        // {text: 'socials', navigateTo: ''},
      ],
    },

    {
      id: 7,
      icon: Images.aboutSooprs,
      text1: 'About Sooprs',
      navigateTo: '',
      navigateToSubScreen: true,
      subFields: [
        {
          text: 'Privacy Policy',
          navigateTo: 'WebView',
          icon: Images.privacyPolicyIcone,
          // WebLink: 'https://sooprs.com/privacy-policy',
        },
        {
          text: 'Term & Condition',
          navigateTo: 'WebView',
          icon: Images.termAndConditionIcone
          // WebLink: 'https://sooprs.com/terms-and-conditions',
        },
        {
          text: 'Refund Policy',
          navigateTo: 'WebView',
          icon: Images.refundPolicyIcone,
          // WebLink: 'https://sooprs.com/refund-policy',
        },
        {
          text: 'Contact Us',
          navigateTo: 'WebView',
          icon: Images.contactUsIcone,
          // WebLink: 'https://sooprs.com/contact-us',
        },
        {
          text: 'FAQ',
          navigateTo: 'WebView',
          icon: Images.faqIcone,
          // WebLink: 'https://sooprs.com/frequently-ask-questions',
        },
      ],
    },
  ].filter(Boolean);
  // handleNavigation
  const handleNavigation = (screenName, params = {}) => {
    navigation.navigate('AccountStack', {screen: screenName, params});
  };
  return (
    <View style={styles.profile}>
      <ScrollView contentContainerStyle={styles.profileSection}>
        {ProfileItems.map((parentItem, index) => {
          return (
            <View key={index}>
              <TouchableOpacity
                style={styles.itemContainer}
                activeOpacity={0.6}
                onPress={() => {
                  if (parentItem?.navigateToSubScreen) {
                    handleNavigation('SubAccount', {
                      heading: parentItem?.text1,
                      items: parentItem?.subFields,
                      imageIcon: parentItem?.icon,
                    });
                  } else {
                    handleNavigation(parentItem?.navigateTo, {
                      inProfileSection: true,
                    });
                  }
                }}>
                <Image
                  source={parentItem?.icon}
                  style={styles.Icon}
                  resizeMode="contain"
                  tintColor={Colors.sooprsblue}
                />
                <View style={{marginLeft: 8, width: '80%'}}>
                  <Text style={styles.heading}>{parentItem?.text1}</Text>
                  <View style={styles.childTextView}>
                    {parentItem?.subFields.map((item, index) => {
                      return (
                        <Text
                          style={{color: Colors.gray, fontWeight: '400'}}
                          key={index}>
                          {item?.text}
                          {index != parentItem?.subFields?.length - 1 && ', '}
                        </Text>
                      );
                    })}
                  </View>
                </View>
                <Image
                  source={Images.chevRight}
                  style={styles.icon}
                  resizeMode="contain"
                />
              </TouchableOpacity>
              <View style={styles.underLine} />
            </View>
          );
        })}
        <TouchableOpacity style={styles.button} onPress={handleLogout}>
          <Image
            source={Images.logoutIcon}
            style={styles.icon}
            tintColor={'red'}
          />
          <Text style={styles.text}>Logout</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

export default AccountProfile;

const styles = StyleSheet.create({
  profile: {
    flex: 1,
    // paddingTop:hp(20)
  },
  profileSection: {
    padding: 20,
    flex: 1,
  },
  heading: {
    color: Colors.black,
    fontWeight: '500',
    fontSize: FSize.fs18,
  },
  itemContainer: {
    marginVertical: 5,
    flexDirection: 'row',
    alignItems: 'center',
  },
  childTextView: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 4,
  },
  underLine: {
    height: 0,
    width: '100%',
    borderTopWidth: 1,
    marginVertical: 10,
    borderColor: Colors.lightgrey2,
  },
  logoContainer: {
    position: 'absolute',
    bottom: 20,
    alignSelf: 'center',
    alignItems: 'center',
  },
  versionText: {
    color: Colors.lightGrey,
    fontWeight: '500',
    fontSize: 12,
    marginLeft: 10,
  },
  Icon: {height: hp(4), width: wp(7)},

  rightArrowIcon: {
    tintColor: Colors.black,
    width: wp(3),
    height: hp(1.5),
  },
  logout: {
    marginVertical: hp(2),
    marginHorizontal: wp(17),
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: hp(3),
    justifyContent: 'flex-start',
    width: '40%',
  },
  icon: {
    width: wp(6),
    height: hp(4),
    marginRight: 10,
  },
  text: {
    color: 'red',
    fontSize: FSize.fs20,
    fontWeight: '400',
  },
});
