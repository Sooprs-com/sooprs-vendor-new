import {
  Alert,
  Image,
  PermissionsAndroid,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import Images from '../assets/image';
import Colors from '../assets/commonCSS/Colors';
import FSize from '../assets/commonCSS/FSize';
import CountriesDropdown from './CountriesDropdown';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import {launchImageLibrary} from 'react-native-image-picker';
import ButtonNew from './ButtonNew';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {useIsFocused} from '@react-navigation/native';
import Toast from 'react-native-toast-message';
import {mobile_siteConfig} from '../services/mobile-siteConfig';
import countriesData from '../countries.json';
import Icons from './Icons';
import NewHeader from './NewHeader';
import {useDispatch, useSelector} from 'react-redux';
import {setUserDetails} from '../Redux/Actions';
import {getDataWithToken} from '../services/mobile-api';

const ManageDetails = ({navigation, route}: {navigation: any; route: any}) => {
  const getUserDetails = useSelector(state => state?.getUserDetails);
  const [newName, setNewName] = useState(getUserDetails?.name);
  const [newProfileImage, setNewProfileImage] = useState(getUserDetails?.image);
  const [emailState, setEmail] = useState(getUserDetails?.email);
  const [mobileState, setMobile] = useState(getUserDetails?.mobile);
  const [cityState, setCity] = useState(getUserDetails?.city);
  const [addressState, setAddress] = useState(getUserDetails?.address);
  const [pincodeState, setPincode] = useState(getUserDetails?.area_code);
  const [countryState, setCountry] = useState(getUserDetails?.country);
  const [organisationState, setOrganisation] = useState(
    getUserDetails?.organisation,
  );
  const [linkedInState, setLinkedIn] = useState(getUserDetails?.linkedin);
  const [aboutState, setAbout] = useState(getUserDetails?.listing_about);
  const [countryCode, setCountryCode] = useState(getUserDetails?.country);
  const getIfProfessional = useSelector(state => state?.getIfProfessional);
  const [pincodeError, setPincodeError] = useState('');
  const [linkedInError, setLinkedInError] = useState('');
  const dispatch = useDispatch();

  // Country code to country name mapping from countriesData
  const countryCodeMapping = countriesData.reduce((acc, country) => {
    acc[country.code] = country.name;
    return acc;
  }, {});

  useEffect(() => {
    if (countryCodeMapping[countryCode]) {
      setCountry(countryCodeMapping[countryCode]);
    } else {
      setCountry('Select Country');
    }
  }, [countryCode]);

  const handleCountrySelect = (selectedCountry, selectedCountryCode) => {
    setCountry(selectedCountry);
    setCountryCode(selectedCountryCode);
  };

  const saveProfileDetails = async () => {
    if (
      !newName ||
      !emailState ||
      !mobileState ||
      !cityState ||
      !addressState ||
      !pincodeState ||
      !countryState ||
      (getIfProfessional == 0 &&
        (!organisationState || !linkedInState || !aboutState))
    ) {
      Toast.show({
        text1: 'Incomplete information',
        text2: 'Please fill all the required fields.',
        type: 'error',
      });
      return;
    }

    try {
      const id = await AsyncStorage.getItem('uid');

      // Remove leading and trailing quotes if present
      const cleanedId = id ? id.replace(/^"|"$/g, '') : null;

      // Create FormData object
      const formData = new FormData();
      formData.append('id', cleanedId);
      formData.append('name', newName);
      formData.append('email', emailState);
      formData.append('city', cityState);
      formData.append('address', addressState);
      formData.append('area_code', pincodeState);
      formData.append('country', countryCode); // Assuming you're using country code
      formData.append('mobile', mobileState);
      if (getIfProfessional == 0) {
        formData.append('organisation', organisationState);
        formData.append('linkedin', linkedInState);
        formData.append('about', aboutState);
      }
      //   await AsyncStorage.setItem('profileDetails', profileImage);
      // Make the POST request
      console.log('save profile details ::::::', formData);
      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/update_profile_professional',
        {
          method: 'POST',
          body: formData,
          headers: {
            'User-Agent': 'com.sooprsapp/1.0',
          },
        },
      );

      const jsonResponse = await response.json();

      // Check for successful response
      if (jsonResponse.status == 200) {
        //update the local storage only
        getUserData('Your profile details have been successfully updated.');
      } else {
        // Show error toast
        Toast.show({
          text1: 'Update Failed',
          text2: 'Failed to update profile. Please try again.',
          type: 'error',
        });
      }
    } catch (e) {
      console.log('Error saving profile details:', e);
      // Show error toast
      Toast.show({
        text1: 'Error',
        text2: 'An error occurred while saving profile details.',
        type: 'error',
      });
    }
  };
  const getUserData = async msg => {
    try {
      const response = await getDataWithToken(mobile_siteConfig.USER_DETAILS);
      if (response?.status == 200) {
        dispatch(setUserDetails(response?.data));
        Toast.show({
          type: 'success',
          text1: 'Profile Updated',
          text2: msg,
        });
      }
    } catch (error) {
      console.log('error in gettting user details', error);
    } finally {
    }
  };
  // Validation checks
  const isValidEmail = (email: string) => {
    const emailRegex = /\S+@\S+\.\S+/;
    return emailRegex.test(email);
  };

  const isValidMobile = (mobile: string) => {
    const mobileRegex = /^\+?[0-9]{1,4}[-\s]?[0-9]{6,16}$/;
    return mobileRegex.test(mobile);
  };

  const validatePincode = value => {
    const pincodeRegex = /^[1-9][0-9]{5}$/;
    if (!pincodeRegex.test(value)) {
      setPincodeError('Invalid Pincode');
    } else {
      setPincodeError('');
    }
    setPincode(value);
  };

  const validateLinkedIn = value => {
    const linkedInRegex = /^https:\/\/[a-z]{2,3}\.linkedin\.com\/.*$/;
    if (!linkedInRegex.test(value)) {
      setLinkedInError('Invalid LinkedIn ID');
    } else {
      setLinkedInError('');
    }
    setLinkedIn(value);
  };

  const selectImage = async () => {
    const result = await launchImageLibrary({
      mediaType: 'photo',
      maxWidth: 300,
      maxHeight: 300,
      includeBase64: true,
    });

    if (result?.assets?.length) {
      const imageUri = result.assets[0].uri;
      const imageName = result.assets[0].fileName; // Get the image name
      const imageType = result.assets[0].type; // Get the image MIME type (e.g., image/jpeg, image/png)

      setNewProfileImage(imageUri); // Set the image locally for preview
      // Get the user ID from AsyncStorage
      const id = await AsyncStorage.getItem('uid');
      const cleanedId = id ? id.replace(/^"|"$/g, '') : null; // Remove quotes if any

      if (!cleanedId) {
        console.error('User ID not found.');
        Toast.show({
          type: 'error',
          text1: 'Error',
          text2: 'User ID not found.',
        });
        return;
      }

      // Prepare the image for upload using FormData
      const formData = new FormData();
      formData.append('image', {
        uri: imageUri,
        name: imageName || 'profile_picture', // Use actual file name if available
        type: imageType || 'image/jpeg', // Use actual MIME type, default to JPEG if not available
      });
      formData.append('id', cleanedId); // Append the user ID
      formData.append('table', 'join_professionals'); // Append the table name

      try {
        const response = await fetch(
          'https://sooprs.com/api2/public/index.php/upload_picture',
          {
            method: 'POST',
            body: formData,
            headers: {
              'User-Agent': 'com.sooprsapp/1.0',
            },
          },
        );

        const responseData = await response.json();
        // console.log('Image upload response:', responseData);

        // Check for success status and store the image URL
        if (responseData?.status === 200 && responseData?.msg?.image) {
          const imageUrl = responseData.msg.image;
          const userDetailsObject = {
            ...getUserDetails,
            image: imageUrl,
          };
          dispatch(setUserDetails(userDetailsObject));
          Toast.show({
            type: 'success',
            text1: 'Success',
            text2: 'Image uploaded successfully!',
          });

          console.log('Image URL saved to AsyncStorage:', imageUrl);
        } else {
          console.error('Image upload failed:', responseData);
          Toast.show({
            type: 'error',
            text1: 'Error',
            text2: 'Image upload failed.',
          });
        }
      } catch (error) {
        console.error('Error uploading image:', error);
        Toast.show({
          type: 'error',
          text1: 'Error',
          text2: 'An error occurred while uploading the image.',
        });
      }
    } else {
      console.error('No image selected.');
      Toast.show({
        type: 'error',
        text1: 'Error',
        text2: 'No image selected.',
      });
    }
  };

  return (
    <View style={{flex: 1, backgroundColor: Colors.white}}>
      <NewHeader header={'Manage Details'} navigation={navigation} />
      <ScrollView style={styles.section}>
        <View style={styles.profileHeading}>
          <View>
            <Image
              style={styles.Icon}
              resizeMode="cover"
              source={
                newProfileImage ? {uri: newProfileImage} : Images.defaultPicIcon
              }
            />
            <Icons
              name={'camera-outline'}
              color={Colors.sooprsblue}
              size={20}
              style={styles.cameraIcon}
              iconPress={() => selectImage()}
            />
          </View>
          {/* </View> */}
          {/* </TouchableOpacity> */}
          <Text style={styles.profileName}>{newName ? newName : 'User'}</Text>
        </View>
        {/* Form Fields */}
        <View style={styles.formContainer}>
          <Text style={styles.label}>Name</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your name"
            placeholderTextColor={Colors.gray}
            value={newName}
            onChangeText={setNewName}
          />
          {newName?.length < 1 && (
            <Text style={styles.errorText}>Please enter your name</Text>
          )}
          <Text style={styles.label}>Email</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your email"
            placeholderTextColor={Colors.gray}
            keyboardType="email-address"
            value={emailState}
            onChangeText={setEmail}
          />
          {!isValidEmail(emailState) && emailState?.length > 0 && (
            <Text style={styles.errorText}>Invalid email format</Text>
          )}

          <Text style={styles.label}>Mobile</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your mobile number"
            placeholderTextColor={Colors.gray}
            keyboardType="number-pad"
            value={mobileState}
            onChangeText={setMobile}
          />
          {(!isValidMobile(mobileState) || mobileState?.length < 1) && (
            <Text style={styles.errorText}>Invalid mobile number</Text>
          )}

          <Text style={styles.label}>City</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your city"
            placeholderTextColor={Colors.gray}
            value={cityState}
            onChangeText={setCity}
          />
          {cityState?.length < 1 && (
            <Text style={styles.errorText}>Please enter your city</Text>
          )}
          <Text style={styles.label}>Address</Text>
          <TextInput
            style={[styles.input, styles.addressTextInput]}
            placeholder="Enter your address..."
            placeholderTextColor={Colors.gray}
            multiline={true}
            textAlignVertical="top"
            value={addressState}
            onChangeText={setAddress}
          />
          <Text style={styles.label}>Pincode</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your pincode"
            placeholderTextColor={Colors.gray}
            keyboardType="number-pad"
            value={pincodeState}
            onChangeText={validatePincode}
          />
          {pincodeError ? (
            <Text style={styles.errorText}>{pincodeError}</Text>
          ) : null}
          <Text style={styles.label}>Country</Text>
          {/* Custom Dropdown for country selection */}
          <CountriesDropdown
            selectedCountry={countryState}
            selectedCountryCode={countryCode}
            onSelect={handleCountrySelect}
          />
          {getIfProfessional == 0 && (
            <>
              <Text style={styles.label}>Organisation</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter your organisation"
                placeholderTextColor={Colors.gray}
                value={organisationState}
                onChangeText={setOrganisation}
              />
              {organisationState?.length < 1 && (
                <Text style={styles.errorText}>
                  Please enter your organisation name
                </Text>
              )}
              <Text style={styles.label}>LinkedIn ID</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter your linkedIn ID"
                placeholderTextColor={Colors.gray}
                value={linkedInState}
                onChangeText={validateLinkedIn}
              />
              {linkedInError ? (
                <Text style={styles.errorText}>{linkedInError}</Text>
              ) : null}
              <Text style={styles.label}>About</Text>
              <TextInput
                style={[styles.input, styles.multilineInput]}
                placeholder="Tell us more about yourself..."
                placeholderTextColor={Colors.gray}
                multiline={true}
                textAlignVertical="top"
                value={aboutState}
                onChangeText={setAbout}
              />
              {aboutState?.length < 1 && (
                <Text style={styles.errorText}>
                  Please enter something about yourself
                </Text>
              )}
            </>
          )}
        </View>
        <View style={styles.saveButton}>
          <ButtonNew
            imgSource={undefined}
            btntext={'Update Profile'}
            bgColor={Colors.sooprsblue}
            textColor={Colors.white}
            onPress={saveProfileDetails}
            isBorder={true}
            isDisabled={undefined}
          />
        </View>
      </ScrollView>
    </View>
  );
};

export default ManageDetails;

const styles = StyleSheet.create({
  section: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  headerSection: {
    marginHorizontal: wp(5),
    marginVertical: hp(1),
    flexDirection: 'row',
    alignItems: 'center',
    gap: wp(2),
  },
  backArrow: {
    width: wp(8),
    height: hp(8),
  },
  headerTitle: {
    color: Colors.black,
    fontWeight: '500',
    fontSize: FSize.fs16,
  },
  profileHeading: {
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: hp(2),
  },
  profileIcon: {
    width: wp(32),
    height: hp(14),
    borderWidth: 2,
    borderColor: Colors.sooprsblue,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: wp(30),
    marginBottom: wp(2),
  },

  Icon: {
    width: 120,
    height: 120,
    borderRadius: 60,
  },
  profileName: {
    fontSize: FSize.fs24,
    fontWeight: '600',
    color: Colors.black,
  },
  formContainer: {
    paddingHorizontal: wp(5),
  },
  label: {
    color: Colors.black,
    fontSize: FSize.fs15,
    fontWeight: '600',
    marginBottom: hp(1.5),
  },
  input: {
    borderWidth: 1,
    borderColor: Colors.gray,
    borderRadius: wp(2),
    paddingVertical: hp(1),
    paddingHorizontal: wp(4),
    fontSize: FSize.fs14,
    color: Colors.black,
    marginBottom: hp(2),
  },
  multilineInput: {
    height: hp(20),
    textAlignVertical: 'top',
  },

  addressTextInput: {
    height: hp(10),
    textAlignVertical: 'top',
  },

  errorText: {
    color: 'red',
    fontSize: FSize.fs12,
    marginBottom: hp(1),
  },

  saveButton: {
    marginVertical: hp(1.5),
    marginHorizontal: wp(5),
  },
  cameraIcon: {
    position: 'absolute',
    right: 6,
    bottom: 8,
    borderWidth: 1.5,
    backgroundColor: Colors.white,
    borderRadius: 200,
    padding: 7,
    borderColor: Colors.sooprsblue,
  },
});
