import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import Colors from '../assets/commonCSS/Colors';
import {hp} from '../assets/commonCSS/GlobalCSS';
import Portfolio from '../ProfessionalScreens/TabView/Portfolio';
import Reviews from '../ProfessionalScreens/TabView/Reviews';
import CompanyInfo from '../UserScreens/TabView/CompanyInfo';
import UserDetails from './UserDetails';
import FSize from '../assets/commonCSS/FSize';
import Gigs from './Gigs';

const Tab = createMaterialTopTabNavigator();

const ProfileTabs = ({
  tabs,
  isClient,
  portfolio,
  services,
  skills,
  about,
  education,
  experience,
  portFolios,
  gigs,
  reviews,
  navigation,
  currency,
}: {
  tabs: string[];
  portfolio: any;
  isClient: boolean;
  services: string[];
  skills: string[];
  about: string;
  education: [];
  experience: [];
  portFolios: [];
  gigs: [];
  reviews: [];
  navigation: any;
  currency: string;
}) => {
  const renderTabScreens = () => {
    return tabs.map((tab, index) => {
      switch (tab) {
        case 'Details':
          return (
            <Tab.Screen
              key={index}
              name={tab}
              children={() => (
                <UserDetails
                  about={about}
                  services={services}
                  skills={skills}
                  education={education}
                  experience={experience}
                />
              )}
            />
          );
        case 'Portfolio':
          return (
            <Tab.Screen
              key={index}
              name={tab}
              children={() => <Portfolio portfolios={portFolios} />}
            />
          );
        case 'Gigs':
          return (
            <Tab.Screen
              key={index}
              name={tab}
              children={() => (
                <Gigs
                  Gigs={gigs}
                  navigation={navigation}
                  professionalId={portfolio}
                  currency={currency}
                />
              )}
            />
          );
        case 'Reviews':
          return (
            <Tab.Screen
              key={index}
              name={tab}
              children={() => <Reviews reviews={reviews} />}
            />
          );
        default:
          return (
            <Tab.Screen
              key={index}
              name={tab}
              children={() => (
                <View>
                  <Text>Unknown Tab</Text>
                </View>
              )}
            />
          );
      }
    });
  };

  return (
    <Tab.Navigator
      screenOptions={({route}) => ({
        tabBarPressColor: 'transparent',
        tabBarLabel: ({focused}) => (
          <Text
            style={[
              styles.tabLabel,
              {
                color: focused ? Colors.sooprsblue : Colors.black,
                lineHeight: hp(4), // Match the height of the indicator for vertical centering
              },
            ]}>
            {route.name}
          </Text>
        ),
      })}>
      {renderTabScreens()}
    </Tab.Navigator>
  );
};

const styles = StyleSheet.create({
  tabLabel: {
    fontWeight: '500',
    fontSize: FSize.fs16,
  },
});

export default ProfileTabs;
