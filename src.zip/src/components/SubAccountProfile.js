import {
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import Colors from '../assets/commonCSS/Colors';
import NewHeader from './NewHeader';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import FSize from '../assets/commonCSS/FSize';
const SubAccountProfile = ({navigation, route}) => {
  const handleNavigation = (screenName, header = '', webLink = '') => {
    navigation.navigate(screenName, {header, webLink});
  };
  const {heading = '', items = [], imageIcon = ''} = route?.params || {};
  return (
    <View style={styles.container}>
      <NewHeader header={heading} navigation={navigation} />
      <ScrollView contentContainerStyle={styles.section}>
        {items?.map((item, index) => {
       // console.log("sub Item:::::",item)
          return (
            <View key={index}>
              <TouchableOpacity
                style={styles.itemContainer}
                onPress={() =>
                  handleNavigation(item?.navigateTo, item?.text, item?.WebLink)
                }>
                <Image
                  source={item?.icon}
                  style={styles.Icon}
                  resizeMode="contain"
                />
                <Text style={styles.heading}>{item?.text}</Text>
              </TouchableOpacity>
              <View style={styles.underLine} />
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
};

export default SubAccountProfile;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  Icon: {height: hp(3.5), width: wp(6), marginRight: 10},
  itemContainer: {
    marginVertical: 5,
    flexDirection: 'row',
    alignItems: 'center',
  },
  section: {
    padding: 20,
    flex: 1,
  },
  heading: {
    color: Colors.black,
    fontWeight: '500',
    fontSize: FSize.fs18,
  },
  underLine: {
    height: 0,
    width: '100%',
    borderTopWidth: 1,
    marginVertical: 10,
    borderColor: Colors.lightgrey2,
  },
});
