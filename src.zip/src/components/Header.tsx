import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  StatusBar,
  Platform,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import Images from '../assets/image';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import Colors from '../assets/commonCSS/Colors';
import FSize from '../assets/commonCSS/FSize';
import {DrawerActions, useIsFocused} from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {mobile_siteConfig} from '../services/mobile-siteConfig';

const Header = ({
  navigation,
  img,
  name,
  btnName,
  isClient,
}: {
  navigation: any;
  img: any;
  name: String;
  btnName: String;
  isClient: any;
}) => {
  const [notifications, setNotifications] = useState([]);
  const isFocused = useIsFocused();
  const [notifCount, setNotifCount] = useState(0);
  useEffect(() => {
    const fetchNotifications = async () => {
      let token = await AsyncStorage.getItem(mobile_siteConfig.TOKEN);
      let new_token = token ? JSON.parse(token) : null;

      try {
        const response = await fetch(
          'https://sooprs.com/api2/public/index.php/get-notifications',
          {
            method: 'GET',
            headers: {
              Authorization: `Bearer ${new_token}`,
            },
          },
        );
        const res = await response.json();
        if (res.status === 200) {
          setNotifications(res?.data?.reverse());
          const notificationCount = res?.data?.reduce((acc: number, item: any) => {
            if (item?.seen == 0) {
              return acc + 1;
            }
            return acc;
          }, 0);
          setNotifCount(notificationCount);
        } else {
          setNotifications([]);
          setNotifCount(0);
        }
      } catch (error) {
        console.error(error);
      }
    };
    fetchNotifications();
  }, [isFocused]);
  // navigation handler
  const handleNavigation = (screenName: string, params = {}) => {
    if (isClient) {
      // Navigate within the current client stack
      navigation.navigate(screenName, params);
    } else {
      // Professional flow
      navigation.navigate('ProfessionalStack', {screen: screenName, params});
    }
  };
  return (
    <View style={styles.header}>
      <StatusBar
        barStyle={'light-content'}
        backgroundColor={Colors.sooprsDark}
        animated
      />
      <TouchableOpacity
        onPress={() => {
          try {
            // Prefer opening the left drawer explicitly if available
            const leftDrawerParent = navigation.getParent?.('LeftDrawer');
            if (leftDrawerParent) {
              leftDrawerParent.dispatch(DrawerActions.openDrawer());
              return;
            }
            // Fallback: bubble to nearest drawer
            navigation.dispatch(DrawerActions.openDrawer());
          } catch (e) {
            // Fallback to a safe screen if no drawer is found
            try {
              navigation.navigate('ClientProfile');
            } catch (_) {
              // final fallback noop
            }
          }
        }}>
        <Image
          style={styles.Icon}
          resizeMode="contain"
          source={Images.drawer}
        />
      </TouchableOpacity>
      <Text style={styles.greetText}>Hello, {name.split(' ')[0]}</Text>
      <View style={styles.rightContainer}>
      {btnName && (
          <TouchableOpacity
            style={styles.postButton}
            onPress={() => {
              // Navigate to Post tab in ClientBottomTab (which shows PostChatSceen)
              navigation.navigate('ClientBottomTab', {screen: 'Post'});
            }}>
            <Text style={styles.postbuttonText}>{btnName}</Text>
          </TouchableOpacity>
        )}
        <TouchableOpacity
          onPress={() => handleNavigation('Notifications', {notifications})}>
          <Image
            source={Images.bellIcon}
            resizeMode="contain"
            style={styles.bellIcon}
            tintColor={Colors.sooprsDark}
          />
          
          {notifCount > 0 && (
            <View style={styles.notifBadge}>
              <Text style={styles.notifCountText}>{notifCount}</Text>
            </View>
          )}
        </TouchableOpacity>
       
      </View>
    </View>
  );
};

export default Header;

const styles = StyleSheet.create({
  header: {
    // backgroundColor: Colors.sooprsDark,
    height:Platform.OS === 'ios' ? hp(15) : hp(10),
    paddingTop:Platform.OS === 'ios' ? hp(7) : hp(0),
    flexDirection: 'row',
    paddingHorizontal: wp(5),
    alignItems: 'center',
  },
  profileIcon: {
    width: wp(10),
    height: hp(5),
    borderWidth: 2,
    borderColor: Colors.sooprsblue,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: wp(5),
    // marginBottom: wp(2),
  },
  Icon: {
    width: wp(7),
    tintColor: Colors.sooprsDark,
    height: hp(4),
  },
  hello: {
    width: wp(6),
    height: hp(5),
    marginLeft: wp(2),
  },
  greetText: {
    fontWeight: '600',
    fontSize: FSize.fs17,
    color: Colors.sooprsDark,
    marginLeft: wp(2),
  },
  rightContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 'auto', // Pushes the items to the right
    gap: wp(4),
  },
  postButton: {
    backgroundColor:Colors.sooprsDark,
    width: wp(25),
    height: hp(4),
    borderRadius: wp(2),
    justifyContent: 'center',
    alignItems: 'center',
  },
  postbuttonText: {
    color: Colors.white,
    fontSize: FSize.fs13,
    fontWeight: 'bold',
  },
  bellIcon: {
    width: wp(5),
    tintColor: Colors.sooprsDark,
    height: hp(4),
  },

  notifBadge: {
    position: 'absolute',
    top: -5,
    right: -10,
    backgroundColor: 'red',
    borderRadius: 10,
    width: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  notifCountText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
});
