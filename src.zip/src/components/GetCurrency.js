// third party api to get currency and symbol
const getCurrencyByCountryCode = async (countryCode) => {
  try {
    const response = await fetch(`https://restcountries.com/v3.1/alpha/${countryCode}`);
    const data = await response.json();

    // Extract currency information
    const currencies = data[0]?.currencies;
    if (currencies) {
      const currencyCode = Object.keys(currencies)[0]; // Get the currency code (e.g., "INR")
      const currencyDetails = currencies[currencyCode];
      const currencyName = currencyDetails?.name || 'Unknown';
      const currencySymbol = currencyDetails?.symbol || 'Unknown';

      return { currency: currencyCode, name: currencyName, symbol: currencySymbol };
    }
    return { currency: 'Unknown', name: 'Unknown', symbol: 'Unknown' };
  } catch (error) {
    console.error('Error fetching currency:', error);
    return { currency: 'Unknown', name: 'Unknown', symbol: 'Unknown' };
  }
};

export default getCurrencyByCountryCode;
