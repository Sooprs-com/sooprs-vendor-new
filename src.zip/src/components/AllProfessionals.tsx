import {
  StyleSheet,
  Text,
  View,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  Image,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import Colors from '../assets/commonCSS/Colors'; // Assuming you have a Colors file
import Images from '../assets/image';
import FSize from '../assets/commonCSS/FSize';
import CustomButton from './CustomButton';
const profileImageSize = Math.min(wp(18), hp(9));
const AllProfessionals = ({
  navigation,
  selectedService,
  searched,
  professionals = [],
  onShowMore,
  hasMore,
}: {
  navigation: any;
  selectedService: any;
  searched: any;
  professionals: [];
  onShowMore: () => void;
  hasMore: boolean;
}) => {
  const renderItem = ({item}: {item: any}) => {
    const {id, name, image, listing_about, slug} = item.data;
    const avgrating = item.avgrating;
    const services = item.services;
    const handleNavigation = () => {
      navigation.navigate('ProfessionalProfile', {id, slug});
    };
    return (
      <View>
        <TouchableOpacity style={styles.items} onPress={handleNavigation}>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Image
              source={image ? {uri: image} : Images.defaultPicIcon}
              style={styles.profilePicStyle}
            />
            <View
              style={{
                marginLeft: 12,
                width: '65%',
                justifyContent: 'space-between',
              }}>
              <View>
                <Text style={styles.nameStyle}>{name}</Text>
                <Text style={styles.designationText}>
                  {services && services[0]}
                </Text>
              </View>

              <Text style={{color: '#999999', marginTop: 8}}>
                {listing_about?.length > 50
                  ? `${listing_about.substring(0, 60)}...`
                  : listing_about}
              </Text>
            </View>
          </View>
          <View style={{justifyContent: 'space-between', alignItems: 'center'}}>
            <View style={styles.ratingContainer}>
              <Image source={Images.star} style={{height: 15, width: 15}} />
              <Text> {avgrating}</Text>
            </View>
          </View>
        </TouchableOpacity>
        <View style={styles.underLine} />
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={searched.length > 0 ? searched : professionals}
        renderItem={renderItem}
        keyExtractor={item => item.data.id.toString()} // Use a unique key for each item
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={<View style={{marginVertical: hp(1.4)}} />}
        ListFooterComponent={
          hasMore ? (
            <TouchableOpacity
              style={styles.showMoreButton}
              onPress={onShowMore}>
              <Text style={styles.showMoreText}>Show more</Text>
            </TouchableOpacity>
          ) : null
        }
      />
    </View>
  );
};

export default AllProfessionals;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  listContent: {
    paddingBottom: hp(4), // Ensure space for the footer
  },
  loader: {
    marginVertical: hp(2),
  },
  items: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: hp(1.5),
    // alignItems: 'center',
  },
  showMoreButton: {
    padding: wp(4),
    backgroundColor: '#0077FF',
    borderRadius: wp(2),
    alignItems: 'center',
    marginVertical: hp(2),
  },
  showMoreText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  noMoreText: {
    color: Colors.gray,
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: hp(2),
  },
  profilePicStyle: {
    height: profileImageSize,
    width: profileImageSize,
    borderRadius: profileImageSize / 2,
  },
  nameStyle: {
    color: Colors.black,
    fontWeight: '500',
    fontSize: FSize.fs18,
  },
  designationText: {
    color: Colors.black,
    fontWeight: '400',
    fontSize: FSize.fs15,
  },
  ratingContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  underLine: {
    height: 0,
    width: '100%',
    borderTopWidth: 0.5,
    borderColor: Colors.lightGrey,
  },
});
