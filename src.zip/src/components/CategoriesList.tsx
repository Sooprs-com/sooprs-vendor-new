import React, {useEffect, useRef, useState} from 'react';
import {StyleSheet, View, FlatList, TouchableOpacity, Text} from 'react-native';
import CategoriesCard from './CategoriesCard'; // Your card component
import {wp, hp} from '../assets/commonCSS/GlobalCSS';
import Colors from '../assets/commonCSS/Colors';

const CategoriesList = ({
  navigation,
  services,
  onSelectService,
  selectedService,
  setLoading,
  setAllData,
  setCurrentPage,
  showMore,
  activeIndex,
}) => {
  const getProfessionals = async item => {
    setCurrentPage(1);
    setLoading(true);
    onSelectService(item);
    const formdata = new FormData();
    formdata.append('dataValue', item?.catId);
    const requestOptions = {
      method: 'POST',
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      body: formdata,
    };
    try {
      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/filter_service_ajax',
        requestOptions,
      );
      const res = await response.json();
      if (res?.status == 200) {
        setAllData(res?.msg);
        showMore(res?.msg);
      }
    } catch (error) {
      console.error('Error fetching professionals:', error);
    } finally {
      setLoading(false);
    }
  };
  const renderCategories = ({item, index}) => {
    const selected = selectedService?.label == item?.label;
    return (
      <TouchableOpacity
        activeOpacity={0.6}
        style={[styles.unSelectedTabStyle, selected && styles.selectedTabStyle]}
        onPress={() => {
          getProfessionals(item);
        }}>
        <Text
          style={{
            color: selected ? Colors.black : '#999999',
            fontWeight: '400',
          }}>
          {item?.label}
        </Text>
      </TouchableOpacity>
    );
  };
  
  return (
    <View style={styles.container}>
      <View>
        <FlatList
          data={services} // Use services data
          renderItem={renderCategories}
          keyExtractor={(item, index) => index.toString()}
          horizontal
          showsHorizontalScrollIndicator={false}
          onScrollToIndexFailed={()=>{console.log('falied auto scroll')}}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  unSelectedTabStyle: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderWidth: 1.5,
    marginRight: 10,
    borderRadius: 30,
    borderColor: Colors.lightGrey,
  },
  selectedTabStyle: {
    backgroundColor: Colors.sooprslight,
    borderWidth: 1.5,
    borderColor: Colors.sooprsblue,
  },
});

export default CategoriesList;
