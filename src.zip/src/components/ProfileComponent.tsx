import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  Alert,
} from 'react-native';
import React, {useState} from 'react';
import {wp, hp} from '../assets/commonCSS/GlobalCSS';
import Images from '../assets/image';
import Colors from '../assets/commonCSS/Colors';
import FSize from '../assets/commonCSS/FSize';
const size = Math.min(wp(24), hp(12));
const ProfileComponent = ({
  navigation,
  img,
  name,
  role,
  rating,
}: {
  navigation: any;
  img: any;
  name: any;
  role: any;
  rating: any;
}) => {
  return (
    <View style={styles.profileSection}>
      <View style={{alignItems: 'center'}}>
        <Image
          source={img ? {uri: img} : Images.defaultPicIcon}
          style={styles.Icon}
        />
        <Text style={styles.profileName}>{name}</Text>
        <Text style={styles.profileRole}>{role}</Text>
      </View>
      {/* <View style={styles.rowContainer}>
        {detailsArray.map((item, index) => (
          <View style={styles.row} key={index}>
            <Text style={styles.profileRole}>{item.title}</Text>
            <Text style={{color: Colors.black}}>{item.value}</Text>
          </View>
        ))}
      </View> */}
    </View>
  );
};
export default ProfileComponent;
const styles = StyleSheet.create({
  profileSection: {
    marginTop: hp(5),
  },
  backArrow: {
    width: wp(8),
    height: hp(8),
    marginLeft: wp(2),
  },
  profile: {
    flexDirection: 'row',
    marginHorizontal: wp(4.5),
    marginBottom: hp(2),
    // marginVertical: hp(4),
    alignItems: 'center',
    gap: wp(5),
  },
  Icon: {
    width: size,
    height: size,
    borderRadius: size / 2,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  rowContainer: {
    width: wp(90),
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    borderRadius: 8,
    alignSelf: 'center',
    marginVertical: hp(2),
  },
  profileContainer: {
    // flexDirection: 'row',
    // alignItems: 'center',
  },

  starIcon: {
    width: wp(4),
    height: hp(4),
  },
  rating: {
    fontSize: FSize.fs12,
    color: Colors.black,
  },
  profileName: {
    fontSize: FSize.fs20,
    fontWeight: '600',
    color: Colors.black,
  },
  profileRole: {
    fontSize: FSize.fs14,
    fontWeight: '500',
    color: Colors.gray,
    maxWidth: '80%',
  },

  ratings: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
});
