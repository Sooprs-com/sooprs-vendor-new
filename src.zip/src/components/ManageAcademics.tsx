import React, {useEffect, useState} from 'react';
import {
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import Colors from '../assets/commonCSS/Colors';
import FSize from '../assets/commonCSS/FSize';
import Images from '../assets/image';
import ButtonNew from './ButtonNew';
import Toast from 'react-native-toast-message';
import {useIsFocused} from '@react-navigation/native';
import NewHeader from './NewHeader';
import {useDispatch, useSelector} from 'react-redux';
import {getDataWithToken} from '../services/mobile-api';
import {mobile_siteConfig} from '../services/mobile-siteConfig';
import {setUserDetails} from '../Redux/Actions';
import CustomButton from './CustomButton';
const ManageAcademics = ({navigation}: {navigation: any}) => {
  const getUserDetails = useSelector(state => state?.getUserDetails);
  const [academics, setAcademics] = useState(
    getUserDetails?.academic_details ?? [],
  );
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);
  const isFocused = useIsFocused();

  useEffect(() => {
    setAcademics(getUserDetails?.academic_details);
  }, [isFocused]);
  const removeAcademics = async acId => {
    const formData = new FormData();
    formData.append('exp_id', acId);
    try {
      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/delete_academics',
        {
          method: 'POST',
          body: formData,
        },
      );

      const res = await response.json();

      if (res.status === 200) {
        console.log('portfolio data fetched:::::::::::', res.msg);
        setAcademics(prev => {
          return prev.filter(item => item.id != acId);
        });
        getUserData(res?.msg);
      } else if (res.status === 400) {
        Toast.show({
          type: 'error',
          text1: res.msg,
        });
      }
    } catch (error) {
      console.log('Error fetching portfolio:', error);
      Toast.show({
        type: 'error',
        text1: 'Something went wrong!',
      });
    }
  };
  // update the data
  const getUserData = async msg => {
    try {
      const response = await getDataWithToken(mobile_siteConfig.USER_DETAILS);
      if (response?.status == 200) {
        dispatch(setUserDetails(response?.data));
        Toast.show({
          type: 'success',
          text1: 'Success',
          text2: msg,
        });
      }
    } catch (error) {
      console.log('error in gettting user details', error);
    } finally {
    }
  };
  const renderAcademicCard = ({item}) => (
    <View style={styles.card}>
      <TouchableOpacity
        style={{position: 'absolute', right: 16, top: 16, zIndex: 999}}
        onPress={() => removeAcademics(item?.id)}>
        <Image source={Images.deleteIcon} style={{height: 25, width: 25}} />
      </TouchableOpacity>
      <Text style={styles.courseText}>{item.course}</Text>
      <View style={styles.detailsContainer}>
        <Text style={styles.label}>Institute:</Text>
        <Text style={styles.value}>{item.institute}</Text>
      </View>
      <View style={styles.detailsContainer}>
        <Text style={styles.label}>University:</Text>
        <Text style={styles.value}>{item.university}</Text>
      </View>
      <View style={styles.detailsContainer}>
        <Text style={styles.label}>Years:</Text>
        <Text style={styles.value}>{item.years}</Text>
      </View>
      <View style={styles.detailsContainer}>
        <Text style={styles.label}>Percentage:</Text>
        <Text style={styles.value}>{item.percentage}%</Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <NewHeader header={'Manage Academics'} navigation={navigation} />
      {loading ? (
        <ActivityIndicator
          size="large"
          color={Colors.primary}
          style={{flex: 1}}
        />
      ) : (
        <FlatList
          data={academics}
          keyExtractor={item => item.id.toString()}
          renderItem={renderAcademicCard}
          contentContainerStyle={styles.listContainer}
          ListEmptyComponent={
            <Image
              source={Images.emptyAcademics}
              style={{
                height: hp(40),
                width: wp(65),
                alignSelf: 'center',
                marginTop: hp(10),
              }}
              resizeMode="contain"
            />
          }
        />
      )}
      <View style={styles.title}>
        <CustomButton
          buttonText="Add Academics"
          onButtonPress={() => navigation.navigate('AddAcademics')}
          buttonStyle={{width:wp(90)}}
        />
        {/* <ButtonNew
          imgSource={null}
          btntext="Add Academics"
          bgColor="#0077FF"
          textColor="#FFFFFF"
          onPress={() => navigation.navigate('AddAcademics')}
          isBorder={true}
        /> */}
      </View>
    </View>
  );
};

export default ManageAcademics;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  headerSection: {
    marginHorizontal: wp(5),
    marginVertical: hp(1),
    flexDirection: 'row',
    alignItems: 'center',
    gap: wp(2),
  },
  backArrow: {
    width: wp(8),
    height: hp(8),
  },
  headerTitle: {
    color: Colors.black,
    fontWeight: '500',
    fontSize: FSize.fs16,
  },
  title: {
    // marginHorizontal: wp(5),
    // marginVertical: hp(2),
    position: 'absolute',
    bottom: hp(2),
    alignSelf: 'center',
  },
  listContainer: {
    paddingHorizontal: wp(5),
    paddingBottom: hp(8),
  },
  card: {
    backgroundColor: Colors.white,
    borderRadius: 15,
    padding: wp(5),
    marginVertical: hp(1.5),
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 5},
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 6,
    borderLeftWidth: 5,
    borderColor: Colors.sooprsblue,
  },
  courseText: {
    fontSize: FSize.fs20,
    fontWeight: 'bold',
    color: Colors.primary,
    marginBottom: hp(1),
  },
  detailsContainer: {
    flexDirection: 'row',
    marginBottom: hp(0.8),
  },
  label: {
    fontWeight: '600',
    color: Colors.gray,
    width: wp(30),
  },
  value: {
    color: Colors.black,
    flex: 1,
  },
  emptyText: {
    textAlign: 'center',
    color: Colors.gray,
    marginTop: hp(35),
    fontSize: FSize.fs14,
  },
});
