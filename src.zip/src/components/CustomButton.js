import React from 'react';
import {
  ActivityIndicator,
  StyleSheet,
  Text,
  TouchableOpacity,
} from 'react-native';
import Colors from '../assets/commonCSS/Colors';
import {wp} from '../assets/commonCSS/GlobalCSS';

const CustomButton = ({
  buttonText = 'Button',
  onButtonPress,
  buttonStyle,
  textStyle,
  loading,
}) => {
  return (
    <TouchableOpacity
      style={[styles.button, {...buttonStyle}]}
      disabled={loading}
      onPress={onButtonPress}
      activeOpacity={0.8}>
      {loading ? (
        <ActivityIndicator color={Colors.white} size={20} />
      ) : (
        <Text style={[styles.text, textStyle]}>{buttonText}</Text>
      )}
    </TouchableOpacity>
  );
};

export default CustomButton;

const styles = StyleSheet.create({
  button: {
    backgroundColor: Colors.sooprsblue,
    paddingVertical: 12,
    paddingHorizontal: 20,
    width: wp(95),
    alignSelf: 'center',
    borderRadius: 4,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
