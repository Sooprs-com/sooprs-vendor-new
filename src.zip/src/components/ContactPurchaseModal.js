import AsyncStorage from '@react-native-async-storage/async-storage';
import {useState} from 'react';
import {
  ActivityIndicator,
  Image,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Toast from 'react-native-toast-message';
import Images from '../assets/image';
import ButtonNew from './ButtonNew';
import Colors from '../assets/commonCSS/Colors';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import {mobile_siteConfig} from '../services/mobile-siteConfig';

const ContactModal = ({
  projectId,
  visible,
  setVisible,
  onClose,
  preBidCost,
  contactSeenOnChat,
  navigation,
}) => {
  console.log('c', contactSeenOnChat);
  const [loading, setLoading] = useState(false); // Track loading state
  const [cost, setCost] = useState(preBidCost);
  const [mobile, setMobile] = useState('+91******33');
  const [btnVisible, setbtnVisible] = useState(!contactSeenOnChat);
  const getContactDetails = async () => {
    if (loading) return; // Prevent multiple clicks while loading
    setLoading(true); // Start loading spinner

    try {
      // Retrieve the token from AsyncStorage
      let token = await AsyncStorage.getItem(mobile_siteConfig.TOKEN);
      let new_token = JSON.parse(token);
      // Prepare form data
      const formData = new FormData();
      formData.append('id', projectId);
      // Make the API call
      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/show-lead-mobile',
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${new_token}`, // Send token in the authorization header
          },
          body: formData,
        },
      );

      // Parse the response
      const result = await response.json();
      if (result.status === 200) {
        // Decrypt the mobile number received from the API
        setMobile(result.encrypted_mobile_number);
        if (result?.price) {
          setCost(result?.price);
        }
        Toast.show({
          type: 'success', // Type of the toast (could also be 'success', 'info', etc.)
          text1: 'Success', // Main message
          text2: 'Contact number is visible now', // Secondary message
          position: 'top', // Position of the toast
          visibilityTime: 1500, // Duration for which the toast will be visible
          text1Style: {fontSize: 16, fontWeight: '600'},
          text2Style: {fontSize: 14, color: '#666'},
        });
        setbtnVisible(false); // Hide the button after successful fetch
      } else {
        onClose();
        Toast.show({
          type: 'error',
          text1: 'Error',
          text2: result.msg,
          position: 'top', // Position of the toast
          visibilityTime: 1500, // Duration for which the toast will be visible
          text1Style: {fontSize: 16, fontWeight: '600'},
          text2Style: {fontSize: 14, color: '#666'},
        });
      }
    } catch (error) {
      onClose();
      Toast.show({
        type: 'error', // Type of the toast (could also be 'success', 'info', etc.)
        text1: 'Network issue',
        position: 'top', // Position of the toast
        visibilityTime: 1500, // Duration for which the toast will be visible
        text1Style: {fontSize: 16, fontWeight: '600'},
        text2Style: {fontSize: 14, color: '#666'},
      });
      console.error('Error fetching contact details:', error, projectId);
    } finally {
      setLoading(false); // Stop loading spinner
    }
  };
  const handleNavigation = (screenName, params = {}) => {
    navigation.navigate('AccountStack', {screen: screenName, params});
  };
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={visible}
      onRequestClose={onClose}>
      <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
          {/* Cross Icon */}
          <TouchableOpacity style={styles.closeButton} onPress={onClose}>
            <Image
              source={Images.crossIcon}
              style={styles.closeIcon}
              resizeMode="contain"
            />
          </TouchableOpacity>

          {/* Modal Title */}
          <Text style={styles.modalTitle}>Contact Details</Text>

          {/* Contact Info */}
          <View style={styles.contactInfo}>
            <Text style={styles.contactText}>Phone: {mobile}</Text>
          </View>

          {/* Credit Cost Info */}
          <View style={styles.creditCostInfo}>
            <Text style={styles.creditCostText}>{`Credit Cost: ${cost}`}</Text>
          </View>

          {/* Button */}
          <ButtonNew
            imgSource={undefined}
            btntext={
              loading ? (
                <ActivityIndicator color={Colors.white} />
              ) : (
                'Get Contact'
              )
            }
            bgColor={!btnVisible ? Colors.lightgrey2 : Colors.sooprsblue}
            textColor={!btnVisible ? '#999999' : Colors.white}
            onPress={getContactDetails}
            isDisabled={!btnVisible || loading} // Disable button while loading
          />
          {!btnVisible && (
            <Text
              style={{
                color: Colors.sooprsblue,
                textDecorationLine: 'underline',
                textAlign: 'center',
              }}
              onPress={() => {
                setVisible(false);
                handleNavigation('ContactDetails', {inProfileSection: true});
              }}>
              View purchased contacts
            </Text>
          )}
        </View>
      </View>
    </Modal>
  );
};
const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: wp(80),
    backgroundColor: Colors.white,
    borderRadius: 10,
    padding: 20,
    gap: hp(2),
    // alignItems: 'center',
  },
  closeButton: {
    position: 'absolute',
    top: 10,
    right: 20,
    padding: 10,
    zIndex: 999,
  },
  closeIcon: {
    width: 25,
    height: 25,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.sooprsblue,
    marginBottom: 20,
  },
  contactDetail: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  contactText: {
    fontSize: 16,
    color: Colors.black,
  },
  creditCostInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  creditCostText: {
    fontSize: 16,
    color: Colors.sooprsblue,
  },
  price: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.sooprsblue,

    // alignSelf:'flex-end'
  },
});
export default ContactModal;
