import React, {useRef, useState} from 'react';
import {
  View,
  StyleSheet,
  Text,
  TouchableOpacity,
  Image,
  FlatList,
  Dimensions,
} from 'react-native';
import {hp} from '../assets/commonCSS/GlobalCSS';
import Images from '../assets/image';
import Colors from '../assets/commonCSS/Colors';

const {width} = Dimensions.get('window');

const Carousel = ({carouselData = [], onImagePress}) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const flatListRef = useRef(null);

  const onViewableItemsChanged = ({viewableItems}) => {
    if (viewableItems.length > 0) {
      setActiveIndex(viewableItems[0].index);
    }
  };
  const renderItem = ({item}) => (
    <TouchableOpacity
      style={styles.card}
      onPress={onImagePress}
      activeOpacity={0.8}>
      <Image source={item.image} style={styles.image} resizeMode="contain" />
    </TouchableOpacity>
  );

  return (
    <View style={{marginVertical: 10}}>
      <FlatList
        ref={flatListRef}
        data={carouselData}
        renderItem={renderItem}
        keyExtractor={(item, index) => String(index)}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{alignItems: 'center'}}
        snapToAlignment="center"
        decelerationRate="fast"
        onViewableItemsChanged={onViewableItemsChanged}
        scrollEnabled={carouselData?.length > 1}
      />
      <View style={styles.dotContainer}>
        {carouselData?.length > 1 &&
          carouselData.map((_, index) => (
            <View
              key={index}
              style={[
                styles.dot,
                activeIndex === index ? styles.activeDot : styles.inactiveDot,
              ]}
            />
          ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    width: width * .9,
    borderRadius: 10,
    overflow: 'hidden',
    marginHorizontal: (width * 0.1) / 2,
  },
  image: {
    width: '100%',
    height: 190,
  },

  dotContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 10,
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginHorizontal: 4,
  },
  activeDot: {
    backgroundColor: Colors.gray,
  },
  inactiveDot: {
    backgroundColor: Colors.lightGrey,
  },
});

export default Carousel;
