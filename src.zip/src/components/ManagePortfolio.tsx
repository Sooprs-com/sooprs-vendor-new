import {
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  FlatList,
  Linking,
  ScrollView,
} from 'react-native';
import React, {useState, useEffect} from 'react';
import Colors from '../assets/commonCSS/Colors';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import FSize from '../assets/commonCSS/FSize';
import Images from '../assets/image';
import ButtonNew from './ButtonNew';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Toast from 'react-native-toast-message';
import {useIsFocused} from '@react-navigation/native';
import Icons from './Icons';
import {getDataWithToken, postData} from '../services/mobile-api';
import NewHeader from './NewHeader';
import {useDispatch, useSelector} from 'react-redux';
import {mobile_siteConfig} from '../services/mobile-siteConfig';
import {setUserDetails} from '../Redux/Actions';

const ManagePortfolio = ({navigation}: {navigation: any}) => {
  const getUserDetails = useSelector(state => state?.getUserDetails);
  const [portfolioData, setPortfolioData] = useState([]);
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  useEffect(() => {
    setPortfolioData(getUserDetails?.portfolio_details);
  }, [isFocused]);
  const removePortFolio = async pId => {
    const formData = new FormData();
    formData.append('id', pId);

    try {
      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/remove_portfolio',
        {
          method: 'POST',
          body: formData,
        },
      );

      const res = await response.json();

      if (res.status === 200) {
        console.log('portfolio data fetched:::::::::::', res.msg);
        setPortfolioData(prev => {
          return prev.filter(item => item.id != pId);
        });
        getUserData(res?.msg);
      } else if (res.status === 400) {
        Toast.show({
          type: 'error',
          text1: res.msg,
        });
      }
    } catch (error) {
      console.log('Error fetching portfolio:', error);
      Toast.show({
        type: 'error',
        text1: 'Something went wrong!',
      });
    }
  };
  // update data
  const getUserData = async msg => {
    try {
      const response = await getDataWithToken(mobile_siteConfig.USER_DETAILS);
      if (response?.status == 200) {
        dispatch(setUserDetails(response?.data));
        Toast.show({
          type: 'success',
          text1: 'Success',
          text2: msg,
        });
      }
    } catch (error) {
      console.log('error in gettting user details', error);
    } finally {
    }
  };
  const handleLinkPress = (url: string) => {
    if (url) {
      Linking.openURL(url);
    } else {
      Toast.show({
        type: 'error',
        text1: 'Invalid URL',
      });
    }
  };

  const renderPortfolioItem = ({item}: {item: any}) => {
    return (
      <TouchableOpacity
        style={styles.card}
        onPress={() => handleLinkPress(item.link)}
        activeOpacity={0.8}>
        <TouchableOpacity
          style={{right: 16, zIndex: 999, position: 'absolute', top: 12}}
          onPress={() => removePortFolio(item?.id)}>
          <Image
            source={Images.crossIcon}
            style={{height: 25, width: 25}}
            resizeMode="contain"
            tintColor={Colors.sooprsblue}
          />
        </TouchableOpacity>
        <Image
          source={{
            uri: `https://sooprs.com/assets/portfolio-images/${item.files}`,
          }}
          style={styles.image}
          resizeMode="cover"
        />
        <Text style={styles.name}>{item.title}</Text>
        <Text style={styles.role}>{item.description}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <View style={{flex: 1, backgroundColor: Colors.white}}>
      <NewHeader header={'Manage Portfolio'} navigation={navigation} />
      <ScrollView
        contentContainerStyle={styles.container}
        showsVerticalScrollIndicator={false}>
        <FlatList
          data={portfolioData}
          renderItem={renderPortfolioItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.portfolioList}
          showsVerticalScrollIndicator={false}
          nestedScrollEnabled={true}
          ListEmptyComponent={
            <Image
              source={Images.emptyPortfolio}
              style={{
                height: hp(40),
                width: wp(65),
                alignSelf: 'center',
                marginTop: hp(10),
              }}
              resizeMode="contain"
            />
          }
        />
        <View style={styles.title}>
          <ButtonNew
            imgSource={null}
            btntext="Add Portfolio"
            bgColor="#0077FF"
            textColor="#FFFFFF"
            onPress={() => navigation.navigate('AddPortfolio')}
            isBorder={true}
          />
        </View>
      </ScrollView>
    </View>
  );
};

export default ManagePortfolio;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
    paddingVertical: hp(4),
  },
  headerSection: {
    marginHorizontal: wp(5),
    marginVertical: hp(1),
    flexDirection: 'row',
    alignItems: 'center',
    gap: wp(2),
  },
  backArrow: {
    width: wp(8),
    height: hp(8),
  },
  headerTitle: {
    color: Colors.black,
    fontWeight: '500',
    fontSize: FSize.fs16,
  },
  title: {
    marginHorizontal: wp(5),
    marginVertical: hp(2),
  },
  portfolioList: {
    marginHorizontal: wp(5),
  },
  card: {
    backgroundColor: Colors.white,
    borderRadius: 10,
    width: wp(90),
    marginVertical: 15,
    borderWidth: 0.5,
    borderColor: '#ccc',
    overflow: 'hidden', // Prevent overflow
  },
  imgBack: {
    width: '100%',
    height: '50%',
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: hp(22),
    zIndex: -1,
  },
  info: {
    marginVertical: hp(1),
    marginHorizontal: wp(2),
    flexDirection: 'column',
    gap: 2,
    height: hp(5),
    justifyContent: 'flex-start',
    flexShrink: 1, // Allow info to shrink if there's too much content
  },
  name: {
    fontSize: FSize.fs18,
    fontWeight: 'bold',
    color: Colors.black,
    paddingHorizontal: 16,
    marginVertical: 10,
  },
  role: {
    fontSize: FSize.fs12,
    color: Colors.gray,
    flexWrap: 'wrap', // Ensure long text wraps
  },
  link: {
    fontSize: FSize.fs12,
    color: '#0077FF',
    textDecorationLine: 'underline',
    marginTop: hp(0.5),
  },
});
