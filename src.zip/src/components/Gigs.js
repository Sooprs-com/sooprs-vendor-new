import {
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import Colors from '../assets/commonCSS/Colors';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import FSize from '../assets/commonCSS/FSize';
import Images from '../assets/image';

const Gigs = ({Gigs = [], navigation, professionalId, currency}) => {
  const symbol = () => {
    const symbol = currency == 'INR' ? '₹' : '$';
    return `${symbol}`;
  };
  const renderPortfolioItem = ({item, index}) => {
    return (
      <TouchableOpacity
        style={styles.card}
        activeOpacity={0.8}
        key={index}
        onPress={() =>
          navigation.navigate('GigDetails', {item, professionalId})
        }>
        <Image
          source={{
            uri: `https://sooprs.com/assets/files/${item.gig_img}`,
          }}
          style={styles.image}
          resizeMode="cover"
        />
        <Text style={styles.name}>{item?.gig_title}</Text>
        <View style={styles.details}>
          <View style={styles.ratingContainer}>
            {Array.from({length: 5}, (_, index) => (
              <Image
                source={Images.star}
                style={[
                  styles.star,
                  index < Number(item?.rating) && styles.filledStar,
                ]}
                resizeMode="contain"
              />
            ))}
          </View>
          <Text style={styles.price}>
            {symbol()}
            {item?.gig_price}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };
  return (
    <View style={styles.container}>
      <FlatList
        data={Gigs}
        renderItem={renderPortfolioItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.portfolioList}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <Text
            style={{
              color: Colors.black,
              textAlign: 'center',
              marginTop: hp(10),
            }}>
            No gigs found
          </Text>
        }
      />
    </View>
  );
};

export default Gigs;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  card: {
    alignSelf: 'center',
    backgroundColor: Colors.white,
    borderRadius: 10,
    width: wp(90),
    marginVertical: 15,
    borderWidth: 0.5,
    borderColor: '#ccc',
    overflow: 'hidden', // Prevent overflow
  },
  name: {
    color: '#444444',
    fontWeight: '500',
    fontSize: FSize.fs18,
    padding: 8,
  },
  image: {
    width: '100%',
    height: hp(22),
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    alignItems: 'center',
  },
  star: {
    height: 17,
    width: 17,
    marginRight: 4,
  },
  price: {
    color: Colors.sooprsblue,
    fontSize: FSize.fs20,
    fontWeight: '700',
  },
  details: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 8,
    alignItems: 'center',
  },
  filledStar: {
    color: '#F4DE25',
  },
});
