import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  SectionList,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import Colors from '../assets/commonCSS/Colors';
import FSize from '../assets/commonCSS/FSize';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import Images from '../assets/image';
const imageSize = Math.min(wp(8), hp(4));

const UserDetails = ({
  about,
  services = [],
  skills = [],
  education = [],
  experience = [],
}) => {
  if (
    !about &&
    !(services?.length > 0) &&
    !(skills?.length > 0) &&
    !(education?.length > 0) &&
    !(experience?.length > 0)
  ) {
    return (
      <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
        <Text style={{color: Colors.black}}>No data found</Text>
      </View>
    );
  }
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{paddingBottom: hp(6)}}
      showsVerticalScrollIndicator={false}>
      {about && (
        <View style={{marginBottom: 16}}>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Image
              source={Images.about}
              style={{height: imageSize, width: imageSize, marginRight: 8}}
            />
            <Text style={styles.headerText}>About</Text>
          </View>
          <Text style={{color: Colors.black, marginLeft: 6}}>{about}</Text>
        </View>
      )}
      {services?.length && (
        <View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              marginBottom: 7,
            }}>
            <Image
              source={Images.services}
              style={{height: imageSize, width: imageSize, marginRight: 8}}
            />
            <Text style={styles.headerText}>Services</Text>
          </View>
          <View style={styles.servicesContainer}>
            {services?.map((service, index) => (
              <View key={index} style={styles.serviceItem}>
                <Text style={styles.serviceText}>{service}</Text>
              </View>
            ))}
          </View>
        </View>
      )}
      {experience?.length > 0 && (
        <View>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Image
              source={Images.experience}
              style={{height: imageSize, width: imageSize, marginRight: 8}}
            />
            <Text style={styles.headerText}>Experience</Text>
          </View>
          {experience?.map((item, index) => (
            <View style={styles.card} key={index}>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'flex-start',
                  width: '65%',
                }}>
                <Text style={styles.designation}>{item.designation}</Text>
                <Text style={styles.organization}> - {item.organization}</Text>
              </View>
              <Text style={styles.date}>
                {item.from_date?.replace(/-/g, '/')} -{' '}
                {item.to_date?.replace(/-/g, '/')}
              </Text>
            </View>
          ))}
        </View>
      )}
      {education?.length > 0 && (
        <View>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Image
              source={Images.education}
              style={{height: imageSize, width: imageSize, marginRight: 8}}
            />
            <Text style={styles.headerText}>Education</Text>
          </View>
          {education.map((item, index) => {
            return (
              <View style={styles.card} key={index}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    width: '85%',
                  }}>
                  <Text style={styles.designation}>{item.course}</Text>
                  <Text
                    style={
                      styles.organization
                    }>{` (${item.percentage}%)`}</Text>
                </View>
                <Text style={styles.organization}>{item.institute}</Text>
              </View>
            );
          })}
        </View>
      )}
    </ScrollView>
  );
};

export default UserDetails;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    backgroundColor: Colors.white,
  },
  card: {
    flex: 1,
    backgroundColor: Colors.white, // Changed to white for better visibility
    borderWidth: 1,
    borderColor: '#ccc',
    marginVertical: 8,
    padding: 8,
    borderRadius: 10,
    paddingHorizontal: 12,
  },
  servicesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    alignSelf: 'center',
  },
  serviceItem: {
    flexBasis: '48%',
    marginBottom: 10,
    backgroundColor: '#f5f5f5',
    padding: 10,
    borderRadius: 8,
  },
  designation: {
    fontSize: FSize.fs18,
    fontWeight: 'bold',
    color: Colors.black, // Made it bold for emphasis
  },
  organization: {
    fontSize: FSize.fs14,
    color: Colors.gray,
    alignSelf: 'flex-start',
  },
  date: {
    fontSize: FSize.fs12,
    color: Colors.gray,
    marginTop: hp(1),
  },
  serviceText: {
    color: Colors.black,
    textAlign: 'center',
  },
  headerText: {
    fontSize: FSize.fs20,
    fontWeight: 'bold',
    color: '#444444',
    marginVertical: 14,
  },
});
