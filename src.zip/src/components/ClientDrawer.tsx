import {createDrawerNavigator} from '@react-navigation/drawer';
import React from 'react';
import {Dimensions, ScrollView} from 'react-native';
import {useSelector} from 'react-redux';
import ClientHome from '../UserScreens/Home/ClientHome';
import ClientAccount from '../UserScreens/Account/Account';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Notifications from './Notifications';
import ClientProfile from '../UserScreens/Profile/ClientProfile';
import ProjectPosting from '../UserScreens/Projects/ProjectPosting';
import Projects from '../UserScreens/TabView/Projects';
import IndividualChat from './IndividualChat';
import ProjectBids from '../UserScreens/Projects/ProjectBids';
import ProjectStatus from './ProjectStatus';
import Professionals from '../UserScreens/Professionals/Professionals';
import ProfessionalProfile from '../UserScreens/Profile/ProfessionalProfile';
import GigDetails from '../UserScreens/Gigs/GigDetails';

const MainDrawer = createDrawerNavigator();
const {width} = Dimensions.get('window');

const ClientStack = createNativeStackNavigator();

const ClientStackNavigator = () => {
  return (
    <ClientStack.Navigator screenOptions={{headerShown: false}}>
      <ClientStack.Screen name="ClientHome" component={ClientHome} />
      <ClientStack.Screen name="Notifications" component={Notifications} />
      <ClientStack.Screen name="ClientProfile" component={ClientProfile} />
      <ClientStack.Screen name="ProjectPosting" component={ProjectPosting} />
      <ClientStack.Screen name="ProjectsScreen" component={Projects} />
      <ClientStack.Screen name="IndividualChat" component={IndividualChat} />
      <ClientStack.Screen name="ProjectBids" component={ProjectBids} />
      <ClientStack.Screen name="ProjectStatus" component={ProjectStatus} />
      <ClientStack.Screen name="ProfessionalsScreen" component={Professionals} />
      <ClientStack.Screen name="ProfessionalProfile" component={ProfessionalProfile} />
      {/* <ClientStack.Screen name="CategoriesList" component={CategoriesList} /> */}
      <ClientStack.Screen name="GigDetails" component={GigDetails} />
    </ClientStack.Navigator>
  );
};

const ScrollableDrawerContent = ({children}) => {
  return (
    <ScrollView
      contentContainerStyle={{flexGrow: 1}}
      showsVerticalScrollIndicator={false}>
      {children}
    </ScrollView>
  );
};

const ClientDrawer = () => {
  return (
    <MainDrawer.Navigator
      id="LeftDrawer"
      screenOptions={{
        headerShown: false,
        drawerPosition: 'left',
        drawerStyle: {width: width * 0.85, overflow: 'hidden'},
      }}
      drawerContent={props => (
        <ScrollableDrawerContent>
          <ClientAccount {...props} />
        </ScrollableDrawerContent>
      )}>
      <MainDrawer.Screen
        name="ClientHomeScreen"
        component={ClientStackNavigator}
      />
    </MainDrawer.Navigator>
  );
};

export default ClientDrawer;
