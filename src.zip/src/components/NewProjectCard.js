import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import {wp} from '../assets/commonCSS/GlobalCSS';
import Colors from '../assets/commonCSS/Colors';
import FSize from '../assets/commonCSS/FSize';
import he from 'he';
import Images from '../assets/image';
import moment from 'moment';
// show limited description
const decodeHtmlEntities = str => {
  return he.decode(str);
};
const getLimitedDescription = description => {
  const limit = 150; // Set character limit
  const newDesc = decodeHtmlEntities(description);
  return newDesc?.length > limit
    ? `${newDesc.substring(0, limit)}...`
    : newDesc;
};
const formatDate = dateString => {
  const parsedDate = moment(dateString?.split([' '])[0], 'YYYY-MM-DD');
  return parsedDate.isValid() ? parsedDate.format('DD-MMM-YYYY') : ' ';
};

const NewProjectCard = ({
  item,
  index,
  onCardPress,
  hideBidCount = false,
  hidePostedDate = false,
  currency = 'USD',
}) => {
  const priceText = (min, max) => {
    const symbol = currency == 'INR' ? '₹' : '$';
    return `${symbol}${min} - ${symbol}${max}`;
  };
  return (
    <TouchableOpacity
      style={styles.container}
      activeOpacity={0.7}
      onPress={onCardPress}>
      <Text style={styles.titleStyle}>
        {decodeHtmlEntities(item.project_title)}
      </Text>
      <Text style={styles.serviceContainer}>
        {item.service_name ?? item['service-name']}
      </Text>
      <Text style={styles.descStyle}>
        {getLimitedDescription(item.description)}
      </Text>
      <View style={styles.withDateContainer}>
        {!hidePostedDate && (
          <Text style={styles.dateText}>
            {formatDate(item?.formatCreatedAt ?? item?.created_at)}
          </Text>
        )}
        <View style={{alignItems: 'flex-end', alignSelf: 'flex-end'}}>
          {!hideBidCount && (
            <Text style={styles.bidText}>{item.bid_count} bids placed</Text>
          )}
          <View style={styles.priceContainer}>
            <Image
              source={Images.wallet}
              style={{height: 25, width: 25}}
              resizeMode="contain"
            />
            <Text style={styles.priceText}>
              {priceText(item?.min_budget, item?.max_budget_amount)}
            </Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default NewProjectCard;

const styles = StyleSheet.create({
  container: {
    width: wp(95),
    backgroundColor: Colors.white,
    borderWidth: 0.8,
    borderColor: '#ccc',
    marginVertical: 5,
    paddingVertical: 14,
    paddingHorizontal: 18,
    borderRadius: 10,
  },
  titleStyle: {
    color: '#444444',
    fontSize: FSize.fs18,
    fontWeight: '700',
    width: '90%',
  },
  serviceContainer: {
    color: '#444444',
    backgroundColor: '#F2F7FF',
    alignSelf: 'flex-start',
    marginVertical: 14,
    padding: 8,
    borderRadius: 4,
    fontWeight: '500',
    fontSize: FSize.fs13,
  },
  descStyle: {color: '#444444'},
  priceText: {
    color: Colors.sooprsblue,
    fontSize: FSize.fs18,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
  },
  withDateContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  dateText: {color: '#444444', fontSize: FSize.fs13},
  bidText: {
    color: '#444444',
    fontWeight: '500',
  },
});
