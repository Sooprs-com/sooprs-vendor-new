import {StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import {wp} from '../assets/commonCSS/GlobalCSS';
import Colors from '../assets/commonCSS/Colors';

const NewButton = ({onPress, text}) => {
  return (
    <TouchableOpacity style={styles.buttonStyle} onPress={onPress}>
      <Text style={{color: Colors.white, fontSize: 16, fontWeight: '500'}}>
        {text ?? 'NewButton'}
      </Text>
    </TouchableOpacity>
  );
};

export default NewButton;

const styles = StyleSheet.create({
  buttonStyle: {
    width: wp(90),
    backgroundColor: Colors.sooprsblue,
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 12,
    borderRadius: 10,
  },
});
