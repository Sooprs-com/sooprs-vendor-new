import {
  FlatList,
  Image,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
  ScrollView,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import Colors from '../assets/commonCSS/Colors';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import FSize from '../assets/commonCSS/FSize';
import Images from '../assets/image';
import ButtonNew from './ButtonNew';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Toast from 'react-native-toast-message';
import {useIsFocused} from '@react-navigation/native';
import NewHeader from './NewHeader';
import NewButton from './NewButton';
import {useDispatch, useSelector} from 'react-redux';
import {getDataWithToken} from '../services/mobile-api';
import {mobile_siteConfig} from '../services/mobile-siteConfig';
import {setUserDetails} from '../Redux/Actions';

const AddSkills = ({navigation, route}: {navigation: any; route: any}) => {
  const getUserDetails = useSelector(state => state?.getUserDetails);
  const skillsList =
    getUserDetails?.skills?.map(item => ({
      id: item?.skill_id,
      skill_name: item?.skill_name,
    })) ?? [];
  const dispatch = useDispatch();
  const [visible, setVisible] = useState(false);
  const [skills, setSkills] = useState([]); // Skills from API
  const [selectedSkill, setSelectedSkill] = useState(null); // Selected skill
  const [skillId, setSkillId] = useState(null);
  const [addedSkills, setAddedSkills] = useState(skillsList);
  const [userId, setUserId] = useState(null);
  const isFocused = useIsFocused();
  // Fetch skills from the API when modal opens
  const fetchSkills = async () => {
    try {
      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/sp_skills_all',
        {
          method: 'POST',
        },
      );
      const result = await response.json();
      if (result.status == 200) {
        // console.log('skills info:::::::::::::::', result.msg);
        const formattedData =
          result?.msg?.map(skill => ({
            id: skill.skill_id,
            skill_name: skill.skill_name,
          })) ?? [];
        // console.log('skills formatted:::::::::', formattedData);
        setSkills(formattedData);
      } else {
        console.log('skills not fetched...');
      }
    } catch (error) {
      console.error('Error fetching skills:', error);
      Toast.show({
        type: 'error',
        text1: 'Failed to fetch skills',
        text2: 'Please try again later.',
      });
    }
  };

  useEffect(() => {
    fetchSkills();
    getUserId();
  }, [isFocused]);

  // Get the user ID from AsyncStorage
  const getUserId = async () => {
    const id = await AsyncStorage.getItem('uid');
    const cleanedId = id ? id.replace(/^"|"$/g, '') : null;
    setUserId(cleanedId);
  };
  // Handle adding skill
  const handleSubmit = async () => {
    try {
      // Prepare FormData payload
      const formData = new FormData();
      formData.append('skill', skillId);
      formData.append('profid', userId);

      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/addSkillForm',
        {
          method: 'POST',
          body: formData,
        },
      );

      const result = await response.json();

      if (result.status == 200) {
        // Update addedSkills with the new skill
        const newSkill = skills.find(skill => skill.id === skillId);
        setAddedSkills(prevSkills => [...prevSkills, newSkill]);
        getUserData('Your skill was successfully added.');
        setVisible(false); // Close modal on success
      } else {
        console.log('response while error:::::', response);

        Toast.show({
          type: 'error',
          text1: 'Error Adding Skill',
          text2: result.message || 'Something went wrong.',
        });
      }
    } catch (error) {
      console.error('Error adding skill:', error);
      Toast.show({
        type: 'error',
        text1: 'Error',
        text2: 'Failed to add skill. Please try again.',
      });
    }
  };

  const removeSkill = async skillId => {
    const formData = new FormData();
    formData.append('dataSkillValue', skillId);
    formData.append('dataPrfValue', userId);
    try {
      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/remove_professional_skill',
        {
          method: 'POST',
          body: formData,
        },
      );

      const res = await response.json();

      if (response.status == 200) {
        setAddedSkills(prev => prev?.filter(skill => skill?.id != skillId));
        getUserData(res?.message ?? 'Skill removed succesfully');
      } else {
        Toast.show({
          type: 'error',
          text1: 'Error',
          text2: res.msg || 'Failed to remove skill.',
        });
      }
    } catch (error) {
      console.error('Error removing skill:', error);
      Toast.show({
        type: 'error',
        text1: 'Error',
        text2: 'An error occurred. Please try again.',
      });
    }
  };
  //
  const getUserData = async msg => {
    try {
      const response = await getDataWithToken(mobile_siteConfig.USER_DETAILS);
      if (response?.status == 200) {
        dispatch(setUserDetails(response?.data));
        Toast.show({
          type: 'success',
          text1: 'Success',
          text2: msg,
        });
      }
    } catch (error) {
      console.log('error in gettting user details', error);
    } finally {
    }
  };
  // Open the modal
  const openModal = () => {
    setVisible(true);
    fetchSkills();
  };

  // Close the modal
  const closeModal = () => {
    setVisible(false);
  };
  return (
    <View style={{flex: 1, backgroundColor: Colors.white}}>
      <NewHeader header={'Add Skills'} navigation={navigation} />
      <ScrollView style={styles.container}>
        {/* Skills Section */}
        <View style={styles.skills}>
          <Text style={styles.skillText}>Skills</Text>

          <FlatList
            data={addedSkills}
            keyExtractor={item => item.id}
            numColumns={2} // Two columns
            renderItem={({item, index}) => (
              <View style={styles.skillCard} key={index}>
                <Text style={styles.skillCardText}>{item.skill_name}</Text>
                {/* Cross Icon for Deleting */}
                <TouchableOpacity onPress={() => removeSkill(item?.id)}>
                  <Image
                    source={Images.crossIcon}
                    style={{height: 20, width: 20}}
                    resizeMode="contain"
                  />
                </TouchableOpacity>
              </View>
            )}
            nestedScrollEnabled={true}
            columnWrapperStyle={styles.row}
            ListEmptyComponent={
              <Image
                source={Images.emptySkills}
                style={{
                  height: hp(40),
                  width: wp(65),
                  alignSelf: 'center',
                  marginTop: hp(10),
                }}
                resizeMode="contain"
              />
            }
          />
        </View>

        {/* Add Skill Button */}
        {/* <View style={styles.addSkill}>
          <NewButton text={'Hello'}/>
         
        </View> */}

        {/* Modal */}
        <Modal
          visible={visible}
          transparent={true}
          animationType="fade"
          onRequestClose={closeModal}>
          <TouchableWithoutFeedback onPress={closeModal}>
            <View style={styles.modalOverlay}>
              <TouchableWithoutFeedback>
                <View style={styles.modalContent}>
                  {/* Close Icon */}
                  <View style={styles.modalsec}>
                    <TouchableOpacity
                      onPress={closeModal}
                      style={styles.closeIconContainer}>
                      <Image
                        source={Images.crossIcon}
                        style={{height: 20, width: 20}}
                        resizeMode="contain"
                      />
                    </TouchableOpacity>

                    {/* Modal Title */}
                    <Text style={styles.modalTitle}>Add Skill</Text>
                  </View>

                  {/* Custom Scrollable Dropdown */}
                  <Text style={styles.labelText}>Select Skill</Text>
                  <FlatList
                    data={skills}
                    keyExtractor={item => item.id}
                    renderItem={({item}) => (
                      <TouchableOpacity
                        onPress={() => {
                          setSelectedSkill(item.skill_name);
                          setSkillId(item.id);
                        }}
                        style={[
                          styles.skillItem,
                          selectedSkill === item.skill_name &&
                            styles.selectedSkill,
                        ]}>
                        <Text
                          style={[
                            styles.skillNewText,
                            selectedSkill === item.skill_name &&
                              styles.selectedSkillText,
                          ]}>
                          {item.skill_name}
                        </Text>
                      </TouchableOpacity>
                    )}
                    style={styles.skillsList}
                  />

                  {/* Submit Button */}
                  <TouchableOpacity
                    onPress={handleSubmit}
                    style={styles.submitBtn}>
                    <Text style={styles.submitText}>Submit</Text>
                  </TouchableOpacity>
                </View>
              </TouchableWithoutFeedback>
            </View>
          </TouchableWithoutFeedback>
        </Modal>
      </ScrollView>
      <View style={{position: 'absolute', bottom: 20, alignSelf: 'center'}}>
        <NewButton onPress={openModal} text={'Add Skills'} />
      </View>
    </View>
  );
};

export default AddSkills;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  headerSection: {
    marginHorizontal: wp(5),
    marginVertical: hp(1),
    flexDirection: 'row',
    alignItems: 'center',
    gap: wp(2),
  },
  backArrow: {
    width: wp(8),
    height: hp(8),
  },
  headerTitle: {
    color: Colors.black,
    fontWeight: '500',
    fontSize: FSize.fs16,
  },

  skillText: {
    color: Colors.sooprsblue,
    fontWeight: '500',
    fontSize: FSize.fs22,
  },

  skills: {
    marginVertical: hp(2),
    marginHorizontal: wp(7),
  },

  row: {
    justifyContent: 'flex-start', // Space between cards
  },

  skillCard: {
    marginTop: hp(3),
    backgroundColor: Colors.lightgrey1,
    padding: wp(3),
    borderRadius: wp(2),
    marginBottom: hp(1),
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 4,
    justifyContent: 'space-between',
  },

  crossIconContainer: {
    marginLeft: wp(2),
  },

  crossIcon: {
    width: 30,
    height: 30,
    // tintColor:Colors.white
  },

  skillCardText: {
    width: wp(30),
    fontSize: FSize.fs14,
    color: Colors.black,
  },

  noSkillsText: {
    fontSize: FSize.fs14,
    color: Colors.gray,
    textAlign: 'center',
  },

  addSkill: {
    width: wp(90),
    alignItems: 'center',
    position: 'absolute',
    bottom: 0,
  },

  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: wp(80),
    backgroundColor: '#FFF',
    padding: wp(5),
    borderRadius: wp(2),
  },
  closeIconContainer: {
    alignSelf: 'flex-end',
  },
  crossIcon: {
    width: wp(3),
    height: hp(3),
  },
  modalTitle: {
    fontSize: FSize.fs18,
    fontWeight: 'bold',
    marginBottom: hp(2),
    color: Colors.black,
  },

  modalsec: {
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  labelText: {
    fontSize: FSize.fs14,
    marginVertical: hp(1),
    color: Colors.sooprsblue,
  },
  skillsList: {
    maxHeight: hp(25),
  },
  skillItem: {
    padding: hp(2),
    borderBottomWidth: 1,
    borderColor: Colors.lightGrey,
  },
  selectedSkill: {
    backgroundColor: Colors.sooprsblue,
  },

  selectedSkillText: {
    color: Colors.white,
  },

  skillNewText: {
    fontSize: FSize.fs14,
    color: Colors.black,
  },
  submitBtn: {
    marginTop: hp(3),
    backgroundColor: '#0077FF',
    padding: wp(3),
    alignItems: 'center',
    borderRadius: wp(2),
  },
  submitText: {
    color: '#FFFFFF',
    fontSize: FSize.fs16,
    fontWeight: 'bold',
  },
});
