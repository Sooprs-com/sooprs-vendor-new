import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {getFocusedRouteNameFromRoute} from '@react-navigation/native';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import Colors from '../assets/commonCSS/Colors';
import Images from '../assets/image';
import ClientHome from '../UserScreens/Home/ClientHome';
import Projects from '../UserScreens/Projects/ViewProjects';
import Professionals from '../UserScreens/Professionals/Professionals';
import BrowseGigs from '../UserScreens/Gigs/BrowseGigs';
import ProjectPosting from '../UserScreens/Projects/ProjectPosting';
import Notifications from './Notifications';
import ClientProfile from '../UserScreens/Profile/ClientProfile';
import ProjectBids from '../UserScreens/Projects/ProjectBids';
import ClientProjectDetails from '../UserScreens/Projects/ClientProjectDetails';
import IndividualChat from './IndividualChat';
import ProjectStatus from './ProjectStatus';
import ProfessionalProfile from '../UserScreens/Profile/ProfessionalProfile';
// import CategoriesList from './CategoriesList';
import GigDetails from '../UserScreens/Gigs/GigDetails';
import ClientDrawer from './ClientDrawer';
import PostChatSceen from '../UserScreens/PostChatScreen/PostChatSceen';

const iconSize = Math.min(wp(7), hp(4));

// Client Stack Navigator
const ClientStack = createNativeStackNavigator();

const ClientStackNavigator = () => {
  return (
    <ClientStack.Navigator screenOptions={{headerShown: false}}>
      <ClientStack.Screen name="ClientHome" component={ClientHome} />
      <ClientStack.Screen name="Notifications" component={Notifications} />
      <ClientStack.Screen name="ClientProfile" component={ClientProfile} />
      <ClientStack.Screen name="ProjectPosting" component={ProjectPosting} />
      <ClientStack.Screen name="ProjectsScreen" component={Projects} />
      <ClientStack.Screen name="IndividualChat" component={IndividualChat} />
      <ClientStack.Screen name="ProjectBids" component={ProjectBids} />
      <ClientStack.Screen name="ClientProjectDetails" component={ClientProjectDetails} />
      <ClientStack.Screen name="ProjectStatus" component={ProjectStatus} />
      <ClientStack.Screen name="ProfessionalsScreen" component={Professionals} />
      <ClientStack.Screen name="ProfessionalProfile" component={ProfessionalProfile} />
      {/* <ClientStack.Screen name="CategoriesList" component={CategoriesList} /> */}
      <ClientStack.Screen name="GigDetails" component={GigDetails} />
    </ClientStack.Navigator>
  );
};

// Projects Stack Navigator - nested stack for Projects tab
const ProjectsStack = createNativeStackNavigator();

const ProjectsStackNavigator = () => {
  return (
    <ProjectsStack.Navigator screenOptions={{headerShown: false}}>
      <ProjectsStack.Screen name="ViewProjects" component={Projects} />
      <ProjectsStack.Screen name="ProjectBids" component={ProjectBids} />
      <ProjectsStack.Screen name="ClientProjectDetails" component={ClientProjectDetails} />
      <ProjectsStack.Screen name="IndividualChat" component={IndividualChat} />
    </ProjectsStack.Navigator>
  );
};

// Professionals Stack Navigator - nested stack for Professionals tab
const ProfessionalsStack = createNativeStackNavigator();

const ProfessionalsStackNavigator = () => {
  return (
    <ProfessionalsStack.Navigator screenOptions={{headerShown: false}}>
      <ProfessionalsStack.Screen name="ProfessionalsList" component={Professionals} />
      <ProfessionalsStack.Screen name="ProfessionalProfile" component={ProfessionalProfile} />
    </ProfessionalsStack.Navigator>
  );
};

const BlackScreen = () => {
  return <View style={styles.blackScreen} />;
};

const ClientBottomTab = () => {
  const Tab = createBottomTabNavigator();
  const tabConfigs = [
    {
      name: 'Home',
      component: ClientDrawer,
      icon: Images.home,
    },
    {
      name: 'Projects',
      component: ProjectsStackNavigator,
      icon: Images.projectsIcon,
    },
    {
      name: 'Post',
      component: PostChatSceen,
      isCenter: true,
    },
    {
      name: 'Professionals',
      component: ProfessionalsStackNavigator,
      icon: Images.professionalsIcon,
    },
    {
      name: 'Gig',
      component: BrowseGigs,
      icon: Images.gigIcon,
    },
  ];

  // Custom Tab Bar
  const MyTab = ({state, descriptors, navigation}: any) => {
    const currentRoute = state.routes[state.index];
    if (currentRoute?.name === 'Post') {
      return null;
    }

    // Get the focused route name from nested stack navigators
    const focusedRouteName = getFocusedRouteNameFromRoute(currentRoute);
    
    // Hide tab bar when on ProfessionalProfile, ProjectBids, ClientProjectDetails, or IndividualChat screens
    if (
      focusedRouteName === 'ProfessionalProfile' ||
      focusedRouteName === 'ProjectBids' ||
      focusedRouteName === 'ClientProjectDetails' ||
      focusedRouteName === 'IndividualChat'
    ) {
      return null;
    }

    return (
      <View style={styles.tabContainer}>
        {state.routes.map((route: any, index: number) => {
          const isFocused = state.index === index;
          const tabConfig = tabConfigs[index];
          const icon = tabConfig?.icon;
          // Handle tab press
          const onPress = () => {
            if (!isFocused) {
              navigation.navigate(route.name);
            }
          };
          if (tabConfig?.isCenter) {
            return (
              <View key={route.key} style={styles.centerButtonWrapper}>
                <TouchableOpacity
                  onPress={onPress}
                  activeOpacity={0.8}
                  style={[
                    styles.centerButton,
                    isFocused && styles.centerButtonFocused,
                  ]}>
                  <Text style={styles.centerButtonLabel}>Post</Text>
                </TouchableOpacity>
              </View>
            );
          }
          return (
            <TouchableOpacity
              key={route.key}
              onPress={onPress}
              style={[styles.tabItem]}>
              {isFocused && <View style={styles.activeBorder} />}
              <Image
                source={icon}
                style={[styles.icon, isFocused && styles.focusedIcon]}
                resizeMode="contain"
              />
              <Text style={[styles.label, isFocused && styles.focusedLabel]}>
                {route.name}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    );
  };

  return (
    <Tab.Navigator
      screenOptions={{headerShown: false}}
      tabBar={props => <MyTab {...props} />}>
      {tabConfigs.map(tab => (
        <Tab.Screen key={tab.name} name={tab.name} component={tab.component} />
      ))}
    </Tab.Navigator>
  );
};

export default ClientBottomTab;

const styles = StyleSheet.create({
  tabContainer: {
    flexDirection: 'row',
    paddingVertical: hp(1.4),
    backgroundColor: Colors.white,
    borderTopWidth: 1,
    borderTopColor: Colors.lightgrey2,
  },
  tabItem: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerButtonWrapper: {
    flex: 1,
    alignItems: 'center',
  },
  centerButton: {
    marginTop: -hp(4),
    width: wp(18),
    height: wp(18),
    borderRadius: wp(9),
    backgroundColor: Colors.sooprsDark,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 4},
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 6,
  },
  centerButtonFocused: {
    backgroundColor: Colors.sooprsblue,
  },
  centerButtonLabel: {
    color: Colors.white,
    fontSize: hp(2),
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  icon: {
    width: iconSize,
    height: iconSize,
    tintColor: Colors.lightgrey2,
  },
  focusedIcon: {
    tintColor: Colors.sooprsDark,
  },
  activeBorder: {
    position: 'absolute',
    top: -hp(1.4),
    height: 3,
    width: '100%',
    backgroundColor: Colors.sooprsDark,
  },
  label: {
    fontSize: hp(1.5),
    color: Colors.lightgrey2,
    marginTop: hp(0.5),
  },
  focusedLabel: {
    color: Colors.sooprsDark,
    fontWeight: '600',
  },
  blackScreen: {
    flex: 1,
    backgroundColor: Colors.black,
  },
});