import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React, {useEffect, useState} from 'react';
import Images from '../../assets/image';
import FSize from '../../assets/commonCSS/FSize';
import Colors from '../../assets/commonCSS/Colors';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import AccountProfile from '../../components/AccountProfile';
import {useIsFocused} from '@react-navigation/native';
import {useSelector} from 'react-redux';
const size = Math.min(wp(16), hp(9));
const Account = ({navigation}: {navigation: any}) => {
  const [name, setName] = useState('');
  const [profileImage, setProfileImage] = useState(null);
  const isFocused = useIsFocused();
  const getUserDetails = useSelector(state => state?.getUserDetails);
  useEffect(() => {
    setName(getUserDetails?.name);
    setProfileImage(getUserDetails?.image);
  }, [isFocused]);
  return (
    <View style={styles.section}>
      <View style={styles.profileContainer}>
        <Image
          source={profileImage ? {uri: profileImage} : Images.defaultPicIcon}
          style={styles.Icon}
          resizeMode="cover"
        />
        <View style={{marginLeft: 18}}>
          <Text style={styles.nameText}>{name ?? 'Tushar'}</Text>
          {/* <Text style={styles.completeText}>Complete Profile</Text> */}
        </View>
      </View>
      <AccountProfile
        navigation={navigation}
        isClient={false}
        name={name}
        profileImage={profileImage}
        isCompany={getUserDetails?.is_company}
      />
    </View>
  );
};

export default Account;

const styles = StyleSheet.create({
  section: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  headerSection: {
    marginHorizontal: wp(5),
    marginVertical: hp(1),
    gap: wp(5),
    flexDirection: 'row',
    alignItems: 'center',
  },
  backArrow: {
    width: wp(8),
    height: hp(8),
  },
  Icon: {
    width: size,
    height: size,
    borderRadius: size / 2,
    borderWidth: 2,
    borderColor: Colors.white,
  },
  profileContainer: {
    width: wp(100),
    backgroundColor: Colors.sooprsDark,
    paddingVertical: hp(3),
    paddingTop:hp(7),
    paddingHorizontal: wp(10),
    flexDirection: 'row',
    alignItems: 'center',
  },
  nameText: {
    color: Colors.white,
    fontWeight: '500',
    fontSize: FSize.fs20,
    textTransform: 'capitalize',
  },
  completeText: {
    color: '#B7BF77',
    textDecorationLine: 'underline',
    fontWeight: '500',
    fontSize: FSize.fs15,
    marginTop: 4,
  },
});
