import {StyleSheet, Text, View, FlatList} from 'react-native';
import React, {useEffect} from 'react';
import ServicesCard from '../../components/ServicesCard';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import {useSelector} from 'react-redux';

const Skills = () => {
  const getUserDetails = useSelector(state => state?.getUserDetails);
  const skills = getUserDetails?.skills?.map(item => ({
    id: item?.skill_id,
    skill_name: item?.skill_name,
  }));
  const renderItem = ({item}: {item: any}) => <ServicesCard item={item} />;

  return (
    <View style={styles.skillsContainer}>
      {skills?.length > 0 ? (
        <FlatList
          data={skills}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
          numColumns={2}
          contentContainerStyle={styles.list}
        />
      ) : (
        <Text>No Skills Found</Text>
      )}
    </View>
  );
};

export default Skills;

const styles = StyleSheet.create({
  skillsContainer: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    padding: wp(1),
  },
  list: {
    justifyContent: 'space-between',
  },
});
