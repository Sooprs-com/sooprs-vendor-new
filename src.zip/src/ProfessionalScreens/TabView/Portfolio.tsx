import React, {useEffect, useState} from 'react';
import {
  View,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  Text,
  Linking,
} from 'react-native';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import Toast from 'react-native-toast-message';
import FSize from '../../assets/commonCSS/FSize';
import Images from '../../assets/image';
import Colors from '../../assets/commonCSS/Colors';

const Portfolio = ({portfolios = []}) => {
  const [portfolioData, setPortfolioData] = useState([]);
  const [expandedCardId, setExpandedCardId] = useState(null); // Track only the expanded card's ID

  // const fetchPortfolioData = async () => {
  //   const id = route?.params?.id;
  //   const formData = new FormData();
  //   formData.append('user_id', id);

  //   try {
  //     const response = await fetch(
  //       'https://sooprs.com/api2/public/index.php/manage_portfolio',
  //       {
  //         method: 'POST',
  //         body: formData,
  //       },
  //     );

  //     const res = await response.json();
  //     if (res.status === 200) {
  //       setPortfolioData(res.msg);
  //     } else if (res.status === 400) {
  //       Toast.show({
  //         type: 'error',
  //         text1: res.msg,
  //         text1Style: {fontSize: 16, fontWeight: '600'},
  //         text2Style: {fontSize: 14, color: '#666'},
  //       });
  //     }
  //   } catch (error) {
  //     Toast.show({
  //       type: 'error',
  //       text1: 'Something went wrong!',
  //       text1Style: {fontSize: 16, fontWeight: '600'},
  //       text2Style: {fontSize: 14, color: '#666'},
  //     });
  //   }
  // };

  // useEffect(() => {
  //   fetchPortfolioData();
  // }, []);

  const handleLinkPress = url => {
    if (url) {
      Linking.openURL(url);
    } else {
      Toast.show({
        type: 'error',
        text1: 'Invalid URL',
        text1Style: {fontSize: 16, fontWeight: '600'},
        text2Style: {fontSize: 14, color: '#666'},
      });
    }
  };

  // const toggleExpand = id => {
  //   setExpandedCardId(prevId => (prevId === id ? null : id)); // Toggle expanded state for specific card
  // };

  const renderPortfolioItem = ({item}: {item: any}) => {
    console.log('itemsms',item?.title)
    return (
      <TouchableOpacity
        style={styles.card}
        onPress={() => handleLinkPress(item.link)}
        activeOpacity={0.8}>
        <Image
          source={{
            uri: `https://sooprs.com/assets/portfolio-images/${item.files}`,
          }}
          style={styles.image}
          resizeMode="cover"
        />
        <Text style={styles.name}>{item?.title}</Text>
        {/* <Text style={styles.role}>{item.description}</Text> */}
      </TouchableOpacity>
    );
  };
  return (
    <View style={styles.container}>
      <FlatList
        data={portfolios}
        renderItem={renderPortfolioItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.portfolioList}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <Text
            style={{
              color: Colors.black,
              textAlign: 'center',
              marginTop: hp(10),
            }}>
            No portfolio Available
          </Text>
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  portfolioList: {
    paddingBottom: hp(8),
  },
  card: {
    alignSelf:'center',
    backgroundColor: Colors.white,
    borderRadius: 10,
    width: wp(90),
    marginVertical: 15,
    borderWidth: 0.5,
    borderColor: '#ccc',
    overflow: 'hidden', // Prevent overflow
  },
  expandedCard: {
    minHeight: hp(34), // Increase height to accommodate expanded content
  },
  imgBack: {
    width: '100%',
    height: hp(12),
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: hp(22),
  },
  info: {
    paddingVertical: hp(1),
    paddingHorizontal: wp(2),
    flexDirection: 'column',
  },
  name: {
    fontSize: FSize.fs18,
    fontWeight: 'bold',
    color: '#444444',
    paddingHorizontal: 16,
    marginVertical: 10,
  },
  role: {
    fontSize: FSize.fs10,
    color: Colors.black,
  },
  readMore: {
    fontSize: FSize.fs12,
    color: '#0077FF',
    marginTop: hp(0.5),
  },
  link: {
    fontSize: FSize.fs12,
    color: '#0077FF',
    textDecorationLine: 'underline',
    marginTop: hp(0.5),
  },
});

export default Portfolio;
