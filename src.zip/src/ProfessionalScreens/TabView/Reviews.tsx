import React, {useState, useEffect} from 'react';
import {StyleSheet, Text, View, Image, FlatList} from 'react-native';
import * as Progress from 'react-native-progress';
import Images from '../../assets/image';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import Colors from '../../assets/commonCSS/Colors';
import FSize from '../../assets/commonCSS/FSize';
const iconSize = Math.min(wp(16), hp(7));
const Reviews = ({reviews = []}) => {
  const renderReview = ({item}: {item: any}) => {
    return (
      <View style={styles.card}>
        <View style={styles.header}>
          <Image source={{uri: item.image}} style={styles.avatar} />
          <View>
            <Text style={styles.name}>{item.name}</Text>
            <View style={styles.ratingContainer}>
              {Array.from({length: 5}, (_, index) => (
                <Text
                  key={index}
                  style={[
                    styles.star,
                    index < Number(item?.rating) && styles.filledStar,
                  ]}>
                  ★
                </Text>
              ))}
              <Text style={styles.rating}></Text>
            </View>
          </View>
        </View>
        <View>
          <Text style={styles.review}>{item.review}</Text>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={reviews}
        renderItem={renderReview}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          <Text
            style={{
              color: Colors.black,
              textAlign: 'center',
              marginTop: hp(10),
            }}>
            No Reviews Available
          </Text>
        }
      />
    </View>
  );
};

export default Reviews;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    padding: wp(2),
    paddingHorizontal: wp(5),
    paddingTop: hp(1),
  },
  list: {
    paddingBottom: hp(2),
  },
  card: {
    flexWrap: 'wrap',
    borderRadius: 10,
    padding: wp(4),
    marginVertical: hp(1),
    borderWidth: 1,
    borderColor: '#ccc',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: hp(1),
  },

  ratingsInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  avatar: {
    width: iconSize,
    height: iconSize,
    borderRadius: iconSize / 2,
    marginRight:8
  },
  name: {
    fontSize: wp(4),
    fontWeight: 'bold',
    color: Colors.black,
  },
  review: {
    color: Colors.gray,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: hp(1),
  },
  star: {
    fontSize: wp(4),
    color:'#dcdcdc'
  },
  filledStar: {
    color: '#F4DE25',
  },
  emptyStar: {
    color: '#dcdcdc',
  },
  rating: {
    marginLeft: wp(2),
    fontSize: wp(4),
    color: 'gray',
  },
  text: {
    fontSize: FSize.fs16,
    color: Colors.black,
    width: wp(30),
  },
  ratingOverview: {
    flexDirection: 'column',
    // alignItems: 'center',
    marginBottom: hp(2),
  },
  ratingScore: {
    fontSize: wp(18),
    fontWeight: 'bold',
    color: Colors.black,
  },
  starContainer: {
    flexDirection: 'row',
    marginLeft: wp(2),
  },
  progressBars: {
    marginBottom: hp(2),
  },
  progressBarContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: hp(0.5),
  },
  progressBarLabel: {
    color: 'gray',
    fontWeight: '600',
    width: wp(5),
  },
});
