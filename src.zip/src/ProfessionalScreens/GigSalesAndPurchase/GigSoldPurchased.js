import {
  ActivityIndicator,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import Colors from '../../assets/commonCSS/Colors';
import NewHeader from '../../components/NewHeader';
import {postData, postFormData} from '../../services/mobile-api';
import {mobile_siteConfig} from '../../services/mobile-siteConfig';
import {useSelector} from 'react-redux';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import FSize from '../../assets/commonCSS/FSize';
import Images from '../../assets/image';

const GigSoldPurchased = ({navigation, route}) => {
  const getUserId = useSelector(state => state?.getUserId);
  const {header} = route?.params || {};
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  useEffect(() => {
    getData();
  }, []);
  const getData = async () => {
    const reqUrl =
      header == 'Gigs Sold'
        ? mobile_siteConfig.SOLD_GIGS
        : mobile_siteConfig.PURCHASED_GIGS;
    const req = new FormData();
    req.append('user_id', getUserId);
    try {
      const res = await postFormData(req, reqUrl);
      if (res?.status == 200) {
        setData(res?.data);
      }
      // console.log('res', res?.data);
    } catch (error) {
      setLoading(false);
    } finally {
      setLoading(false);
    }
  };
  const renderItem = ({item, index}) => {
    console.log('item=>', item, getUserId);
    return (
      <TouchableOpacity
        style={{
          width: wp(90),
          borderWidth: 1,
          borderColor: '#ccc',
          padding: 12,
          marginVertical: 8,
          borderRadius: 12,
        }}
        onPress={() =>
          navigation.navigate('Chat', {
            gorder_id: item.gorder_id,
            receiver_id:
              header == 'Gigs Sold' ? item.buyer_id : item?.seller_id,
            name: item?.buyer_name,
            image: item?.buyer_image,
          })
        }>
        <Text
          style={{
            color: Colors.black,
            fontSize: FSize.fs16,
            fontWeight: '500',
          }}>
          {item?.gig_details?.gig_title}
        </Text>
        <Text style={styles.subText}>Buyer Name: {item?.buyer_name}</Text>
        <Text style={styles.subText}>Gig price: {item?.final_amt} INR</Text>
        {/* <Text>{item?.gig_details?.gig_unique_id}</Text> */}
        <Text style={{color: '#0038FF', marginVertical: 2}}>
          {item?.payment_id}
        </Text>
        {/* <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}>
          {item?.order_date &&
            item?.order_date?.split(' ').map((item, index) => {
              return <Text >{item}</Text>;
            })}
        </View> */}
        <Text style={{color: Colors.gray, marginVertical: 2}}>
          {item?.order_date}
        </Text>
      </TouchableOpacity>
    );
  };
  if (loading)
    return (
      <ActivityIndicator
        color={Colors.sooprsDark}
        style={{marginTop: hp(10)}}
      />
    );
  return (
    <View style={styles.container}>
      <NewHeader navigation={navigation} header={header ?? ''} />
      <View style={{alignSelf: 'center', marginTop: 10}}>
        <FlatList
          data={data}
          renderItem={renderItem}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{paddingBottom: hp(10)}}
          ListEmptyComponent={
            <Image
              source={Images.nodata}
              style={{
                height: hp(40),
                width: wp(65),
                alignSelf: 'center',
                marginTop: hp(10),
              }}
              resizeMode="contain"
            />
          }
        />
      </View>
    </View>
  );
};

export default GigSoldPurchased;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  subText: {color: Colors.black, fontWeight: '400', marginVertical: 2},
});
