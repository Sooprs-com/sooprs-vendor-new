import {
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import Colors from '../../assets/commonCSS/Colors';
import Images from '../../assets/image';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import {DrawerActions} from '@react-navigation/native';
import FSize from '../../assets/commonCSS/FSize';
const iconSize = Math.min(wp(7), hp(4));
const SearchFilter = ({
  input,
  setInput,
  originalData = [],
  navigation,
  onFilterPress,
  projectLength,
}) => {
  const handleSearch = param => {
    if (!param.trim()) {
      //   setGigData(originalData);
      return;
    }
    const filteredGigs = originalData.filter(
      item =>
        item.gig_title.toLowerCase().includes(param?.toLowerCase()) ||
        item.gig_tags
          ?.split(',')
          .some(tag => tag.toLowerCase().includes(param.toLowerCase())) ||
        item.gig_price.toString().includes(param) ||
        item?.professional?.name?.toLowerCase().includes(param?.toLowerCase()),
    );
    // setGigData(filteredGigs);
  };
  return (
    <View style={styles.searchRow}>
      <Text
        style={{color: Colors.gray, fontWeight: '500', fontSize: FSize.fs15}}>
        Projects ({projectLength})
      </Text>
      <TouchableOpacity
        activeOpacity={0.6}
        onPress={() =>
          navigation
            .getParent('RightDrawer')
            .dispatch(DrawerActions.openDrawer())
        }>
        <Image
          source={Images.filterIcon1}
          style={{height: iconSize, width: iconSize}}
        />
      </TouchableOpacity>
    </View>
  );
};

export default SearchFilter;

const styles = StyleSheet.create({
  searchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    // padding: 16,
    marginBottom: 10,
    alignItems: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: Colors.lightGrey,
    borderRadius: 12,
    flex: 1,
    marginRight: 12,
    padding: 10,
  },
});
