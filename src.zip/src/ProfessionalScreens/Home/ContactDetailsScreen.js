import React, {useState, useEffect, useCallback} from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Linking,
  ActivityIndicator,
  RefreshControl,
  Image,
  Alert,
} from 'react-native';
import {useFocusEffect} from '@react-navigation/native'; // Import useFocusEffect
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import FSize from '../assets/commonCSS/FSize';
import Colors from '../assets/commonCSS/Colors';
import {mobile_siteConfig} from '../services/mobile-siteConfig';
import {getDataFromAsyncStorage} from '../services/CommonFunction';
import Images from '../assets/image';
import he from 'he';
const ContactDetailScreen = ({navigation}) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const decodeHtmlEntities = str => {
    return he.decode(str); // Decodes HTML entities (e.g. &#39; -> ')
  };

  // Fetch Contacts Data
  const fetchContacts = async () => {
    setLoading(true);
    const getUserId = await getDataFromAsyncStorage(mobile_siteConfig.UID);
    const formData = new FormData();
    formData.append('id', getUserId);

    try {
      const response = await fetch(
        `${mobile_siteConfig.BASE_URL}${mobile_siteConfig.INDEX}${mobile_siteConfig.GET_CONTACTS}`,
        {
          method: 'POST',
          body: formData,
        },
      );

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const result = await response.json();
      if (result.status === 200 && result.msg === 'Success') {
        setData(result.data);
      } else {
        setData([]);
      }
    } catch (error) {
      console.error('Error fetching contacts:', error);
      setData([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Dial Contact Number
  const handleDial = mobile => {
    Linking.openURL(`tel:${mobile}`);
  };
  const openWhatsApp = phoneNumber => {
    const whatsappURL = `whatsapp://send?phone=${phoneNumber}`;

    Linking.canOpenURL(whatsappURL)
      .then(supported => {
        if (supported) {
          return Linking.openURL(whatsappURL);
        } else {
          Alert.alert('Error', 'WhatsApp is not installed on your device.');
        }
      })
      .catch(err => console.error('Error:', err));
  };
  // handle card press
  const handleCardPress = item => {
    console.log('itemDetails===>',item)
    navigation.navigate('ProjectDetails', {
      id: item.id,
      cScreen:true,
      contactNumber:item.mobile
      // isCompany,
    });
  };
  // Render Contact Item
  const renderItem = ({item}) => (
    <TouchableOpacity style={styles.card} onPress={() => handleCardPress(item)}>
      <View style={{width: '60%'}}>
        <Text style={styles.title}>{decodeHtmlEntities(item.project_title)}</Text>
        <Text style={styles.date}>{item.created_at}</Text>
        <Text style={styles.mobile}>{item.mobile}</Text>
      </View>
      <View style={{flexDirection: 'row'}}>
        <TouchableOpacity onPress={() => openWhatsApp(item.mobile)}>
          <Image
            source={Images.whatsAppIcon}
            style={styles.iconStyle}
            resizeMode="contain"
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => handleDial(item.mobile)}>
          <Image
            source={Images.callIcon}
            style={styles.iconStyle}
            resizeMode="contain"
          />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  // Show Loading Spinner
  const renderLoading = () => (
    <View style={styles.centered}>
      <ActivityIndicator size="large" color={Colors.sooprsblue} />
    </View>
  );

  // Show Empty State
  const renderEmptyState = () => (
    <View style={styles.centered}>
      <Text style={styles.emptyText}>No contacts available</Text>
    </View>
  );

  // Handle Pull-to-Refresh
  const handleRefresh = () => {
    setRefreshing(true);
    fetchContacts();
  };

  // Fetch data on screen focus
  useFocusEffect(
    useCallback(() => {
      fetchContacts();
    }, []),
  );

  return (
    <View style={styles.container}>
      {/* Header Section */}
      <View style={styles.headerSection}>
        <Text style={styles.headerTitle}>Contacts</Text>
      </View>

      {/* Main Content */}
      {loading ? (
        renderLoading()
      ) : data.length === 0 ? (
        renderEmptyState()
      ) : (
        <FlatList
          data={data}
          keyExtractor={(item, index) => index.toString()}
          renderItem={renderItem}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              colors={[Colors.sooprsblue]}
            />
          }
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  headerSection: {
    marginHorizontal: wp(5),
    marginVertical: hp(1),
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconStyle: {width: 35, height: 35, marginRight: 8},
  headerTitle: {
    color: Colors.black,
    fontWeight: '500',
    fontSize: FSize.fs16,
  },
  card: {
    alignSelf: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: wp(90),
    backgroundColor: Colors.white,
    padding: wp(4),
    marginVertical: hp(1),
    borderWidth: 1,
    borderRadius: 20,
    borderColor:Colors.lightGrey
  },
  title: {
    fontSize: FSize.fs16,
    fontWeight: 'bold',
    color: Colors.black,
    marginBottom: hp(0.5),
  },
  date: {
    fontSize: FSize.fs14,
    color: Colors.gray,
    marginBottom: hp(0.5),
  },
  mobile: {
    fontSize: FSize.fs15,
    color: Colors.sooprsblue,
  },
  emptyText: {
    fontSize: FSize.fs16,
    color: Colors.gray,
    textAlign: 'center',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContent: {
    paddingBottom: hp(5),
  },
});

export default ContactDetailScreen;