import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  SectionList,
  TouchableOpacity,
} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import Colors from '../../assets/commonCSS/Colors';
import FSize from '../../assets/commonCSS/FSize';
import CustomButton from '../../components/CustomButton';
import {DrawerActions, useNavigation} from '@react-navigation/native';
import {setProjectFilter} from '../../Redux/Actions';
import {useDrawerStatus} from '@react-navigation/drawer';
import PriceRangeSlider from './PriceRangeSlider';
import { hp } from '../../assets/commonCSS/GlobalCSS';
const ProjectFilterComponent = ({navigation}) => {
  const getUserDetails = useSelector(state => state?.getUserDetails);
  const dispatch = useDispatch();
  const getProjectFilters = useSelector(state => state?.getProjectFilters);
  const drawerStatus = useDrawerStatus();
  const [priceRange, setPriceRange] = useState(100);
  // Default selected values (single values for all)
  const [selectedFilters, setSelectedFilters] = useState({
    datePosted: null,
    budget: null,
    categories: null,
    min_budget: null,
    max_budget: null,
  });
  useEffect(() => {
    if (Object.keys(getProjectFilters).length > 0) {
      setProjectFilter(getProjectFilters);
      getProjectFilters?.max_budget &&
        setPriceRange(getProjectFilters?.max_budget);
    } else {
      setPriceRange(100);
      setSelectedFilters({
        datePosted: null,
        budget: null,
        categories: null,
        min_budget: null,
        max_budget: null,
      });
    }
  }, [drawerStatus]);

  // Section Data (Keep original structure for categories)
  const filtersArray = [
    {
      title: 'Date Posted',
      data: [
        {id: 'last_24_hours', service_name: 'Past 24 hours'},
        {id: 'last_7_days', service_name: 'Past 7 days'},
        {id: 'last_1_month', service_name: 'Past 1 month'},
      ],
      key: 'datePosted',
    },
    {
      title: 'Budget',
      data: [
        {id: '1', service_name: 'Low'},
        {id: '0', service_name: 'High'},
      ],
      key: 'budget',
    },
    {
      title: 'Categories',
      data: getUserDetails?.services || [],
      key: 'categories',
    },
  ];
  // price range filter
  const handlePriceChange = range => {
    setSelectedFilters(prev => ({
      ...prev,
      min_budget: 0,
      max_budget: range,
    }));
  };
  // Handle selection (only one category allowed now)
  const handleSelect = (sectionKey, item) => {
    setSelectedFilters(prev => ({
      ...prev,
      [sectionKey]: prev[sectionKey] === item.id ? null : item.id,
    }));
  };

  // Render radio button or selected item
  const renderItem = ({item, section}) => {
    const isSelected = selectedFilters[section.key] === item.id;

    return (
      <TouchableOpacity
        activeOpacity={0.8}
        style={styles.radioContainer}
        onPress={() => handleSelect(section.key, item)}>
        <View
          style={[styles.radioCircle, isSelected && styles.radioSelected]}
        />
        <Text style={styles.radioText}>{item.service_name}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <Text
        style={styles.clearFilters}
        onPress={() => {
          dispatch(setProjectFilter({}));
          setPriceRange(100);
          setSelectedFilters({
            datePosted: null,
            budget: null,
            categories: null,
            min_budget: null,
            max_budget: null,
          });
          navigation
            .getParent('RightDrawer')
            .dispatch(DrawerActions.closeDrawer());
        }}>
        Clear filters
      </Text>
      <SectionList
        sections={filtersArray}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        scrollEnabled={false}
        renderSectionHeader={({section: {title}}) => (
          <Text style={styles.sectionHeader}>{title}</Text>
        )}
        contentContainerStyle={styles.listContainer}
        ListFooterComponent={
          <>
            <PriceRangeSlider
              onChange={handlePriceChange}
              selectedValue={priceRange}
              setSelectedValue={setPriceRange}
              maxPrice={getUserDetails?.country == 'IN' ? 500000 : 1000}
              currencySymbol={getUserDetails?.country == 'IN' ? '₹' : '$'}
            />
            <CustomButton
              buttonText="Apply"
              buttonStyle={{
                width: '50%',
                marginVertical: 8,
                alignSelf: 'flex-end',
              }}
              onButtonPress={() => {
                dispatch(setProjectFilter(selectedFilters));
                navigation
                  .getParent('RightDrawer')
                  .dispatch(DrawerActions.closeDrawer());
              }}
            />
          </>
        }
      />
    </View>
  );
};

export default ProjectFilterComponent;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 12,
    paddingTop:hp(5),
    backgroundColor: Colors.white,
  },
  clearFilters: {
    color: Colors.grey,
    fontWeight: 'bold',
    textAlign: 'right',
    fontSize: FSize.fs15,
    marginBottom: 10,
  },
  listContainer: {
    paddingBottom: 20,
  },
  sectionHeader: {
    fontSize: FSize.fs17,
    fontWeight: 'bold',
    color: Colors.black,
    marginVertical: 8,
  },
  radioContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  radioCircle: {
    width: 18,
    height: 18,
    borderRadius: 9,
    borderWidth: 2,
    borderColor: Colors.grey,
    marginRight: 10,
  },
  radioSelected: {
    borderColor: Colors.sooprsblue,
    backgroundColor: Colors.sooprsblue,
  },
  radioText: {
    fontSize: FSize.fs15,
    color: Colors.black,
  },
});
