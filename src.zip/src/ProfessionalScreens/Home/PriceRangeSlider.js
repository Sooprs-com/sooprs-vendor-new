import React, {useState} from 'react';
import {View, Text, StyleSheet} from 'react-native';
import Slider from '@react-native-community/slider';
import Colors from '../../assets/commonCSS/Colors';
import FSize from '../../assets/commonCSS/FSize';

const PriceRangeSlider = ({
  maxPrice = 1000,
  onChange,
  selectedValue,
  setSelectedValue,
  currencySymbol,
}) => {
  const handleSliderChange = value => {
    setSelectedValue(value); // Update UI immediately
  };
  const handleSlidingComplete = value => {
    onChange(value); // Update external state when user stops sliding
  };

  return (
    <View style={styles.container}>
      <View>
        <Text style={styles.priceText}>Price Range</Text>
        <Text style={{color: Colors.gray, fontWeight: 'bold'}}>
          {0} to {currencySymbol}
          {selectedValue}
        </Text>
      </View>
      <Slider
        style={styles.slider}
        minimumValue={50}
        maximumValue={maxPrice}
        step={10}
        value={selectedValue}
        onValueChange={handleSliderChange} // Live update
        onSlidingComplete={handleSlidingComplete} // Commit final value
        minimumTrackTintColor={Colors.sooprsblue}
        maximumTrackTintColor={Colors.grey}
        thumbTintColor={Colors.sooprsblue}
      />
    </View>
  );
};

export default PriceRangeSlider;

const styles = StyleSheet.create({
  container: {
    // paddingVertical: 15,
    // paddingHorizontal: 10,
  },
  priceText: {
    fontSize: FSize.fs17,
    fontWeight: 'bold',
    color: Colors.black,
    marginVertical: 8,
  },
  slider: {
    width: '100%',
    height: 30,
  },
});
