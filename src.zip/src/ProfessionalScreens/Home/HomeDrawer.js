import {createDrawerNavigator} from '@react-navigation/drawer';
import React from 'react';
import {Dimensions, ScrollView} from 'react-native';
import {useSelector} from 'react-redux';
import ProfessionalHome from './ProfessionalHome.tsx';
import ClientHome from '../../UserScreens/Home/ClientHome';
import Account from '../Account/Account.tsx';
import ClientAccount from '../../UserScreens/Account/Account.tsx';
import ProjectFilterComponent from './ProjectFilterComponent.js';

const MainDrawer = createDrawerNavigator();
const RightDrawer = createDrawerNavigator();
const {width} = Dimensions.get('window');
const ScrollableDrawerContent = ({children}) => {
  return (
    <ScrollView
      contentContainerStyle={{flexGrow: 1}}
      showsVerticalScrollIndicator={false}>
      {children}
    </ScrollView>
  );
};

// filter drawer
const RightDrawerScreen = () => {
  const getIfProfessional = useSelector(state => state?.getIfProfessional);
  return (
    <RightDrawer.Navigator
      id="RightDrawer"
      screenOptions={{
        drawerPosition: 'right',
        headerShown: false,
        gestureEnabled:false,
        drawerStyle: {width: width * 0.7, overflow: 'hidden'},
      }}
      drawerContent={props => (
        <ScrollableDrawerContent>
          <ProjectFilterComponent {...props} />
        </ScrollableDrawerContent>
      )}>
      <RightDrawer.Screen
        name="MainScreen"
        component={getIfProfessional == '0' ? ProfessionalHome : ClientHome}
      />
    </RightDrawer.Navigator>
  );
};

const HomeDrawer = () => {
  const getIfProfessional = useSelector(state => state?.getIfProfessional);

  return (
    <MainDrawer.Navigator
      id="LeftDrawer"
      screenOptions={{
        headerShown: false,
        drawerPosition: 'left',
        drawerStyle: {width: width * 0.85, overflow: 'hidden'},
      }}
      drawerContent={props => (
        <ScrollableDrawerContent>
          {getIfProfessional == 0 ? (
            <Account {...props} />
          ) : (
            <ClientAccount {...props} />
          )}
        </ScrollableDrawerContent>
      )}>
      <MainDrawer.Screen
        name="RightDrawerWrapper"
        component={RightDrawerScreen}
      />
    </MainDrawer.Navigator>
  );
};

export default HomeDrawer;
