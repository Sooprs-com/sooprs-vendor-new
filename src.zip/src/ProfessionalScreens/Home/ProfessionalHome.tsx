import {
  StyleSheet,
  Text,
  View,
  StatusBar,
  Image,
  ScrollView,
  RefreshControl,
  ActivityIndicator,
  Dimensions,
  FlatList,
} from 'react-native';
import React, {useEffect, useReducer, useState} from 'react';
import {wp, hp} from '../../assets/commonCSS/GlobalCSS';
import Colors from '../../assets/commonCSS/Colors';
import FSize from '../../assets/commonCSS/FSize';
import {useIsFocused} from '@react-navigation/native';
import {mobile_siteConfig} from '../../services/mobile-siteConfig';
import Header from '../../components/Header';
import Carousel from '../../components/Carousel';
import {useDispatch, useSelector} from 'react-redux';
import Images from '../../assets/image';
import SearchFilter from './SearchFilter';
import {postDataWithToken1} from '../../services/mobile-api';
import Toast from 'react-native-toast-message';
import {setProjectFilter} from '../../Redux/Actions';
import NewProjectCard from '../../components/NewProjectCard';
import CustomButton from '../../components/CustomButton';
// optmization needed
const Home = ({navigation}: {navigation: any}) => {
  const ITEM_PER_RENDER = 10;
  const [name, setName] = useState('');
  const isFocused = useIsFocused();
  const [refreshing, setRefreshing] = useState(false);

  // States to manage project data and API response
  const [projectDetail, setProjectDetail] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [profilePic, setProfilePic] = useState(null);
  const [company, setIsCompany] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [originalData, setOriginalData] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const getUserDetails = useSelector(state => state?.getUserDetails);
  const getProjectFilters = useSelector(state => state?.getProjectFilters);
  const dispatch = useDispatch();
  useEffect(() => {
    if (isFocused) {
      getProjects();
      getNameAndImage();
    }
  }, [isFocused, getProjectFilters]);
  const getNameAndImage = () => { 
    setName(getUserDetails?.name);
    setProfilePic(getUserDetails?.image);
    setIsCompany(getUserDetails?.is_company);
  };
  const getProjects = async () => {
    // reset the page
    setCurrentPage(1);
    setIsLoading(true);
    //to get active flags
    const activeFlags =
      Array.from(
        new Set(getUserDetails?.services?.map(item => item?.flag)),
      ).toString() || '';
    try {
      // req params for filtered data
      const req = {
        cur: getUserDetails?.country == 'IN' ? 'INR' : 'USD',
        ...(!getProjectFilters?.categories && {flag: activeFlags}),
        ...(getProjectFilters?.budget && {lowhign: getProjectFilters?.budget}),
        ...(getProjectFilters?.datePosted && {
          timeline: getProjectFilters?.datePosted,
        }),
        ...(getProjectFilters?.categories && {
          category: getProjectFilters?.categories,
        }),
        ...(getProjectFilters?.min_budget && {min_budget: 0}),
        ...(getProjectFilters?.max_budget && {
          max_budget: getProjectFilters?.max_budget,
        }),
      };
      // console.log('payload', req);
      const res = await postDataWithToken1(
        req,
        mobile_siteConfig.INDEX + mobile_siteConfig.GET_FILTERED_PROJECTS,
      );
      setOriginalData(res);
      setProjectDetail(res?.slice(0, 10));
      // setpegination on api call
      if (res.length > currentPage * ITEM_PER_RENDER) {
        setCurrentPage(prev => prev + 1);
        setHasMore(true);
      } else {
        setHasMore(false);
      }
    } catch (error) {
      Toast.show({
        type: 'error',
        text1: 'Error in fetching leads',
      });
    } finally {
      setIsLoading(false);
    }
  };
  // pegination handling from front end
  const showMore = (data = []) => {
    const endIndex = currentPage * ITEM_PER_RENDER;
    const limitedData = data.slice(0, endIndex);
    setProjectDetail(limitedData);
    if (data.length > currentPage * ITEM_PER_RENDER) {
      setCurrentPage(prev => prev + 1);
      setHasMore(true);
    } else {
      setHasMore(false);
    }
  };
  const onRefresh = async () => {
    dispatch(setProjectFilter({}));
    setRefreshing(true);
    setRefreshing(false); 
  };

  const handleReferPress = () => {
    navigation.navigate('ProfessionalStack', {screen: 'Refer'});
  };
  const handleNavigation = (screenName, params = {}) => {
    navigation.navigate('ProfessionalStack', {screen: screenName, params});
  };
  const onCardPress = item => {
    // console.log('item',item.id)
    handleNavigation('ProjectDetails', {
      id: item.id,
    });
  };
  return (
    <View style={{flex: 1}}>
      <StatusBar barStyle="dark-content" backgroundColor="white" />
      <Header
        navigation={navigation}
        img={profilePic}
        name={name || 'user'}
        btnName=""
        isClient={false}
      />
      <ScrollView
        style={styles.container}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={Colors.sooprsblue}
            colors={[Colors.sooprsblue, Colors.black]}
          />
        }
        showsVerticalScrollIndicator={false}>
        {/* <MovingBanner navigation={navigation} /> */}
        <Carousel
          carouselData={[{id: 1, image: Images.refer}]}
          onImagePress={handleReferPress}
        />
        <View style={styles.section}>
          {isLoading ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color={Colors.sooprsblue} />
            </View>
          ) : (
            <View>
              <SearchFilter
                input={searchInput}
                setInput={setSearchInput}
                originalData={originalData}
                navigation={navigation}
                projectLength={projectDetail.length}
              />
              <FlatList
                data={projectDetail}
                renderItem={({item, index}) => (
                  <NewProjectCard
                    item={item}
                    index={index}
                    currency={getUserDetails?.country == 'IN' ? 'INR' : 'USD'}
                    onCardPress={() => onCardPress(item)}
                  />
                )}
                keyExtractor={(item, index) => index.toString()}
                ListFooterComponent={
                  <CustomButton
                    buttonStyle={{marginVertical: 10}}
                    buttonText="Load more..."
                    onButtonPress={() => showMore(originalData)}
                  />
                }
                showsVerticalScrollIndicator={false}
                scrollEnabled={false}
              />
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  );
};

export default Home;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },

  section: {
    alignSelf: 'center',
  },
  homeInfo: {
    color: Colors.black,
    fontWeight: '600',
    fontSize: FSize.fs19,
  },

  textAlign: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: hp(3),
  },

  profText: {
    color: Colors.sooprsblue,
  },

  searchFilter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: wp(2),
    marginHorizontal: wp(1),
    // width:width/1.3
  },

  loadingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: hp(2),
  },
});
