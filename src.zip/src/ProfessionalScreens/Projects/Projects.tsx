import {FlatList, Image, StyleSheet, View, RefreshControl} from 'react-native';
import React, {useEffect, useState, useCallback} from 'react';
import {useIsFocused} from '@react-navigation/native';
import {useSelector} from 'react-redux';
import NewHeader from '../../components/NewHeader';
import NewProjectCard from '../../components/NewProjectCard';
import CustomButton from '../../components/CustomButton';
import Colors from '../../assets/commonCSS/Colors';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import Images from '../../assets/image';

const Projects = ({navigation}) => {
  const [bidProjects, setBidProjects] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [moreLoading, setMoreLoading] = useState(false);
  const getUserId = useSelector(state => state?.getUserId);
  const isFocused = useIsFocused();
  const getUserDetails = useSelector(state => state?.getUserDetails);
  useEffect(() => {
    if (isFocused) {
      fetchProjects(true);
    }
  }, [isFocused]);

  const fetchProjects = async (isRefreshing = false) => {
    if (moreLoading) return;
    setMoreLoading(true);

    const newOffset = isRefreshing ? 0 : offset + 10;

    try {
      const formdata = new FormData();
      formdata.append('offset', newOffset);
      formdata.append('limit', 10);
      formdata.append('my_get_id', getUserId);
      formdata.append('cur', getUserDetails?.country == 'IN' ? 'INR' : 'USD');
      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/get_my_leads',
        {
          method: 'POST',
          body: formdata,
        },
      );

      const responseData = await response.json();
      if (responseData.status === 200) {
        const newProjects = responseData?.msg || [];

        setBidProjects(prev =>
          isRefreshing
            ? newProjects
            : [
                ...prev,
                ...newProjects.filter(
                  proj => !prev.some(p => p.id === proj.id),
                ),
              ],
        );

        setHasMore(newProjects.length === 10);
        setOffset(newOffset); // Set offset after successful fetch
      }
    } catch (error) {
      console.error('Error fetching projects:', error);
    } finally {
      setIsLoading(false);
      setMoreLoading(false);
    }
  };

  const handleRefresh = () => {
    setIsLoading(true);
    fetchProjects(true);
  };
  const handleNavigation = (screenName, params = {}) => {
    navigation.navigate('ProfessionalStack', {screen: screenName, params});
  };
  const onCardPress = item => {
    // console.log('item',item.id)
    handleNavigation('ProjectDetails', {
      id: item.id,
      bidId: item?.bid_id,
      cScreen: true,
    });
  };
  return (
    <View style={styles.section}>
      <NewHeader header="My Projects" hideBackButton />
      <View style={styles.myProjects}>
        <FlatList
          data={bidProjects}
          keyExtractor={(_, index) => index.toString()}
          renderItem={({item, index}) => (
            <NewProjectCard
              item={item}
              index={index}
              onCardPress={() => onCardPress(item)}
              hidePostedDate
              hideBidCount
              currency={getUserDetails?.country == 'IN' ? 'INR' : 'USD'}
            />
          )}
          contentContainerStyle={{paddingBottom: hp(10)}}
          refreshControl={
            <RefreshControl
              refreshing={isLoading}
              onRefresh={handleRefresh}
              colors={[Colors.sooprsblue]}
            />
          }
          ListEmptyComponent={
            <Image
              source={Images.mBids}
              style={styles.emptyMessage}
              resizeMode="contain"
            />
          }
          ListFooterComponent={
            hasMore &&
            !isLoading && (
              <CustomButton
                loading={moreLoading}
                buttonText="Show more"
                onButtonPress={() => fetchProjects()}
              />
            )
          }
        />
      </View>
    </View>
  );
};

export default Projects;

const styles = StyleSheet.create({
  section: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  myProjects: {
    alignSelf: 'center',
  },
  emptyMessage: {
    height: hp(40),
    width: wp(65),
    alignSelf: 'center',
    marginTop: hp(10),
  },
});
