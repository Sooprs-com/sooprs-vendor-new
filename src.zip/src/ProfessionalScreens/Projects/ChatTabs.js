import {StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import {wp} from '../../assets/commonCSS/GlobalCSS';
import Colors from '../../assets/commonCSS/Colors';

const ChatTabs = ({activeIndex = 0, setActiveTab}) => {
  const tabs = ['Assigned Projects', 'Purchased Gigs', 'Sold Gigs'];
  return (
    <View style={styles.container}>
      {tabs.map((item, index) => {
        return (
          <TouchableOpacity
            activeOpacity={0.5}
            onPress={() => setActiveTab(index)}
            style={{
              flex: 1,
              borderBottomWidth: activeIndex == index ? 1.5 : 0,
              borderBottomColor: Colors.sooprsblue,
              alignItems: 'center',
              paddingVertical: 10,
            }}>
            <Text
              style={{
                color: activeIndex == index ? Colors.sooprsblue : Colors.black,
                fontWeight: '500',
              }}
              key={index}>
              {item}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
};

export default ChatTabs;

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    width: wp(90),
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: Colors.lightgrey1,
    marginVertical: 10,
    borderRadius: 5,
  },
});
