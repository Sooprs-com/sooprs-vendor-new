import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  FlatList,
  RefreshControl,
} from 'react-native';
import React, {useCallback, useEffect, useState} from 'react';
import Images from '../../assets/image';
import FSize from '../../assets/commonCSS/FSize';
import Colors from '../../assets/commonCSS/Colors';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import {useIsFocused} from '@react-navigation/native';
import NewHeader from '../../components/NewHeader';
import {mobile_siteConfig} from '../../services/mobile-siteConfig';
import {useSelector} from 'react-redux';
import NewProjectCard from '../../components/NewProjectCard';
import ChatTabs from './ChatTabs';

const AssignedProjects = ({navigation}: {navigation: any}) => {
  const [assignedProjects, setAssignedProjects] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const isFocused = useIsFocused();
  const getUserId = useSelector(state => state?.getUserId);
  const [activeTab, setActiveTab] = useState(0);
  const getUserDetails = useSelector(state => state?.getUserDetails);
  useEffect(() => {
    getAssignedProjects();
  }, [isFocused, activeTab]);

  const getAssignedProjects = async () => {
    try {
      setRefreshing(true); // Start the refreshing indicator
      const reqUrl =
        'https://sooprs.com/api2/public/index.php/get_professional_projects';
      const formdata = new FormData();
      formdata.append('variable', getUserId);
      formdata.append('cur', getUserDetails?.country == 'IN' ? 'INR' : 'USD');
      const response = await fetch(reqUrl, {
        method: 'POST',
        body: formdata,
        headers: {},
      });
      const responseData = await response?.json();
      if (responseData.status === 200) {
        setAssignedProjects(responseData.msg);
        console.log('e', responseData.msg, formdata);
      } else if (responseData.status === 400) {
        console.error('An error has occurred!');
      }
    } catch (error) {
      console.error('Error fetching projects:', error);
    } finally {
      setRefreshing(false);
    }
  };
  const RenderGigCards = ({item, index}) => {
    return <Text style={{color: 'red'}}>Heloo</Text>;
  };
  const onRefresh = useCallback(() => {
    setRefreshing(true);
    getAssignedProjects();
  }, []);
  const handleNavigation = (screenName, params = {}) => {
    navigation.navigate('ProfessionalStack', {screen: screenName, params});
  };
  const handleCardPress = item => {
    handleNavigation('IndividualChat', {
      name: item?.Customer_name,
      cust_image: item?.Customer_image,
      userId: getUserId,
      leadId: item?.id,
      bidId: item?.myLeadId,
      recieverId: item?.customer_id,
      id: item?.id,
      project_status: item?.project_status,
    });
  };
  return (
    <View style={styles.container}>
      <NewHeader header={'Assigned Projects'} hideBackButton />
      <View style={{alignItems: 'center'}}>
        {/* <ChatTabs setActiveTab={setActiveTab} activeIndex={activeTab}/> */}
        <FlatList
          data={assignedProjects}
          contentContainerStyle={{paddingBottom: hp(15)}}
          renderItem={({item, index}) => {
            // console.log('item',item)
            return activeTab == 0 ? (
              <NewProjectCard
                item={item}
                hideBidCount
                hidePostedDate
                currency={getUserDetails?.country == 'IN' ? 'INR' : 'USD'}
                index={index}
                onCardPress={() => handleCardPress(item)}
              />
            ) : (
              <RenderGigCards item={item} index={index} />
            );
          }}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={[Colors.sooprsblue]}
            />
          }
          ListEmptyComponent={
            <Image
              source={Images.emptyChat}
              style={styles.emptyMessage}
              resizeMode="contain"
            />
          }
        />
      </View>
    </View>
  );
};

export default AssignedProjects;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  headerSection: {
    marginHorizontal: wp(5),
    marginVertical: hp(1),
    flexDirection: 'row',
    alignItems: 'center',
    gap: wp(2),
  },
  backArrow: {
    width: wp(8),
    height: hp(8),
  },
  headerTitle: {
    color: Colors.black,
    fontWeight: '500',
    fontSize: FSize.fs16,
  },
  loadingText: {
    textAlign: 'center',
    color: Colors.sooprsblue,
    fontSize: FSize.fs14,
    marginVertical: hp(1),
  },
  myProjects: {
    marginHorizontal: wp(5),
  },

  assigned: {
    marginHorizontal: wp(5),
  },

  emptyMessage: {
    height: hp(40),
    width: wp(65),
    alignSelf: 'center',
    marginTop: hp(10),
  },
  tabcontainer: {
    width: wp(90),
    backgroundColor: Colors.lightgrey1,
    // borderRadius: 12,
    alignSelf: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 10,
    overflow: 'hidden',
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    paddingVertical: hp(1.5),
    paddingHorizontal: 3,
  },
  activeTab: {
    flex: 1,
    // backgroundColor: Colors.sooprslight,
  },
  tabText: {
    color: 'black',
    fontSize: 14,
    fontWeight: '500',
  },
  activeText: {
    color: Colors.sooprsblue, // Active tab text color
  },
  activeIndicator: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    borderBottomWidth: 2,
    borderColor: Colors.sooprsblue,
  },
});
