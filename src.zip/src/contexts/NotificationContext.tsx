import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface NotificationData {
  id?: string;
  title?: string;
  body?: string;
  data?: any;
  priority?: 'low' | 'normal' | 'high';
  actionButtons?: {
    okText?: string;
    cancelText?: string;
    showCancel?: boolean;
  };
}

interface NotificationContextType {
  notification: NotificationData | null;
  showNotification: (notification: NotificationData) => void;
  hideNotification: () => void;
  handleNotificationOk: () => void;
  handleNotificationCancel: () => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

interface NotificationProviderProps {
  children: ReactNode;
}

export const NotificationProvider: React.FC<NotificationProviderProps> = ({ children }) => {
  const [notification, setNotification] = useState<NotificationData | null>(null);

  const showNotification = (notificationData: NotificationData) => {
    setNotification(notificationData);
  };

  const hideNotification = () => {
    setNotification(null);
  };

  const handleNotificationOk = () => {
    // You can add custom logic here for OK button
    console.log('Notification OK pressed:', notification);
    
    // You can navigate to specific screen based on notification data
    if (notification?.data?.screen) {
      // Add navigation logic here
      console.log('Navigate to:', notification.data.screen);
    }
    
    hideNotification();
  };

  const handleNotificationCancel = () => {
    // You can add custom logic here for Cancel button
    console.log('Notification cancelled:', notification);
    hideNotification();
  };

  return (
    <NotificationContext.Provider
      value={{
        notification,
        showNotification,
        hideNotification,
        handleNotificationOk,
        handleNotificationCancel,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotification = (): NotificationContextType => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotification must be used within NotificationProvider');
  }
  return context;
};
