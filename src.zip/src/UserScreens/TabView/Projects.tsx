import {
  FlatList,
  StyleSheet,
  View,
  RefreshControl,
  Image,
  ActivityIndicator,
} from 'react-native';
import React, {useEffect, useState, useCallback} from 'react';
import Colors from '../../assets/commonCSS/Colors';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import {useIsFocused, useNavigation} from '@react-navigation/native';
import Images from '../../assets/image';
import NewProjectCard from '../../components/NewProjectCard';
import {useSelector} from 'react-redux';
import CustomButton from '../../components/CustomButton';

const Projects = ({navigation: navigationProp}: {navigation?: any}) => {
  const navigation = useNavigation();
  const nav = navigationProp || navigation;
  const [projectDetails, setProjectDetails] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [offset, setOffset] = useState(0);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true );
  const getUserDetails = useSelector((state: any) => state?.getUserDetails);
  const isFocused = useIsFocused();
  const getUserId = useSelector((state: any) => state?.getUserId);
  const currency=getUserDetails?.country == 'IN' ? 'INR' : 'USD';
  useEffect(() => {
    getProjects(true); // Reset data when screen is focused
  }, [isFocused]);

  const getProjects = async (isNewFetch = false) => {
    if (isNewFetch) {
      setOffset(0);
      setProjectDetails([]);
      setHasMore(true); // Reset pagination flag
    }

    if (!hasMore) return;

    const newOffset = isNewFetch ? 0 : offset;

    const formdata = new FormData();
    formdata.append('variable', getUserId);
    formdata.append('offset', newOffset);
    formdata.append('limit', 10);
    formdata.append('cur',currency)
    try {
      if (isNewFetch) setLoading(true);
      else setIsLoadingMore(true);

      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/get_enquiries_ajax',
        {method: 'POST', body: formdata},
      );

      const responseData = await response.json();

      if (responseData.status === 200) {
        setProjectDetails(prev => {
          const existingIds = new Set(prev.map(item => item.id));
          const newItems = responseData.msg.filter((item: any) =>
            !existingIds.has(item.id),
          );

          // If no new items, stop further fetching
          if (newItems.length === 0) {
            setHasMore(false);
          }

          return isNewFetch ? newItems : [...prev, ...newItems];
        });

        if (responseData.msg.length > 0) {
          setOffset(prevOffset => prevOffset + 10);
        }
      } else {
        setHasMore(false);
      }
    } catch (error) {
      console.error('Error fetching projects:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
      setIsLoadingMore(false);
    }
  };

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    getProjects(true);
  }, []);

  const loadMoreProjects = () => {
    if (!isLoadingMore) {
    
      getProjects();
    }
  };

  const onCardPress = (item: any) => {
    nav.navigate('ClientProjectDetails', {
      id: item?.id, 
      project_status: item?.project_status
    });
  };

  if (loading) return <ActivityIndicator color={Colors.sooprsblue} />;

  return (
    <View style={styles.projectsList}>
      <FlatList
        data={projectDetails}
        renderItem={({item, index}) => (
          <NewProjectCard
            item={item}
            index={index}
            currency={currency}
            onCardPress={() => onCardPress(item)}
          />
        )}
        keyExtractor={(item, index) => index.toString()}
        showsHorizontalScrollIndicator={false}
        ListEmptyComponent={
          <Image
            source={Images.nodata}
            style={styles.emptyList}
            resizeMode="contain"
          />
        }
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={[Colors.sooprsblue]}
          />
        }
        ListFooterComponent={
          hasMore &&
          projectDetails.length > 0 ? (
            <CustomButton
              buttonText={'Load more...'}
              buttonStyle={{marginVertical: 10}}
              textStyle={{}}
              onButtonPress={loadMoreProjects}
              loading={isLoadingMore}
            />
          ) : null
        }
      />
    </View>
  );
};

export default Projects;

const styles = StyleSheet.create({
  projectsList: {
    backgroundColor: Colors.white,
    flex: 1,
    marginHorizontal: wp(2),
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyList: {
    height: hp(40),
    width: wp(65),
    alignSelf: 'center',
    marginTop: hp(10),
  },
});
