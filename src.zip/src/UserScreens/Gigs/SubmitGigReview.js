import {
  Image,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import FSize from '../../assets/commonCSS/FSize';
import Colors from '../../assets/commonCSS/Colors';
import Images from '../../assets/image';
import CustomButton from '../../components/CustomButton';
import {useGigApis} from './GigApis';
const iconSize = Math.min(wp(8), hp(2.5));
const SubmitGigReview = ({
  review,
  setReview,
  selectedIndex,
  setSelectedIndex,
  handleSubmit,
}) => {
  return (
    <View style={styles.container}>
      <Text style={styles.headerText}>Post a review</Text>
      <View style={{flexDirection: 'row', marginBottom: 10}}>
        {Array.from({length: 5}).map((_, index) => {
          return (
            <TouchableOpacity
              key={index}
              style={{height: iconSize, width: iconSize, marginRight: 6}}
              activeOpacity={0.6}
              onPress={() => setSelectedIndex(index)}>
              <Image
                source={Images.star}
                style={{height: '100%', width: '100%'}}
                resizeMode="contain"
                tintColor={selectedIndex < index ? Colors.lightGrey : 'gold'}
              />
            </TouchableOpacity>
          );
        })}
      </View>
      <TextInput
        style={styles.input}
        placeholder="Write your review"
        textAlignVertical="top"
        multiline
        placeholderTextColor={Colors.gray}
        value={review}
        onChangeText={setReview}
      />
      <CustomButton
        buttonStyle={styles.submitButton}
        buttonText="Submit"
        onButtonPress={handleSubmit}
      />
    </View>
  );
};

export default SubmitGigReview;

const styles = StyleSheet.create({
  container: {
    width: wp(90),
    alignSelf: 'center',
  },
  headerText: {
    fontSize: FSize.fs22,
    color: Colors.black,
    fontWeight: '500',
    marginBottom: 10,
  },
  input: {
    borderWidth: 1,
    height: hp(18),
    borderColor: '#ccc',
    borderRadius: 12,
    padding: 16,
    width: '100%',
    marginBottom: 14,
    color: Colors.black,
  },
  submitButton: {
    width: '45%',
    alignSelf: 'flex-start',
    borderRadius: 12,
    marginBottom: hp(3),
  },
});
