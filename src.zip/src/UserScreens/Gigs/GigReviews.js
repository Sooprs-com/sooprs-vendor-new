import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import Colors from '../../assets/commonCSS/Colors';
import Images from '../../assets/image';
import FSize from '../../assets/commonCSS/FSize';
const iconSize = Math.min(wp(16), hp(7));
const GigReviews = ({data = []}) => {
  if (data.length < 1) return;
  return (
    <View style={{flex: 1}}>
      <Text style={styles.headerText}>Reviews({data.length})</Text>
      {data.map((item, index) => {
        return (
          <View style={styles.card}>
            <View style={styles.header}>
              <Image
                source={{uri: item?.image}}
                style={styles.avatar}
                defaultSource={Images.defaultPicIcon}
              />
              <View>
                <Text style={styles.name}>{item?.name}</Text>
                <View style={styles.ratingContainer}>
                  {Array.from({length: item?.stars}).map((_, index) => {
                    return (
                      <TouchableOpacity
                        key={index}
                        style={{
                          height: 20,
                          width: 20,
                          marginRight: 6,
                        }}
                        activeOpacity={0.6}
                        onPress={() => {}}>
                        <Image
                          source={Images.star}
                          style={{height: '100%', width: '100%'}}
                          resizeMode="contain"
                        />
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </View>
            </View>
            <View>
              <Text style={styles.review}>{item?.review}</Text>
            </View>
          </View>
        );
      })}
    </View>
  );
};

export default GigReviews;

const styles = StyleSheet.create({
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: hp(1),
  },
  star: {
    fontSize: wp(4),
    color: '#dcdcdc',
  },
  filledStar: {
    color: '#F4DE25',
  },
  emptyStar: {
    color: '#dcdcdc',
  },
  rating: {
    marginLeft: wp(2),
    fontSize: wp(4),
    color: 'gray',
  },
  avatar: {
    width: iconSize,
    height: iconSize,
    borderRadius: iconSize / 2,
    marginRight: 8,
  },
  name: {
    fontSize: wp(4),
    fontWeight: 'bold',
    color: Colors.black,
  },
  review: {
    color: Colors.gray,
  },
  card: {
    flexWrap: 'wrap',
    borderRadius: 10,
    padding: wp(4),
    marginVertical: hp(1),
    borderWidth: 1,
    borderColor: '#ccc',
    width: wp(90),
    alignSelf: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: hp(1),
  },
  headerText: {
    fontSize: FSize.fs22,
    color: Colors.black,
    fontWeight: '500',
    marginBottom: 10,
    width: wp(90),
    alignSelf: 'center',
  },
});
