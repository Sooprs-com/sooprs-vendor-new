import {View, Text, StyleSheet, Image, FlatList,ActivityIndicator} from 'react-native';
import React, { useEffect, useState } from 'react';
import NewHeader from '../../components/NewHeader';
import Colors from '../../assets/commonCSS/Colors';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import FSize from '../../assets/commonCSS/FSize';
import Images from '../../assets/image';
import {useSelector} from 'react-redux';

const MyGigsCardComponent=({item})=>{
    // console.log("Item Of Data::::",item)
    return(
        <View
        style={{
          marginHorizontal: wp(4),
          // marginTop: hp(2),
          marginBottom:hp(2),
          borderWidth: 1,
          borderTopRightRadius:12,
          borderTopLeftRadius:12,
          // borderRadius: 12,
          overflow: 'hidden',
          borderColor: '#ccc',
          backgroundColor:"white",
          borderRadius:hp(2),
          paddingBottom:hp(1)

        }}>
        {/* Image Contener */}
        <View
          style={{
            width: '100%',
            height: hp(25),
            backgroundColor: '#999999',
            // borderRadius: hp(2),
            overflow:"hidden"
          }}>
          <Image  source={{uri: `https://sooprs.com/assets/files/${item?.item?.gig_img}`}} style={{
            width:"100%",
            height:"100%"
          }}/>
        </View>
        <View
          style={{
            marginHorizontal: wp(3),
          }}>
          <Text
            style={{
              fontWeight: '400',
              fontSize: FSize.fs16,
              color:'#444444',
              marginBottom: hp(2),
            }}>
           {item?.item?.gig_title}
          </Text>

        {/* Statr And Price Contener */}
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginHorizontal: wp(2),
          }}>
            <View style={styles.starContainer}>
              <Image
                source={Images.star}
                style={{height: 15, width: 15}}
                resizeMode="contain"
              />
              {/* <Text style={styles.ratingText}>{item?.gig_rating ?? 0}</Text> */}
              <Text style={styles.ratingText}>{item?.item?.gig_rating==null?0:item?.item?.gig_rating}</Text>
            </View>
            <Text style={styles.priceText}>{item?.item?.gig_price} USD</Text>
          </View>

        </View>
       </View>
    )
}
const MyGigs = ({navigation, route}) => {
  const {header} = route?.params || {};
  const userDetails=useSelector((state)=>state?.getUserDetails)
  // console.log("User Details::::", userDetails)
  const [gigs,setGigs]=useState([])
  const [loading, setLoading] = useState(true);

  const getUserInformation = async () => {
    // console.log('userDetails==>', "hello");
    const formdata = new FormData();
    formdata.append('professional_slug',userDetails?.slug);
    formdata.append('cur','USD');
      // console.log('formdata==>', formdata);
    try {
      const res = await fetch(
        'https://sooprs.com/api2/public/index.php/get_my_gigs',
        {
          method: 'POST',
          body: formdata,
        },
      );
      const response = await res?.json();
      // console.log("Responce of User Details:::::",response)
      if (response?.status == 200) {
        // setUserInformation(response?.msg[0]);
        // console.log('userInformation==>', response?.msg);
        setGigs(response?.msg);
      }
    } catch (error) {
      console.error('Error fetching user details:', error);
    } finally {
      setLoading(false);
}
}

useEffect(()=>{
    getUserInformation()
},[userDetails])
//   console.log('header:::::::', header);
  return ( 
    <View style={styles.container}>
      <NewHeader navigation={navigation} header={header ?? ''} />
      {
        loading ? (
          <ActivityIndicator
            color={Colors.sooprsblue}
            style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}
          />
        ):(
          <View style={{
            marginBottom:hp(10)
        }}>
           <FlatList
            data={gigs}
            style={{
              paddingTop:hp(2)
            }}
            keyExtractor={(item) => item.toString()}
            renderItem={(item)=>{
                
                return(
                    <MyGigsCardComponent item={item}/>
                )
            }}
            ListEmptyComponent={
              <Image
                source={Images.nodata}
                style={{
                  height: hp(40),
                  width: wp(65),
                  alignSelf: 'center',
                  marginTop: hp(10),
                }}
                resizeMode="contain"
              />
            }
           /> 
        {/* <MyGigaCardComponent/> */}
          </View>
        )
      } 
    </View>
  );
};

export default MyGigs;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  starContainer: {flexDirection: 'row', alignItems: 'center'},
  ratingText: {marginLeft: 8, color: 'gold', fontSize: FSize.fs16},
  priceText: {
    color: Colors.sooprsblue,
    fontWeight: '500',
    marginVertical: 6,
    // marginLeft: 8,
  },
});
