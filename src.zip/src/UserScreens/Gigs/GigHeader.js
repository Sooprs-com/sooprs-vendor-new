import {
  Image,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import Colors from '../../assets/commonCSS/Colors';
import Images from '../../assets/image';
import FSize from '../../assets/commonCSS/FSize';
const iconSize = Math.min(wp(7), hp(4));
const GigHeader = ({
  input,
  setInput,
  setGigData,
  originalData = [],
  isProfessional,
  navigation,
  onFilterPress,
}) => {
  const handleSearch = param => {
    if (!param.trim()) {
      setGigData(originalData);
      return;
    }
    const filteredGigs = originalData.filter(
      item =>
        item.gig_title.toLowerCase().includes(param?.toLowerCase()) ||
        item.gig_tags
          ?.split(',')
          .some(tag => tag.toLowerCase().includes(param.toLowerCase())) ||
        item.gig_price.toString().includes(param) ||
        item?.professional?.name?.toLowerCase().includes(param?.toLowerCase()),
    );
    setGigData(filteredGigs);
  };

  return (
    <View>
      <View style={styles.container}>
        <Text style={[styles.gigText, {fontSize: FSize.fs16, paddingTop:Platform.OS === 'ios' ? hp(6) : hp(2)}]}>
          Browse Gigs
        </Text>
        {isProfessional == 0 && (
          <TouchableOpacity
            style={styles.button}
            activeOpacity={0.7}
            onPress={() => navigation.navigate('CreateGig')}>
            <Image
              source={Images.addIcon}
              style={{height: iconSize, width: iconSize, marginRight: 4}}
              resizeMode="contain"
            />
            <Text style={styles.gigText}>Create Gig</Text>
          </TouchableOpacity>
        )}
      </View>
      <View style={styles.searchRow}>
        <TextInput
          value={input}
          onChangeText={text => {
            setInput(text);
            handleSearch(text);
          }}
          placeholder="Search..."
          placeholderTextColor={Colors.gray}
          style={styles.input}
        />
        {/* <TouchableOpacity
          activeOpacity={0.6}
          onPress={() =>
            navigation
              .getParent('RightDrawer')
              .dispatch(DrawerActions.openDrawer())
          }>
          <Image
            source={Images.filterIcon1}
            style={{height: iconSize, width: iconSize}}
          />
        </TouchableOpacity> */}
      </View>
    </View>
  );
};

export default GigHeader;

const styles = StyleSheet.create({
  container: {
    width: wp(100),
    backgroundColor: Colors.sooprsDark,
    paddingVertical: hp(2),
    height: Platform.OS === 'ios' ? hp(12) : hp(8),
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-end',
  },
  gigText: {
    // paddingTop:hp(6),
    color: Colors.white,
    fontSize: FSize.fs14,
    fontWeight: '500',
  },
  searchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    alignItems: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: Colors.lightGrey,
    borderRadius: 12,
    flex: 1,
    marginRight: 12,
    padding: 10,
    color: Colors.black,
  },
});
