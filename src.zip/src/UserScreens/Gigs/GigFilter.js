import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import { hp } from '../../assets/commonCSS/GlobalCSS';

const GigFilter = () => {
  return (
    <View style={{width:100,height:hp(100)}}>
      <Text>GigFilter</Text>
      <Text>Hekllkllli</Text>
    </View>
  );
};

export default GigFilter;

const styles = StyleSheet.create({});
