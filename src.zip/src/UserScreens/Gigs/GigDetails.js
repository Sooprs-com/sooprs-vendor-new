import {
  ActivityIndicator,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import Colors from '../../assets/commonCSS/Colors';
import NewHeader from '../../components/NewHeader';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import AboutGig from './AboutGig';
import SubmitGigReview from './SubmitGigReview';
import GigReviews from './GigReviews';
import {useGigApis} from './GigApis';
import {useSelector} from 'react-redux';
import Toast from 'react-native-toast-message';

const GigDetails = ({navigation, route}) => {
  const {item = {}, professionalId = ''} = route?.params || {};
  const [review, setReview] = useState('');
  const getUserId = useSelector(state => state?.getUserId);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [gigDetails, setGigDetails] = useState({});
  const {
    postReview,
    postingReview,
    verifyOrder,
    createOrder,
    getGigDetail,
    gigDetailsLoading,
  } = useGigApis();
  const [buyLoader, setBuyLoader] = useState(false);
  const getUserDetails = useSelector(state => state?.getUserDetails);
  // get gig Details
  useEffect(() => {
    getGigInfo();
  }, []);
  const getGigInfo = async () => {
    const payload = new FormData();
    payload.append('gigId', item?.gig_unique_id);
    payload.append('cur', getUserDetails?.country == 'IN' ? 'INR' : 'USD');
    try {
      const res = await getGigDetail(payload);
      setGigDetails(res);
    } catch (error) {
      console.log('err', error);
    }
  };
  // post review function and api call
  const handlePostReview = async () => {
    if (review.length < 3) {
      Toast.show({
        type: 'info',
        text1: 'Enter your review',
        text2: 'Please enter your review about the gig.',
      });
    }
    try {
      const payload = new FormData();
      const gigPaylod = new FormData();
      gigPaylod.append('gigId', gigDetails?.gig_unique_id);
      payload.append('user_id', getUserId);
      payload.append('gig_id', gigDetails?.gig_id);
      payload.append('rating', selectedIndex + 1);
      payload.append('review', review);
      await postReview(payload);
      // to refresh the reviews
      await getGigInfo(gigPaylod);
      setReview('');
      setSelectedIndex(0);
    } catch (error) {}
  };

  const handlePayment = async () => {
    // setBuyLoader(true);

    const amount =
      getUserDetails?.country == 'IN'
        ? gigDetails?.gig_price * 100
        : gigDetails?.gig_price * 85 * 100;
    const amountInPaise = amount.toString();

    try {
      const res = await createOrder(amountInPaise);
      if (res?.razorpay_payment_id) {
        const payload = new FormData();
        payload.append('amount', amountInPaise);
        payload.append('user_id', getUserId);
        payload.append('gig_id', gigDetails?.gig_unique_id);
        payload.append('seller_id', professionalId);
        payload.append('payment_id', res?.razorpay_payment_id);
        payload.append('order_id', res?.razorpay_order_id);
        payload.append('signature', res?.razorpay_signature);
        const response = await verifyOrder(payload);
        console.log('response==>', response);
        // if (response?.status == 201) {
        //   navigation.navigate('Chat', {
        //     gig_id: item?.gig_id,
        //     seller_id: professionalId,
        //   });
        // }
        // further implementation
      }
      console.log('res--', res);
    } catch (error) {
      console.log('err', error);
    } finally {
      setBuyLoader(false);
    }
  };
  return (
    <View style={styles.container}>
      <NewHeader navigation={navigation} header={'Gig details'} />
      <ScrollView showsVerticalScrollIndicator={false}>
        {gigDetailsLoading ? (
          <ActivityIndicator
            color={Colors.sooprsblue}
            style={{marginTop: hp(10)}}
            size={25}
          />
        ) : (
          <>
            <View style={styles.imgContainer}>
              <Image
                source={{
                  uri: `https://sooprs.com/assets/files/${gigDetails?.gig_img}`,
                }}
                style={styles.gigImgStyle}
                resizeMode="cover"
              />
            </View>
            <AboutGig
              item={gigDetails}
              handlePayment={handlePayment}
              loading={buyLoader}
              currency={getUserDetails?.country == 'IN' ? 'INR' : 'USD'}
            />
            <SubmitGigReview
              review={review}
              setReview={setReview}
              selectedIndex={selectedIndex}
              setSelectedIndex={setSelectedIndex}
              handleSubmit={handlePostReview}
            />
            <GigReviews data={gigDetails?.reviews || []} />
          </>
        )}
      </ScrollView>
    </View>
  );
};

export default GigDetails;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  imgContainer: {
    height: hp(22),
    overflow: 'hidden',
    width: wp(90),
    alignSelf: 'center',
    marginVertical: 15,
    // backgrounColor: Colors.white
  },
  gigImgStyle: {height: '100%', width: '100%', borderRadius: 18},
});
