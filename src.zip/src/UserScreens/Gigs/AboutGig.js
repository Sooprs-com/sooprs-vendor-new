import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import Colors from '../../assets/commonCSS/Colors';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import FSize from '../../assets/commonCSS/FSize';
import CustomButton from '../../components/CustomButton';
const AboutGig = ({item, handlePayment, loading, currency}) => {
  //
  const gigRecord = [
    {
      heading: 'Total\nSales',
      value: item?.total_sales,
    },
    {
      heading: 'Response\nSales',
      value: item?.total_sales,
    },
    {
      heading: 'Delivery\nTime',
      value: `${item?.dilivery_time} Days`,
    },
  ];

  const tags = item?.gig_tags?.split(',') || [];
  const tech = item?.technologies || [];
  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <View style={styles.items}>
          {gigRecord.map((item, indx) => {
            return (
              <View key={indx} style={styles.cardItems}>
                <Text style={styles.recordText}>{item?.heading}</Text>
                <Text style={styles.recordText}>{item?.value}</Text>
              </View>
            );
          })}
        </View>
        <View style={styles.purchaseContainer}>
          <Text style={styles.priceText}>
            {currency == 'INR' ? '₹' : '$'} {item?.gig_price ?? 0}
          </Text>
          <CustomButton
            buttonStyle={{width: '50%', borderRadius: 12}}
            buttonText="Buy this gig"
            onButtonPress={handlePayment}
            loading={loading}
          />
        </View>
      </View>
      <View style={styles.section}>
        <Text style={[styles.priceText]}>About your gig</Text>
        <Text style={styles.des}>{item?.gig_desc}</Text>
      </View>
      <View style={styles.section}>
        <Text style={styles.priceText}>Related Tags</Text>
        <View style={styles.tagContainer}>
          {tags.map((item, index) => (
            <View key={index} style={styles.tagWrapper}>
              <Text style={styles.tagText}>{item}</Text>
            </View>
          ))}
        </View>
      </View>
      {tech?.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.priceText}>Technologies</Text>
          <View style={styles.tagContainer}>
            {tech.map((item, index) => (
              <View key={index} style={styles.tagWrapper}>
                <Text style={styles.tagText}>{item}</Text>
              </View>
            ))}
          </View>
        </View>
      )}
    </View>
  );
};

export default AboutGig;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  card: {
    // alignItems: 'center',
    alignSelf: 'center',
    width: wp(90),
    borderWidth: 0.6,
    borderColor: '#ccc',
    borderRadius: 12,
    padding: 16,
  },
  cardItems: {alignItems: 'center'},
  items: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  recordText: {
    color: Colors.black,
    fontWeight: '500',
    textAlign: 'center',
    lineHeight: FSize.fs23,
  },
  purchaseContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: hp(5),
  },
  priceText: {
    fontSize: FSize.fs22,
    color: Colors.black,
    fontWeight: '500',
    marginRight: 10,
  },
  section: {width: wp(90), alignSelf: 'center', marginVertical: 12},
  des: {
    color: '#444444',
    marginTop: 6,
  },
  tagContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  tagWrapper: {
    width: '48%',
    marginBottom: 10,
    padding: 10,
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
    alignItems: 'center',
  },
  tagText: {
    fontSize: 14,
    color: Colors.black,
  },
});
