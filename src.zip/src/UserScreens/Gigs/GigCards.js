import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React, {useEffect} from 'react';
import Images from '../../assets/image';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import Colors from '../../assets/commonCSS/Colors';
import FSize from '../../assets/commonCSS/FSize';
import {useSelector} from 'react-redux';
const iconSize = Math.min(wp(7), hp(4));
const GigCards = ({item, index, navigation, currency}) => {
  const userDetails = useSelector(state => state?.getUserDetails);

  const professionalId = item?.professional?.id;
  const handleNavigation = (screenName, params = {}) => {
    navigation.navigate('ProfessionalStack', {screen: screenName, params});
  };
  const source = `https://sooprs.com/assets/files/${item?.gig_img}`;
  return (
    <TouchableOpacity
      key={index}
      style={styles.cards}
      onPress={() => handleNavigation('GigDetails', {item, professionalId})}>
      <View
        style={{
          width: '50%',
          // borderWidth:hp(1),
          // borderColor:"black",
          borderRadius: hp(0.5),
        }}>
        <Image
          source={{uri: source}}
          style={{width: '100%', height: hp(16)}}
          resizeMode="stretch"
        />
      </View>
      <View style={{justifyContent: 'space-between'}}>
        <View>
          <View style={styles.titleContainer}>
            <Image
              source={{uri: item?.professional?.image}}
              style={styles.img}
            />
            <View>
              <Text numberOfLines={1} style={styles.name}>
                {item?.professional?.name}
              </Text>
              <View style={styles.starContainer}>
                <Image
                  source={Images.star}
                  style={{height: 12, width: 12}}
                  resizeMode="contain"
                />
                <Text style={styles.ratingText}>
                  {Number(item?.gig_rating).toFixed(1).toString() ?? 0}
                </Text>
              </View>
            </View>
          </View>
          <View style={{margin: 4, width: '68%'}}>
            {item?.gig_desc && (
              <Text style={{color: '#444444', fontSize: FSize.fs12}}>
                {item?.gig_title}
              </Text>
            )}
          </View>
        </View>

        <View
          style={{
            flexDirection: 'column',
            flexDirection: 'row',
            justifyContent: 'flex-end',
            width: '68%',
          }}>
          <Text style={styles.priceText}>
            {currency == 'INR' ? '₹' : '$'}
            {item?.gig_price}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default GigCards;

const styles = StyleSheet.create({
  cards: {
    // width: '100%',
    flexDirection: 'row',
    marginBottom: 12,
    // minHeight: hp(20),
    borderWidth: 1,
    borderRadius: 12,
    overflow: 'hidden',
    borderColor: '#ccc',
  },
  titleContainer: {flexDirection: 'row', alignItems: 'center', margin: 4},
  name: {
    width: '100%',
    marginLeft: 8,
    color: Colors.black,
    fontSize: FSize.fs13,
    fontWeight: '400',
  },
  img: {
    height: iconSize,
    width: iconSize,
    borderRadius: iconSize / 2,
  },
  starContainer: {flexDirection: 'row', alignItems: 'center', marginLeft: 8},
  ratingText: {marginLeft: 8, color: 'gold', fontSize: FSize.fs16},
  priceText: {
    color: Colors.sooprsblue,
    fontWeight: '500',
    marginVertical: 6,
    // alignSelf:"flex-end",
    // marginTop:hp(1)
    // marginLeft: 8,
  },
  priceContainer: {
    alignSelf: 'flex-end',
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 8,
  },
});
