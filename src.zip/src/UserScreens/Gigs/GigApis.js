import {useState} from 'react';
import {postDataWithToken1} from '../../services/mobile-api';
import {mobile_siteConfig} from '../../services/mobile-siteConfig';
import Toast from 'react-native-toast-message';
import {useSelector} from 'react-redux';
import RazorpayCheckout from 'react-native-razorpay';
import {Fetch} from 'socket.io-client';
export const useGigApis = () => {
  const [postingReview, setPostingReview] = useState(false);
  const [loading, setLoading] = useState(false);
  const [gigDetailsLoading, setGigDetailsLoading] = useState(true);
  const [error, setError] = useState(null);
  const {name, email, mobile} = useSelector(state => state?.getUserDetails);
  const getGigDetail = async payload => {
    // setGigDetailsLoading(true);
    try {
      const res = await fetch(
        'https://sooprs.com/api2/public/index.php/get_gig_details',
        {
          method: 'POST',
          body: payload,
        },
      );
      if (res?.status == 200) {
        const response = await res.json();
        return response?.msg;
      } else {
        throw new Error('Error while getting information');
      }
    } catch (error) {
      Toast.show({
        type: 'error',
        text1: 'Error',
        text2: error,
      });
    } finally {
      setGigDetailsLoading(false);
    }
  };
  //post review
  const postReview = async data => {
    setPostingReview(true);
    try {
      const res = await postDataWithToken1(
        data,
        mobile_siteConfig.INDEX + mobile_siteConfig.POST_GIG_REVIEW,
      );
      console.log('ress', res);
      if (res?.status == 200) {
        Toast.show({
          type: 'success',
          text1: 'Success',
          text2: 'Review posted successfully',
        });
      }
    } catch (error) {
      Toast.show({
        type: 'error',
        text1: 'Error',
        text2: 'Error while posting your review',
      });
    }
  };
  // get browse gigs data
  const getBrowseGigs = async payload => {
    setLoading(true);
    try {
      const res = await postDataWithToken1(
        payload,
        mobile_siteConfig.INDEX + mobile_siteConfig.GET_GIGS,
      );
      return res?.msg || [];
    } catch (error) {
      Toast.show({
        type: 'error',
        text1: 'Error',
        text2: 'Error while getting gigs',
      });
    } finally {
      setLoading(false);
    }
  };
  // create order for purchase
  const createOrder = async amt => {
    setLoading(true);
    const payload = new FormData();
    payload.append('amount', amt);
    try {
      const response = await fetch(mobile_siteConfig.CREATE_RAZORPAY_ORDER, {
        method: 'POST',
        body: payload,
      });
      if (!response.ok)
        throw new Error(`HTTP error! Status: ${response.status}`);

      const res = await response.json();
      if (res?.order_id) {
        // console.log('orderid',res?.order_id,name,email,mobile,amt)
        return await makePurchaseThroughRazorPay(
          res?.order_id,
          name,
          email,
          mobile,
          amt,
        );
      }
    } catch (error) {
      console.log('rr', error);
      setError(error);
      setLoading(false);
      throw error;
    }
  };

  // Calling Razorpay for Payment
  const makePurchaseThroughRazorPay = async (
    orderId,
    name,
    email,
    mobile,
    amount,
  ) => {
    const options = {
      description: 'Sooprs',
      image: 'https://sooprs.com/assets/images/sooprs_logo.png',
      currency: 'INR',
      key: 'rzp_live_0dVc0pFpUWFAqu',
      amount: amount,
      name: 'Sooprs.com',
      order_id: orderId,
      prefill: {
        email: email,
        contact: mobile,
        name: name,
      },
      theme: {
        color: '#0077FF',
      },
    };
    try {
      const res = await RazorpayCheckout.open(options);
      if (res?.razorpay_payment_id) {
        return res;
      }
    } catch (error) {
      console.error('Razorpay Payment Error:', error);
      setLoading(false);
      Toast.show({
        type: 'error',
        text1: 'Payment Error',
        text2: 'Payment has been cancelled',
      });
      throw error;
    }
  };

  // Verify Order Payment
  const verifyOrder = async payload => {
    // console.log('payload===>', payload);
    try {
      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/gig_order',
        {
          method: 'POST',
          body: payload,
          headers: {
            'Content-type': 'multipart/form-data',
          },
        },
      );
      if (response?.status === 200) {
        const res = await response?.json();
        Toast.show({
          type: 'success',
          text1: 'Success',
          text2: 'Congratutlation!, gig purchased successfully',
        });
        return res;
      } else {
        throw new Error('Order verification failed');
      }
    } catch (error) {
      console.error('Order Verification Error:', error);
      Toast.show({
        type: 'error',
        text1: 'Payment verification failed',
        text2: 'If any amount has been debited , please contact us.',
      });
      setLoading(false);
    }
  };
  return {
    postReview,
    postingReview,
    verifyOrder,
    createOrder,
    loading,
    getBrowseGigs,
    getGigDetail,
    gigDetailsLoading,
  };
};
