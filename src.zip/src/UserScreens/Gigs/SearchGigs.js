import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const SearchGigs = () => {
  return (
    <View>
      <Text>SearchGigs</Text>
    </View>
  )
}

export default SearchGigs

const styles = StyleSheet.create({})