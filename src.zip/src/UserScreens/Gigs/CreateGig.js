import {
  StyleSheet,
  Text,
  TextInput,
  View,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Image,
  Modal,
  Button,
  Alert,
  Pressable,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import Colors from '../../assets/commonCSS/Colors';
import GigHeader from './GigHeader';
import FSize from '../../assets/commonCSS/FSize';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import {getDataWithToken, postData} from '../../services/mobile-api';
import {launchImageLibrary} from 'react-native-image-picker';
import {mobile_siteConfig} from '../../services/mobile-siteConfig';
import Images from '../../assets/image';
import Toast from 'react-native-toast-message';
import {useSelector} from 'react-redux';
import NewHeader from '../../components/NewHeader';

const DropDownContainer = ({
  label,
  selectedValue,
  isOpen,
  setOpen,
  options,
  onSelect,
  setItem,
}) => {
  return (
    <View style={{marginTop: hp(2)}}>
      <TouchableOpacity
        style={styles.dropdownButton}
        onPress={() => setOpen(!isOpen)}>
        <Text
          style={[
            {color: Colors.gray},
            selectedValue === label && {color: Colors.black},
          ]}>
          {selectedValue ? selectedValue : label}
        </Text>
        <Image
          source={Images.downArrowLight}
          style={{
            height: hp(3),
            width: wp(3),
            resizeMode: 'contain',
          }}
        />
      </TouchableOpacity>
      {isOpen && (
        <View style={styles.dropdown}>
          <FlatList
            data={options}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({item}) => {
              // console.log("item Of Services:::",item)
              return (
                // <></>
                <TouchableOpacity
                  style={styles.option}
                  onPress={() => {
                    onSelect(item);
                    setOpen(false);
                    setItem && setItem(item);
                  }}>
                  <Text style={{color: Colors.gray}}>
                    {item?.service_name || item}
                  </Text>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      )}
    </View>
  );
};

const TextInputComponent = ({
  height,
  placeholder,
  value,
  onChangeText,
  keyboardType,
}) => {
  return (
    <View style={styles.inputContainer(height)}>
      <TextInput
        multiline
        placeholder={placeholder}
        value={value}
        // keyboardType="number-pad"
        keyboardType={keyboardType}
        onChangeText={onChangeText}
        placeholderTextColor={Colors.gray}
        style={{color: '#444444'}}
      />
    </View>
  );
};

const CreateGig = ({navigation}) => {
  const [categories, setCategories] = useState([]);
  const [allServices, setAllServices] = useState([]);
  const [tags, setTags] = useState([]);
  const [categoryItem, setCategoryItem] = useState();
  const [inputValue, setInputValue] = useState('');
  const [selectedFlags, setSelectedFlags] = useState([]);
  const [addedServices, setAddedServices] = useState([]);
  const [filteredServices, setFilteredServices] = useState([]);
  const [allTechnology, setAllTechnology] = useState([]);
  const getUserId = useSelector(state => state?.getUserId);
  const [responseTimes] = useState([
    '1 hours',
    '2 hours',
    '3 hours',
    '6 hours',
    '12 hours',
    '24 hours',
    '48 hours',
  ]);

  const [selectedCategory, setSelectedCategory] = useState({});
  const [selectedSubCategory, setSelectedSubCategory] = useState({});
  const [selectedResponseTime, setSelectedResponseTime] =
    useState('Response Time');

  const [openDropdown, setOpenDropdown] = useState(false);
  // const [isCategoryOpen, setIsCategoryOpen] = useState(false);
  // const [isSubCategoryOpen, setIsSubCategoryOpen] = useState(false);
  const [isResponseTimeOpen, setIsResponseTimeOpen] = useState(false);
  const [isChecked, setIsChecked] = useState(false);

  const [selectedImage, setSelectedImage] = useState(null);
  const [selectedItems, setSelectedItems] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);

  const [formDataval, setFormData] = useState({
    title: '',
    description: '',
    gigPrice: '',
    deliveryTime: '',
    tags: '',
  });

  const handleAddTag = () => {
    if (tags.length >= 5) {
      Alert.alert('You can only add up to 5 tags');
      return;
    }
    if (inputValue.trim() !== '' && !tags.includes(inputValue.trim())) {
      setTags([...tags, inputValue.trim()]);
      setInputValue('');
    }
  };

  const removeTag = index => {
    setTags(tags.filter((_, i) => i !== index));
  };

  const toggleModal = () => {
    setModalVisible(!modalVisible);
  };

  const selectItem = item => {
    if (selectedItems.length < 5 && !selectedItems.includes(item)) {
      setSelectedItems([...selectedItems, item]);
    }
  };

  const removeItem = item => {
    setSelectedItems(selectedItems.filter(i => i !== item));
  };

  const fetchSelectedServices = async () => {
    try {
      const response = await getDataWithToken(
        mobile_siteConfig.GET_SELECTED_CATEGORIES,
      );
      if (response?.status === 'success') {
        // const services = response.data.map(service => ({
        //   label: service.service_name,
        //   value: service.flag,
        // }));
        setCategories(response.data);
        console.log('respone Data::::::', response.data);
      }
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await postData({}, mobile_siteConfig.GET_CATEGORIES);
      if (response?.status === 200) {
        console.log('All SerVices Data response', response.msg);
        setAllServices(response.msg);
      }
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const handleFlagChange = flags => {
    const arr = Array.isArray(flags) ? flags : [flags];
    // console.log("Flag Data in Array:::",arr)
    setSelectedFlags(arr);
    console.log('All Service Data:::::', allServices);
    // Filter services based on the selected flags and not already added
    const filtered = allServices.filter(service =>
      arr?.some(item => item?.flag === service?.flag),
    );

    setFilteredServices(filtered);

    // Remove items from `addedServices` that no longer match the selected flags
    const updatedAddedServices = addedServices.filter(service =>
      arr.includes(service.flag),
    );
    setAddedServices(updatedAddedServices);
    // console.log('All Updated  Data:::', updatedAddedServices);
    // dropDownRef?.current?.close();
  };

  useEffect(() => {
    fetchSelectedServices();
    fetchCategories();
  }, []);

  const handleInputChange = (key, value) => {
    setFormData(prevFormData => ({...prevFormData, [key]: value}));
  };

  const openGallery = () => {
    const options = {
      mediaType: 'photo',
      quality: 1,
    };

    launchImageLibrary(options, response => {
      if (response.didCancel) {
        console.log('User cancelled image picker');
      } else if (response.errorMessage) {
        console.log('ImagePicker Error: ', response.errorMessage);
      } else {
        const source = response.assets[0];
        // console.log("Source of Image: ", source)
        setSelectedImage(source);
      }
    });
  };

  useEffect(() => {
    // console.log("Selecetd Category",categoryItem)
    handleFlagChange(categoryItem);
  }, [selectedCategory]);

  const getAllTechnology = async selectedCategory => {
    try {
      console.log('Selecetd Caregory::', selectedCategory);
      const response = await postData({}, mobile_siteConfig.GET_TECHNOLOGY);
      if (response?.status === 200) {
        // console.log('All Technology', response.msg);
        const category = response.msg;
        // console.log('All Filter Data::::', category);
        const FilterData = category.filter(
          item => item?.flag_id === selectedCategory?.flag,
        );
        // console.log('All Filtered Skill::::', FilterData);
        setAllTechnology(FilterData);
      }
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  useEffect(() => {
    getAllTechnology(selectedCategory);
  }, [selectedCategory]);

  const handleValidation = () => {
    // Check if the title is empty
    if (!formDataval?.title) {
      Alert.alert('Please enter a title');
      return;
    }

    if (!formDataval?.title.length > 80) {
      Alert.alert('Please enter a title min 80 characters');
      return;
    }

    if (Object.keys(selectedCategory).length === 0) {
      Alert.alert('Please select a category');
      return;
    }
    if (Object.keys(selectedSubCategory).length === 0) {
      Alert.alert('Please select a Sub Category');
      return;
    }

    // Check if the description is empty
    if (!formDataval?.description) {
      Alert.alert('Please enter a description');
      return;
    }

    // Check if the category is selected
    // Check if the sub-category is selected
    if (!selectedSubCategory) {
      Alert.alert('Please select a sub-category');
      return;
    }

    if (!selectedImage) {
      Alert.alert('Please select Image');
      return;
    }

    // Check if the response time is selected
    if (!selectedResponseTime.replace(/\D/g, '')) {
      Alert.alert('Please select a response time');
      return;
    }
    if (!formDataval.gigPrice) {
      Alert.alert('Please enter a valid gigPrice');
      return;
    }
    if (formDataval.gigPrice > 5800) {
      Alert.alert('GigPrice Should be < 5800');
      return;
    }

    // if (formDataval.gigPrice<5800) {
    //   Alert.alert('Please enter gigPrice > 5800');
    //   return;
    // }

    // Check if at least one technology is selected

    if (!formDataval.deliveryTime) {
      Alert.alert('Please enter deliveryTime');
      return;
    }

    if (!formDataval.deliveryTime) {
      Alert.alert('Please select at least one technology');
      return;
    }

    // Check if the price is a valid number

    // Check if the tags array is not empty
    if (tags.length === 0) {
      Alert.alert('Please add at least one tag');
      return;
    }
    return true;
  };

  const handelCreateGigApi = async () => {
    // if (!formDataval?.title) {
    //   Alert.alert('Please enter a title');
    //   return
    // }
    console.log('selcted category::::', selectedCategory);

    if (!handleValidation()) {
      // Alert.alert('Please enter a title');
      return;
    }

    try {
      const formData = new FormData();
      formData.append('professional_id', getUserId);
      formData.append('gig_title', formDataval?.title);
      formData.append('gig_main_category', selectedCategory?.id);
      formData.append('gig_sub_category', selectedSubCategory?.id);
      selectedItems.map(item => {
        formData.append('gig_technologies[]', item?.skill_id);
      });
      formData.append('gig_price', formDataval.gigPrice);
      formData.append('gig_desc', formDataval.description);
      formData.append('delivery_time', formDataval.deliveryTime);
      formData.append('gig_type', 1);
      tags.map(item => formData.append('gig_tags[]', item));
      formData.append('gig_declaration', 'on');
      formData.append('response_time', selectedResponseTime.replace(/\D/g, ''));
      formData.append('file', {
        uri: selectedImage?.uri,
        type: selectedImage?.type,
        name: selectedImage?.fileName,
      });
      // console.log('Form Data Value::::', formData);
      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/gig_create',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'multipart/form-data',
          },
          body: formData,
        },
      );
      const responseData = await response?.json();
      console.log('Response Data::::', response, responseData);
      if (responseData?.status === 200) {
        Alert.alert(responseData?.msg, '', [
          {
            text: 'ok',
            onPress: () => navigation.navigate('ProfessionalBottomTab'),
          },
        ]);
      }
    } catch (error) {
      console.error('Error creating gig:', error);
    }
    // Check if the response is okay
  };

  useEffect(() => {
    console.log('openDropdown', openDropdown);
  }, [openDropdown]);

  return (
    <View style={styles.container}>
      <NewHeader navigation={navigation} header={'Create Gig'} />
      <Pressable
        disabled={openDropdown != null ? false : true}
        style={{
          flex: 1,
        }}
        onPress={() => {
          setOpenDropdown(null);
        }}>
        <ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          scrollEnabled={openDropdown != null ? false : true}>
          <Text style={styles.titleText}>
            Create your <Text style={styles.highlightText}>Gig</Text>
          </Text>

          {/* Less Then 80 char */}
          <TextInputComponent
            placeholder={'Create a Title'}
            value={formDataval.title}
            onChangeText={value => handleInputChange('title', value)}
          />

          <DropDownContainer
            label={'Category'}
            selectedValue={selectedCategory?.service_name}
            isOpen={openDropdown === 'category'}
            setOpen={isOpen => setOpenDropdown(isOpen ? 'category' : null)}
            options={categories}
            setItem={setCategoryItem}
            onSelect={setSelectedCategory}
          />

          <DropDownContainer
            label={'SubCategory'}
            selectedValue={selectedSubCategory?.service_name}
            isOpen={openDropdown === 'subcategory'}
            setOpen={isOpen => setOpenDropdown(isOpen ? 'subcategory' : null)}
            options={filteredServices}
            onSelect={setSelectedSubCategory}
          />

          <TextInputComponent
            height
            placeholder={'Add Description'}
            value={formDataval.description}
            onChangeText={value => handleInputChange('description', value)}
          />

          <View
            style={{
              height: hp(15),
              borderRadius: hp(1),
              borderColor: 'rgba(217, 217, 217, 1)',
              borderWidth: 1,
              justifyContent: 'center',
              paddingLeft: wp(3),
              marginTop: hp(2),
              // alignItems:"center"
            }}>
            <TouchableOpacity onPress={() => openGallery()} style={{}}>
              <Image
                source={selectedImage || Images.ImageSelectContener}
                style={{
                  height: hp(10),
                  width: wp(20),
                  resizeMode: 'center',
                }}
              />
            </TouchableOpacity>
          </View>

          <DropDownContainer
            label={'Response Time'}
            selectedValue={selectedResponseTime}
            isOpen={openDropdown === 'ResponseTime'}
            setOpen={isOpen => setOpenDropdown(isOpen ? 'ResponseTime' : null)}
            options={responseTimes}
            onSelect={setSelectedResponseTime}
          />
          {/* Price Limit 5800 */}
          <TextInputComponent
            placeholder={'Enter your Gig Price'}
            value={formDataval.gigPrice}
            keyboardType={'number-pad'}
            onChangeText={value => handleInputChange('gigPrice', value)}
          />

          <TextInputComponent
            placeholder={'Delivery time in days'}
            value={formDataval.deliveryTime}
            keyboardType={'number-pad'}
            onChangeText={value => handleInputChange('deliveryTime', value)}
          />

          {/* techNology  */}

          <View style={{}}>
            {selectedItems.length > 0 && (
              <View style={styles.selectedItemsContainer}>
                {selectedItems.map(item => (
                  <View key={item?.skill_id} style={styles.selectedItem}>
                    <Text style={{color: '#999999'}}>{item?.skill_name}</Text>
                    <TouchableOpacity
                      style={{
                        // width:wp(10),
                        // justifyContent:"center",
                        // alignItems:"center",
                        flexDirection: 'row',
                        alignSelf: 'flex-end',
                      }}
                      onPress={() => {
                        removeItem(item);
                      }}>
                      <Text
                        style={{
                          paddingLeft: wp(2),
                          color: 'red',
                        }}>
                        X
                      </Text>
                    </TouchableOpacity>
                    {/* <Button title="Remove" onPress={() => removeItem(item)} /> */}
                  </View>
                ))}
              </View>
            )}
            <TouchableOpacity
              onPress={toggleModal}
              style={{
                backgroundColor: 'white',
                flexDirection: 'row',
                justifyContent: 'space-between',
                padding: 10,
                paddingVertical: hp(2.3),
                borderWidth: 1,
                borderColor: 'rgba(217, 217, 217, 1)',
                marginVertical: hp(2),
                borderRadius: hp(1),
              }}>
              <Text style={styles.buttonText}>Select Technology</Text>
              <Image
                source={Images.downArrowLight}
                style={{
                  height: hp(3),
                  width: wp(3),
                  resizeMode: 'contain',
                }}
              />
            </TouchableOpacity>
            <Modal
              animationType="slide"
              transparent={true}
              visible={modalVisible}
              onRequestClose={toggleModal}>
              <View style={styles.modalOverlay}>
                <View style={styles.modalContainer}>
                  <FlatList
                    data={allTechnology}
                    renderItem={({item}) => (
                      <TouchableOpacity
                        onPress={() => selectItem(item)}
                        style={styles.item}>
                        <Text style={{color: '#999999'}}>
                          {item?.skill_name}
                        </Text>
                      </TouchableOpacity>
                    )}
                    keyExtractor={item => item}
                  />
                  <Button title="Close" onPress={toggleModal} />
                </View>
              </View>
            </Modal>
          </View>

          {/* End Technology Section */}

          {tags.length > 0 && (
            <View
              style={{
                borderRadius: hp(1),
                borderWidth: 1,
                borderColor: 'rgba(217, 217, 217, 1)',
                flexDirection: 'row',
                flexWrap: 'wrap',
                paddingVertical: hp(1),
              }}>
              {tags.map((item, index) => {
                return (
                  <View key={index} style={styles.selectedItem}>
                    <Text
                      style={{
                        fontSize: FSize.fs16,
                        fontWeight: '400',
                        // marginTop:hp(1),
                        color: '#999999',
                      }}>
                      {item}
                    </Text>
                    <TouchableOpacity
                      onPress={() => removeTag(index)}
                      style={{marginLeft: wp(2)}}>
                      <Text
                        style={{
                          color: 'red',
                        }}>
                        X
                      </Text>
                      {/* <size={20} color="rgba(17, 17, 17, 1)" /> */}
                    </TouchableOpacity>
                  </View>
                );
              })}
            </View>
          )}

          <View
            style={{
              borderWidth: 1,
              borderRadius: hp(1),
              borderColor: 'rgba(217, 217, 217, 1)',
              height: hp(8),
              paddingHorizontal: wp(1),
              marginVertical: tags.length > 0 ? hp(2) : 0,
            }}>
            <TextInput
              multiline
              placeholderTextColor="#999999"
              placeholder={'Tag'}
              value={inputValue}
              onChangeText={setInputValue}
              onSubmitEditing={() => handleAddTag()} // Triggers when the check button is pressed
              returnKeyType="done"
              keyboardType="default"
              blurOnSubmit={true}
              style={styles.textInput}
            />
          </View>

          {/* <TextInputComponent
            placeholder={'Tags'}
            value={formData.tags}
            onChangeText={value => handleInputChange('tags', value)}
          /> */}

          <View style={styles.checkboxContainer}>
            <TouchableOpacity onPress={() => setIsChecked(!isChecked)}>
              <Image
                source={
                  isChecked ? Images.checkedCheckBox : Images.blankChackbox
                }
                style={styles.checkbox}
              />
            </TouchableOpacity>
            <Text style={{color: '#999999', marginLeft: wp(2)}}>
              I confirm that the information provided is accurate...
            </Text>
          </View>

          <TouchableOpacity
            onPress={() => {
              if (isChecked) {
                handelCreateGigApi();
              } else {
                Alert.alert('Please confirm the checkbox to proceed');
              }
            }}
            style={[
              styles.submitButton,
              {
                backgroundColor: isChecked
                  ? 'rgba(0, 104, 255, 1)'
                  : 'rgba(217, 217, 217, 1)',
              },
            ]}>
            <Text style={styles.submitText}>Submit</Text>
          </TouchableOpacity>
        </ScrollView>
      </Pressable>
    </View>
  );
};

export default CreateGig;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  scrollView: {
    marginHorizontal: wp(4),
    marginVertical: hp(1),
  },
  titleText: {
    color: 'black',
    fontSize: FSize.fs22,
    fontWeight: '500',
  },
  highlightText: {
    color: 'rgba(0, 104, 255, 1)s',
  },
  placeholder: {
    color: '#444444',
  },
  dropdownButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(217, 217, 217, 1)',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: hp(2.5),
    backgroundColor: 'white',
  },
  dropdown: {
    marginTop: 5,
    backgroundColor: 'white',
    borderRadius: 8,
    maxHeight: hp(40),
    borderWidth: 1,
    borderColor: 'rgba(217, 217, 217, 1)',
    position: 'absolute',
    width: '100%',
    zIndex: 1000,
  },
  option: {
    paddingVertical: 12,
    paddingHorizontal: 12,
  },
  inputContainer: height => ({
    borderWidth: 1,
    borderRadius: hp(1),
    borderColor: 'rgba(217, 217, 217, 1)',
    height: height ? hp(20) : hp(8),
    justifyContent: height ? 'flex-start' : 'center',
    // justifyContent:"",
    // alignItems:"center",
    paddingHorizontal: wp(1),
    marginTop: hp(2),
  }),
  textInput: {
    // fontSize: FSize.fs16,
    color: '#444444',
  },
  checkboxContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: wp(2),
    marginTop: hp(2),
  },
  checkbox: {
    width: hp(3),
    height: hp(3),
    tintColor: 'rgba(0, 104, 255, 1)',
    resizeMode: 'contain',
  },
  checkboxText: {
    marginLeft: wp(2),
    color: Colors.gray,
  },
  submitButton: {
    paddingHorizontal: wp(10),
    paddingVertical: hp(1.8),
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: hp(2),
  },
  submitText: {
    fontSize: FSize.fs18,
    fontWeight: '600',
    color: 'white',
  },
  dropdownButtonTech: {
    backgroundColor: 'white',
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
    paddingVertical: hp(2),
    borderWidth: 1,
    borderColor: 'rgba(217, 217, 217, 1)',
    marginVertical: hp(2),
    borderRadius: hp(1),
  },
  buttonText: {
    color: '#444444',
    // textAlign: 'center',
  },
  selectedItemsContainer: {
    marginTop: 20,
    flexDirection: 'row',
    flexWrap: 'wrap',
    borderWidth: 1,
    borderColor: 'rgba(217, 217, 217, 1)',
    borderRadius: hp(1),
  },
  selectedItem: {
    marginHorizontal: wp(2),
    marginVertical: hp(1),
    paddingVertical: hp(1),
    paddingHorizontal: wp(2),
    backgroundColor: '#f0f0f0',
    borderRadius: 5,
    flexDirection: 'row',
    alignItems: 'center',
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContainer: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    maxHeight: hp(40),
    width: 300,
  },
  item: {
    padding: 10,
    backgroundColor: '#ecf0f1',
    marginBottom: 5,
    borderRadius: 5,
  },
});
