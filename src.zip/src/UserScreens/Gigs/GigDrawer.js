import {Dimensions, ScrollView, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {createDrawerNavigator} from '@react-navigation/drawer';
import BrowseGigs from './BrowseGigs';
import ProjectFilterComponent from '../../ProfessionalScreens/Home/ProjectFilterComponent';
const {width} = Dimensions.get('window');
const GigDrawer = () => {
  const RightDrawer = createDrawerNavigator();
  const ScrollableDrawerContent = ({children}) => {
    return (
      <ScrollView
        contentContainerStyle={{flexGrow: 1}}
        showsVerticalScrollIndicator={false}>
        {children}
      </ScrollView>
    );
  };

  return (
    <RightDrawer.Navigator
      id="RightDrawer"
      screenOptions={{
        drawerPosition: 'right',
        headerShown: false,
        gestureEnabled: false,
        drawerStyle: {width: width * 0.7, overflow: 'hidden'},
      }}
      drawerContent={props => (
        <ScrollableDrawerContent>
          <ProjectFilterComponent {...props} showRatings/>
        </ScrollableDrawerContent>
      )}>
      <RightDrawer.Screen name="MainScreen" component={BrowseGigs} />
    </RightDrawer.Navigator>
  );
};

export default GigDrawer;

const styles = StyleSheet.create({});
