import {
  ActivityIndicator,
  FlatList,
  RefreshControl,
  StyleSheet,
  View,
} from 'react-native';
import React, {useEffect, useRef, useState} from 'react';
import Colors from '../../assets/commonCSS/Colors';
import GigHeader from './GigHeader';
import {useGigApis} from './GigApis';
import GigCards from './GigCards';
import {hp} from '../../assets/commonCSS/GlobalCSS';
import CustomButton from '../../components/CustomButton';
import {useSelector} from 'react-redux';
import {useIsFocused} from '@react-navigation/native';

const BrowseGigs = ({navigation}) => {
  const [input, setInput] = useState('');
  const {getBrowseGigs} = useGigApis();
  const [gigData, setGigData] = useState([]);
  const [originalData, setOriginalData] = useState([]);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(true);
  const getIfProfessional = useSelector(state => state?.getIfProfessional);
  const [buttonLoading, setButtonLoading] = useState(false);
  const getUserDetails = useSelector(state => state?.getUserDetails);
  const flagRef = useRef(-1);
  const isFocused = useIsFocused();
  useEffect(() => {
    if (isFocused) {
      getData();
    }
  }, [offset, isFocused]);

  const getData = async () => {
    setButtonLoading(true);

    try {
      //logic to handle gigs based on flags
      const selectedFlags = Array.from(
        new Set(getUserDetails?.services?.map(item => item.flag)),
      ).sort((a, b) => a - b);
      if (selectedFlags[selectedFlags.length - 1] <= 6) {
        flagRef.current = 1;
      } else if (selectedFlags[selectedFlags.length - 1] > 6) {
        flagRef.current = 0;
      }
      const payload = new FormData();
      payload.append('offset', offset);
      payload.append('limit', 10);
      payload.append('cur', getUserDetails?.country == 'IN' ? 'INR' : 'USD');
      flagRef.current != -1 && payload.append('is_it', flagRef.current);
      const res = await getBrowseGigs(payload);
      if (res == 'No gigs found') {
        setHasMore(false);
        return;
      }
      if (res?.length < 10) {
        setHasMore(false);
      }
      setOriginalData(prev => {
        const combinedData = [...res, ...prev];
        const uniqueData = Array.from(
          new Map(
            combinedData.map(item => [item.gig_unique_id, item]),
          ).values(),
        );
        return uniqueData;
      });
      setGigData(prev => {
        const combinedData = [...res, ...prev];
        const uniqueData = Array.from(
          new Map(
            combinedData.map(item => [item.gig_unique_id, item]),
          ).values(),
        );
        return uniqueData;
      });
    } catch (error) {
      console.error('Error fetching gigs:', error);
    } finally {
      setLoading(false);
      setButtonLoading(false);
    }
  };

  if (loading)
    return (
      <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
        <ActivityIndicator color={Colors.sooprsblue} size={35} />
      </View>
    );
  return (
    <View style={styles.container}>
      {/* Header */}

      <GigHeader
        input={input}
        setInput={setInput}
        setGigData={setGigData}
        gigData={gigData}
        originalData={originalData}
        isProfessional={getIfProfessional && flagRef.current == 0}
        navigation={navigation}
      />
      <View>
        <FlatList
          refreshControl={
            <RefreshControl
              refreshing={loading}
              onRefresh={() => {
                getData();
              }}
              colors={[Colors.sooprsblue, Colors.sooprsDark]}
            />
          }
          data={gigData}
          showsVerticalScrollIndicator={false}
          renderItem={({item, index}) => (
            <GigCards
              navigation={navigation}
              item={item}
              index={index}
              currency={getUserDetails?.country == 'IN' ? 'INR' : 'USD'}
            />
          )}
          // numColumns={1}
          contentContainerStyle={{padding: 16, paddingBottom: hp(20)}}
          // columnWrapperStyle={{justifyContent: 'space-between'}}
          ListFooterComponent={
            hasMore ? (
              <CustomButton
                buttonText="Load more gigs"
                onButtonPress={() => setOffset(prev => prev + 10)}
                loading={buttonLoading}
              />
            ) : null
          }
        />
      </View>
    </View>
  );
};

export default BrowseGigs;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
});
