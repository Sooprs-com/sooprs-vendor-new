import React, {useEffect, useMemo, useRef, useState} from 'react';
import {
  Animated,
  Easing,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Linking,
  Modal,
  Platform,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import DocumentPicker from 'react-native-document-picker';
import {useNavigation} from '@react-navigation/native';
import Colors from '../../assets/commonCSS/Colors';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import FSize from '../../assets/commonCSS/FSize';
import Images from '../../assets/image';
import { getDataWithToken } from '../../services/mobile-api';
import { mobile_siteConfig } from '../../services/mobile-siteConfig';
import { getDataFromAsyncStorage } from '../../services/CommonFunction';
import axios from 'axios';

type Sender = 'bot' | 'user';
type MessageVariant = 'default' | 'system' | 'attachment';

type AttachmentData = {
  uri: string;
  name?: string | null;
  type?: string | null;
};

type ChatMessage = {
  id: string;
  text: string;
  sender: Sender;
  variant?: MessageVariant;
  attachment?: AttachmentData;
};

type ConversationOption = {
  id: string;
  label: string;
  nextStepId?: string | null;
  completesFlow?: boolean;
  data?: any; // Store original data for reference
};

type ConversationStep = {
  id: string;
  prompt: string;
  options: ConversationOption[];
  questionId?: string;
  categoryId?: string;
  subcategoryId?: string;
};

// API Response Types
type QuestionOption = {
  id: string;
  answer_text: string;
};

type Question = {
  id: string;
  category_id: string;
  question_text: string;
  answer_type: string; // "1" for options, "2" for text input
  required: string;
  sequence: string;
  status: string;
  options: QuestionOption[];
};

type Subcategory = {
  id: string;
  name: string;
  questions: Question[];
};

type Category = {
  id: string;
  name: string;
  parent_id: string | null;
  subcategories: Subcategory[];
};

type ApiResponse = {
  success: boolean;
  data: Category[];
  total_categories: number;
  message: string;
};

const FINAL_MESSAGE =
  'Thanks — we have recorded your choice. Our agent will contact you if needed.';
const END_OF_FLOW_MESSAGE = 'Your Request is captured successfully.';
const FOOTER_HINT = 'Choose an option — no typing required';
const MANUAL_REPLY_RESPONSE =
  'Thanks for sharing. Our agent will review and get back to you soon!';
const ATTACHMENT_ACKNOWLEDGEMENT =
  'Attachment received. We will review it and respond shortly.';

const PROCESSING_WAVE_COLOR = 'rgba(0,119,255,0.18)'; 
const PROCESSING_WAVE_DELAYS = [0, 260];

const generateId = (prefix: string) =>
  `${prefix}-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

// Transform API data into conversation steps
const transformApiDataToSteps = (categories: Category[]): ConversationStep[] => {
  const steps: ConversationStep[] = [];

  // Step 1: Category selection
  const categoryStep: ConversationStep = {
    id: 'category-selection',
    prompt: 'What service do you need?',
    options: categories.map(category => ({
      id: `category-${category.id}`,
      label: category.name,
      nextStepId: category.subcategories && category.subcategories.length > 0 
        ? `subcategory-${category.id}` 
        : null,
      completesFlow: !category.subcategories || category.subcategories.length === 0,
      data: category,
    })),
  };
  steps.push(categoryStep);

  // Step 2: Subcategory selection for each category
  categories.forEach(category => {
    if (category.subcategories && category.subcategories.length > 0) {
      const subcategoryStep: ConversationStep = {
        id: `subcategory-${category.id}`,
        prompt: 'Which service type do you need?',
        options: category.subcategories.map(subcategory => ({
          id: `subcategory-${category.id}-${subcategory.id}`,
          label: subcategory.name,
          nextStepId: subcategory.questions && subcategory.questions.length > 0
            ? `question-${subcategory.id}-0`
            : null,
          completesFlow: !subcategory.questions || subcategory.questions.length === 0,
          data: { category, subcategory },
        })),
        categoryId: category.id,
      };
      steps.push(subcategoryStep);

      // Steps for questions
      category.subcategories.forEach(subcategory => {
        if (subcategory.questions && subcategory.questions.length > 0) {
          // Sort questions by sequence
          const sortedQuestions = [...subcategory.questions].sort(
            (a, b) => parseInt(a.sequence) - parseInt(b.sequence)
          );

          sortedQuestions.forEach((question, index) => {
            const isLastQuestion = index === sortedQuestions.length - 1;
            const nextQuestionId = !isLastQuestion 
              ? `question-${subcategory.id}-${index + 1}`
              : null;

            if (question.answer_type === '1' && question.options && question.options.length > 0) {
              // Question with options
              const questionStep: ConversationStep = {
                id: `question-${subcategory.id}-${index}`,
                prompt: question.question_text,
                options: question.options.map(option => ({
                  id: `option-${question.id}-${option.id}`,
                  label: option.answer_text,
                  nextStepId: nextQuestionId,
                  completesFlow: isLastQuestion,
                  data: { question, option },
                })),
                questionId: question.id,
                categoryId: category.id,
                subcategoryId: subcategory.id,
              };
              steps.push(questionStep);
            } else if (question.answer_type === '2') {
              // Text input question - complete flow after this
              const questionStep: ConversationStep = {
                id: `question-${subcategory.id}-${index}`,
                prompt: question.question_text,
                options: [],
                questionId: question.id,
                categoryId: category.id,
                subcategoryId: subcategory.id,
              };
              steps.push(questionStep);
            }
          });
        }
      });
    }
  });

  return steps;
};

const PostChatSceen = () => {
  const navigation = useNavigation();
  const [conversationSteps, setConversationSteps] = useState<ConversationStep[]>([]);
  const [apiData, setApiData] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [selectedSubcategory, setSelectedSubcategory] = useState<Subcategory | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [userAnswers, setUserAnswers] = useState<Record<string, any>>({});
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [activeStepId, setActiveStepId] = useState<string | null>(null);
  const [isFlowCompleted, setIsFlowCompleted] = useState(false);
  const [manualInput, setManualInput] = useState('');
  const [hoveredOptionId, setHoveredOptionId] = useState<string | null>(null);
  const [showProcessingModal, setShowProcessingModal] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const flatListRef = useRef<FlatList<ChatMessage>>(null);
  const processingTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const typingTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const typingDotAnimations = useRef([
    new Animated.Value(0),
    new Animated.Value(0),
    new Animated.Value(0),
  ]).current;
  const wavePulseValues = useRef(
    PROCESSING_WAVE_DELAYS.map(() => new Animated.Value(0)),
  ).current;
  const waveAnimationRefs = useRef<Animated.CompositeAnimation[]>([]);
  const waveStartTimeoutsRef =
    useRef<Array<ReturnType<typeof setTimeout>>>([]);

  useEffect(() => {
    return () => {
      if (processingTimerRef.current) {
        clearTimeout(processingTimerRef.current);
      }
      if (typingTimerRef.current) {
        clearTimeout(typingTimerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (flatListRef.current) {
      flatListRef.current.scrollToEnd({animated: true});
    }
  }, [messages, isTyping]);

  // Typing indicator animation
  useEffect(() => {
    if (!isTyping) {
      typingDotAnimations.forEach(anim => anim.setValue(0));
      return;
    }

    const animations = typingDotAnimations.map((anim, index) => {
      return Animated.loop(
        Animated.sequence([
          Animated.delay(index * 150),
          Animated.timing(anim, {
            toValue: 1,
            duration: 500,
            easing: Easing.inOut(Easing.ease),
            useNativeDriver: true,
          }),
          Animated.timing(anim, {
            toValue: 0,
            duration: 500,
            easing: Easing.inOut(Easing.ease),
            useNativeDriver: true,
          }),
          Animated.delay((3 - index) * 150),
        ]),
      );
    });

    animations.forEach(anim => anim.start());

    return () => {
      animations.forEach(anim => anim.stop());
    };
  }, [isTyping, typingDotAnimations]);

  useEffect(() => {
    if (!showProcessingModal) {
      waveAnimationRefs.current.forEach(anim => anim.stop());
      waveAnimationRefs.current = [];
      waveStartTimeoutsRef.current.forEach(timeout => clearTimeout(timeout));
      waveStartTimeoutsRef.current = [];
      return;
    }

    wavePulseValues.forEach(value => value.setValue(0));

    const loops = wavePulseValues.map((value, index) => {
      const animation = Animated.loop(
        Animated.timing(value, {
          toValue: 1,
          duration: 2600,
          easing: Easing.linear,
          useNativeDriver: true,
        }),
        {resetBeforeIteration: true},
      );
      const timeout = setTimeout(() => {
        animation.start();
      }, PROCESSING_WAVE_DELAYS[index]);
      waveStartTimeoutsRef.current.push(timeout);
      return animation;
    });

    waveAnimationRefs.current = loops;

    return () => {
      waveAnimationRefs.current.forEach(anim => anim.stop());
      waveAnimationRefs.current = [];
      waveStartTimeoutsRef.current.forEach(timeout => clearTimeout(timeout));
      waveStartTimeoutsRef.current = [];
    };
  }, [showProcessingModal, wavePulseValues]);

  const getAllServices = async () => {
  try {
    const res = await getDataWithToken(mobile_siteConfig.GET_POSTED_PROJECTS_ALL_CRETGORY);
    if (res.success && res.data) {
      console.log("Response of all Services", JSON.stringify(res, null, 2));
      setApiData(res.data);
      const steps = transformApiDataToSteps(res.data);
      setConversationSteps(steps);
      
      // Initialize with first step
      if (steps.length > 0) {
        const firstStep = steps[0];
        setActiveStepId(firstStep.id);
        setMessages([
          {
            id: `${firstStep.id}-prompt`,
            text: firstStep.prompt,
            sender: 'bot',
          },
        ]);
      }
    } else {
      console.log("Error in getting all Services", res.message);
    }
  } catch (err) {
    console.log("Error in getting all Services", err);
  }
};

useEffect(() => {
  getAllServices();
}, []);

  // Submit query API function
  const submitQueryAPi = async (answersToSubmit?: Record<string, any>) => {
    // Use provided answers or fallback to state
    const answersToUse = answersToSubmit || userAnswers;
    
    // Find subcategory from selectedSubcategory or from apiData using answersToUse
    let subcategoryToUse = selectedSubcategory;
    
    // If subcategory not set, try to find it from apiData using the first answer's question
    if (!subcategoryToUse && Object.keys(answersToUse).length > 0 && apiData.length > 0) {
      const firstQuestionId = Object.keys(answersToUse)[0];
      for (const category of apiData) {
        if (category.subcategories) {
          for (const subcat of category.subcategories) {
            const question = subcat.questions.find(q => String(q.id) === String(firstQuestionId));
            if (question) {
              subcategoryToUse = subcat;
              break;
            }
          }
          if (subcategoryToUse) break;
        }
      }
    }

    if (!subcategoryToUse) {
      console.log("Error: No subcategory found");
      return;
    }

    try {
      // Format answers array from answersToUse
      const answersArray: any[] = [];
      
      // Get all questions from selected subcategory sorted by sequence
      const sortedQuestions = [...subcategoryToUse.questions].sort(
        (a, b) => parseInt(a.sequence) - parseInt(b.sequence)
      );

      // Process each question in sequence order
      sortedQuestions.forEach(question => {
        // Try both string and number keys to handle ID type mismatch
        const questionIdStr = String(question.id);
        const questionIdNum = Number(question.id);
        const userAnswer = answersToUse[questionIdStr] || answersToUse[questionIdNum] || answersToUse[question.id];
        
        console.log(`Processing question ${question.id} (str: ${questionIdStr}, num: ${questionIdNum}), answer_type: ${question.answer_type}`);
        console.log(`answersToUse keys:`, Object.keys(answersToUse));
        console.log(`userAnswer for question ${question.id}:`, userAnswer);
        
        if (userAnswer) {
          if (question.answer_type === '1' && userAnswer.answerId) {
            console.log("Option-based answer:", {
              question_id: question.id,
              answer_option_id: userAnswer.answerId,
            });
            // Option-based answer (answer_type: "1")
            // Format: { question_id: "8", answer_option_id: "30" }
            answersArray.push({
              question_id: String(question.id),
              answer_option_id: String(userAnswer.answerId),
            });
          } else if (question.answer_type === '2' && userAnswer.answerText) {
            console.log("Text input answer:", {
              question_id: question.id,
              typed_answer: userAnswer.answerText,
            });
            // Text input answer (answer_type: "2")
            // Format: { question_id: "11", typed_answer: "6393141893" }
            answersArray.push({
              question_id: String(question.id),
              typed_answer: String(userAnswer.answerText).trim(),
            });
          } else if (question.answer_type === '2' && !userAnswer.answerText) {
            console.log("Warning: Text input question but no answerText found for question:", question.id, "userAnswer:", userAnswer);
          }
        } else {
          console.log("No user answer found for question:", question.id);
          console.log("Available answers:", answersToUse);
        }
      });

      // Create FormData
      const formData = new FormData();
      formData.append('subcategory_id', subcategoryToUse.id);
      
      // Append answers array as JSON string
      // Format: answers = [{question_id: 8, answer_option_id: 30}, {question_id: 11, typed_answer: "6393141893"}, ...]
      const answersJsonString = JSON.stringify(answersArray);
      formData.append('answers', answersJsonString);

      console.log("Submitting query with data:", {
        subcategory_id: subcategoryToUse.id,
        answers: answersArray,
      });
      console.log("Answers array details:", JSON.stringify(answersArray, null, 2));
      console.log("Answers JSON string:", answersJsonString);
      console.log("FormData - subcategory_id:", subcategoryToUse.id);
      console.log("FormData - answers:", answersJsonString);

      // Get token from AsyncStorage
      const token = await getDataFromAsyncStorage(mobile_siteConfig.TOKEN);
      
      // Build full URL
      const url = mobile_siteConfig.BASE_URL + mobile_siteConfig.INDEX + mobile_siteConfig.SUBMIT_QUERY;
      
      console.log("API URL:", url);
      console.log("Token:", token);

      // Make API call using axios
      // Note: axios automatically sets Content-Type for FormData with boundary
      // Don't set Content-Type manually as axios will set it with proper boundary
      const response = await axios.post(url, formData, {
        headers: {
          'Origin': 'localhost',
          'Authorization': `Bearer ${token}`,
        },
      });

      const res = response.data;
      
      if (res?.success) {
        console.log("Query submitted successfully:", res);
      } else {
        console.log("Error in submitting query:", res?.message || "Unknown error");
      }
    } catch (err: any) {
      console.log("Error in submitting query", err);
      if (err.response) {
        // The request was made and the server responded with a status code
        // that falls out of the range of 2xx
        console.log("Error response data:", err.response.data);
        console.log("Error response status:", err.response.status);
      } else if (err.request) {
        // The request was made but no response was received
        console.log("Error request:", err.request);
      } else {
        // Something happened in setting up the request that triggered an Error
        console.log("Error message:", err.message);
      }
    }
  };



  const activeStep = useMemo(
    () => conversationSteps.find(step => step.id === activeStepId) ?? null,
    [activeStepId, conversationSteps],
  );

  // Get current question from active step
  const currentQuestion = useMemo(() => {
    if (!activeStep?.questionId) {
      return null;
    }
    
    // First try to get from selectedSubcategory
    if (selectedSubcategory) {
      const question = selectedSubcategory.questions.find(
        q => q.id === activeStep.questionId
      );
      if (question) {
        return question;
      }
    }
    
    // If not found, search in apiData
    if (activeStep.subcategoryId && apiData.length > 0) {
      for (const category of apiData) {
        if (category.subcategories) {
          const subcategory = category.subcategories.find(
            sc => sc.id === activeStep.subcategoryId
          );
          if (subcategory) {
            const question = subcategory.questions.find(
              q => q.id === activeStep.questionId
            );
            if (question) {
              return question;
            }
          }
        }
      }
    }
    
    return null;
  }, [activeStep, selectedSubcategory, apiData]);

  // Check if current step is a text input question
  const isTextInputQuestion = useMemo(() => {
    return currentQuestion?.answer_type === '2';
  }, [currentQuestion]);

  const appendMessage = (message: ChatMessage) => {
    setMessages(prev => [...prev, message]);
  };

  const appendMessages = (newMessages: ChatMessage[]) => {
    setMessages(prev => [...prev, ...newMessages]);
  };

  const isImageAttachment = (attachment?: AttachmentData) => {
    if (!attachment) {
      return false;
    }
    if (attachment.type?.startsWith('image/')) {
      return true;
    }
    const reference = (
      attachment.name ?? attachment.uri ?? ''
    ).toLowerCase();
    return /\.(png|jpe?g|gif|bmp|webp|heic|heif)$/.test(reference);
  };

  const handleFlowCompletion = (answersToSubmit?: Record<string, any>) => {
    if (isFlowCompleted) {
      return;
    }
    appendMessages([
      {
        id: 'final-response',
        text: FINAL_MESSAGE,
        sender: 'bot',
      },
      {
        id: 'end-of-flow',
        text: END_OF_FLOW_MESSAGE,
        sender: 'bot',
        variant: 'system',
      },
    ]);
    setIsFlowCompleted(true);
    setActiveStepId(null);
    
    // Submit query API when flow completes - pass answers if provided
    submitQueryAPi(answersToSubmit);
    
    if (processingTimerRef.current) {
      clearTimeout(processingTimerRef.current);
    }
    processingTimerRef.current = setTimeout(() => {
      setShowProcessingModal(true);
    }, 1800);
  };

  const handleCloseProcessingModal = () => {
    if (processingTimerRef.current) {
      clearTimeout(processingTimerRef.current);
      processingTimerRef.current = null;
    }
    setShowProcessingModal(false);
  };

  // Helper function to show next question with typing delay
  const showNextQuestionWithDelay = (nextStep: ConversationStep, delay: number = 2500) => {
    // Clear any existing typing timer
    if (typingTimerRef.current) {
      clearTimeout(typingTimerRef.current);
    }

    // Show typing indicator
    setIsTyping(true);

    // After delay, show the next question
    typingTimerRef.current = setTimeout(() => {
      setIsTyping(false);
      
      // Check if it's a text input question
      if (nextStep.questionId && nextStep.options.length === 0) {
        // Text input question - show input field
        appendMessage({
          id: `${nextStep.id}-prompt`,
          text: nextStep.prompt,
          sender: 'bot',
        });
        setActiveStepId(nextStep.id);
        // Update selected subcategory to get question data
        if (nextStep.subcategoryId && apiData.length > 0) {
          apiData.forEach(cat => {
            if (cat.subcategories) {
              const subcat = cat.subcategories.find(
                sc => sc.id === nextStep.subcategoryId
              );
              if (subcat) {
                setSelectedSubcategory(subcat);
                setSelectedCategory(cat);
              }
            }
          });
        }
      } else {
        // Question with options
        appendMessage({
          id: `${nextStep.id}-prompt`,
          text: nextStep.prompt,
          sender: 'bot',
        });
        setActiveStepId(nextStep.id);
      }
    }, delay);
  };

  const handleOptionPress = (option: ConversationOption) => {
    appendMessage({
      id: `${option.id}-user`,
      text: option.label,
      sender: 'user',
    });

    // Store user answer if it's a question option - use string key for consistency
    if (option.data?.question && option.data?.option) {
      const questionId = String(option.data.question.id);
      setUserAnswers(prev => ({
        ...prev,
        [questionId]: {
          questionId: questionId,
          answerId: String(option.data.option.id),
          answerText: option.data.option.answer_text,
        },
      }));
    }

    // Handle category selection
    if (option.data && 'id' in option.data && option.data.parent_id === null) {
      setSelectedCategory(option.data as Category);
    }

    // Handle subcategory selection
    if (option.data?.category && option.data?.subcategory) {
      setSelectedCategory(option.data.category);
      setSelectedSubcategory(option.data.subcategory);
      setCurrentQuestionIndex(0);
    }

    if (option.nextStepId) {
      const nextStep = conversationSteps.find(
        step => step.id === option.nextStepId,
      );
      if (nextStep) {
        // Show next question with typing delay
        showNextQuestionWithDelay(nextStep);
        return;
      }
    }

    handleFlowCompletion();
  };

  const handleManualSend = () => {
    const trimmed = manualInput.trim();
    if (!trimmed) {
      return;
    }

    // If it's a text input question, store the answer
    if (activeStep?.questionId && currentQuestion) {
      console.log("Storing text input answer:", {
        questionId: currentQuestion.id,
        answerText: trimmed,
        answer_type: currentQuestion.answer_type,
      });
      
      // Store user answer - use string key to ensure consistency
      const questionIdKey = String(currentQuestion.id);
      let updatedAnswers: Record<string, any> = {};
      
      setUserAnswers(prev => {
        updatedAnswers = {
          ...prev,
          [questionIdKey]: {
            questionId: questionIdKey,
            answerText: trimmed,
          },
        };
        console.log("Updated userAnswers:", updatedAnswers);
        console.log("Stored with key:", questionIdKey, "value:", updatedAnswers[questionIdKey]);
        return updatedAnswers;
      });

      // Add user message
      appendMessage({
        id: generateId('text-input-user'),
        text: trimmed,
        sender: 'user',
      });

      // Find next question or complete flow
      let subcategoryToUse = selectedSubcategory;
      
      // If subcategory not set, find it from apiData
      if (!subcategoryToUse && activeStep.subcategoryId && apiData.length > 0) {
        for (const category of apiData) {
          if (category.subcategories) {
            const subcat = category.subcategories.find(
              sc => sc.id === activeStep.subcategoryId
            );
            if (subcat) {
              subcategoryToUse = subcat;
              setSelectedSubcategory(subcat);
              setSelectedCategory(category);
              break;
            }
          }
        }
      }

      if (subcategoryToUse && activeStep.subcategoryId) {
        const sortedQuestions = [...subcategoryToUse.questions].sort(
          (a, b) => parseInt(a.sequence) - parseInt(b.sequence)
        );
        const currentIndex = sortedQuestions.findIndex(
          q => q.id === currentQuestion.id
        );
        const nextQuestion = sortedQuestions[currentIndex + 1];

        if (nextQuestion) {
          // Move to next question
          const nextStepId = `question-${activeStep.subcategoryId}-${currentIndex + 1}`;
          const nextStep = conversationSteps.find(step => step.id === nextStepId);
          if (nextStep) {
            // Show next question with typing delay
            showNextQuestionWithDelay(nextStep);
          } else {
            handleFlowCompletion(updatedAnswers);
          }
        } else {
          // No more questions, complete flow
          handleFlowCompletion(updatedAnswers);
        }
      } else {
        handleFlowCompletion(updatedAnswers);
      }
    } else {
      // Regular manual input (not part of question flow)
      appendMessages([
        {
          id: generateId('manual-user'),
          text: trimmed,
          sender: 'user',
        },
        {
          id: generateId('manual-response'),
          text: MANUAL_REPLY_RESPONSE,
          sender: 'bot',
        },
      ]);
    }
    
    setManualInput('');
  };

  const handleAttachmentOpen = (attachment?: AttachmentData) => {
    if (!attachment?.uri) {
      return;
    }

    Linking.canOpenURL(attachment.uri)
      .then(supported => {
        if (supported) {
          Linking.openURL(attachment.uri);
        } else {
          console.warn('Cannot open attachment URI:', attachment.uri);
        }
      })
      .catch(err => {
        console.warn('Failed to open attachment', err);
      });
  };

  const handleAttachmentPick = async () => {
    try {
      const result = await DocumentPicker.pick({
        presentationStyle: 'fullScreen',
        type: [DocumentPicker.types.allFiles],
      });

      const file = result?.[0];
      if (file) {
        appendMessages([
          {
            id: generateId('attachment-user'),
            text: file.name ?? 'Attachment',
            sender: 'user',
            variant: 'attachment',
            attachment: {
              uri: file.uri,
              name: file.name,
              type: file.type,
            },
          },
          {
            id: generateId('attachment-bot'),
            text: ATTACHMENT_ACKNOWLEDGEMENT,
            sender: 'bot',
          },
        ]);
      }
    } catch (err) {
      if (!DocumentPicker.isCancel(err)) {
        console.warn('Attachment pick error', err);
      }
    }
  };

  const renderMessage = ({item}: {item: ChatMessage}) => {
    const attachment = item.attachment;
    const isUser = item.sender === 'user';
    const isSystem = item.variant === 'system';
    const isAttachment = item.variant === 'attachment' && attachment;
    const isImage =
      isAttachment && attachment ? isImageAttachment(attachment) : false;

    if (isSystem) {
      return (
        <View style={styles.systemMessageWrapper}>
          <Text style={styles.optionText}>{item.text}</Text>
        </View>
      );
    }

    return (
      <View
        style={[
          styles.messageWrapper,
          isUser ? styles.messageWrapperUser : styles.messageWrapperBot,
        ]}>
        <View
          style={[
            styles.messageBubble,
            isUser ? styles.userBubble : styles.botBubble,
            isAttachment && styles.attachmentBubble,
          ]}>
          {isAttachment ? (
            <TouchableOpacity
              activeOpacity={0.85}
              onPress={() => handleAttachmentOpen(item.attachment)}>
              {isImage && attachment && (
                <Image
                  source={{uri: attachment.uri}}
                  style={styles.attachmentImage}
                  resizeMode="cover"
                />
              )}
              <View style={styles.attachmentDetails}>
                <Image
                  source={
                    isImage
                      ? Images.imageIcon
                      : Images.link
                  }
                  style={styles.attachmentThumb}
                  resizeMode="contain"
                />
                <Text
                  style={[
                    styles.attachmentName,
                    isUser
                      ? styles.optionText
                      : styles.attachmentNameBot,
                  ]}
                  numberOfLines={2}>
                  {attachment?.name ?? item.text}
                </Text>
              </View>
            </TouchableOpacity>
          ) : (
            <Text
              style={[
                styles.messageText,
                isUser ? styles.userMessageText : styles.botMessageText,
              ]}>
              {item.text}
            </Text>
          )}
        </View>
      </View>
    );
  };

  const waveAnimatedStyles = wavePulseValues.map(value => ({
    opacity: value.interpolate({
      inputRange: [0, 0.5, 1],
      outputRange: [0.9, 0.55, 0],
    }),
    transform: [
      {
        scale: value.interpolate({
          inputRange: [0, 1],
          outputRange: [0.72, 1.32],
        }),
      },
    ],
  }));

  return (
    <SafeAreaView style={styles.safeArea}>
      <Modal
        transparent
        animationType="fade"
        visible={showProcessingModal}
        onRequestClose={handleCloseProcessingModal}>
        <View style={styles.modalBackdrop}>
          <Pressable
            style={StyleSheet.absoluteFill}
            onPress={handleCloseProcessingModal}
          />
          <View style={styles.modalContent}>
            <View style={styles.modalVisualWrap}>
              <View style={styles.modalWaveContainer}>
                {wavePulseValues.map((_, index) => (
                  <Animated.View
                    key={`processing-wave-${index}`}
                    pointerEvents="none"
                    style={[
                      styles.modalWave,
                      {backgroundColor: PROCESSING_WAVE_COLOR},
                      waveAnimatedStyles[index],
                    ]}
                  />
                ))}
                <View style={styles.modalLogoHolder}>
                  <Image
                    source={Images.Sooprsnewlogo}
                    style={styles.modalLogo}
                    resizeMode="contain"
                  />
                </View>
              </View>
            </View>
            <Text style={styles.modalTitle}>
              Sooper AI is processing your requirement
            </Text>
            <Text style={styles.modalSubtitle}>
              Hang tight while we match you with the best solution for your
              request.
            </Text>
            <TouchableOpacity
              style={styles.modalButton}
              activeOpacity={0.85}
              onPress={handleCloseProcessingModal}>
              <Text style={styles.modalButtonText}>Got it</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
      <KeyboardAvoidingView
        style={styles.keyboardAvoider}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={hp(1)}>
        <View style={styles.header}>
          <TouchableOpacity
            activeOpacity={0.8}
            style={styles.backButton}
            onPress={() => navigation.goBack()}>
            <Image
              source={Images.backArrow}
              style={styles.backIcon}
              resizeMode="contain"
            />
          </TouchableOpacity>
          {/* <View style={styles.avatarPlaceholder} /> */}
          <Text style={styles.headerTitle}>Sooprs — Service Assistant</Text>
        </View>

        <View style={styles.container}>
          <FlatList
            ref={flatListRef}
            data={messages}
            keyExtractor={item => item.id}
            renderItem={renderMessage}
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
            ListFooterComponent={
              isTyping ? (
                <View style={styles.messageWrapper}>
                  <View style={[styles.messageBubble, styles.botBubble, styles.typingIndicatorBubble]}>
                    <View style={styles.typingDotsContainer}>
                      {typingDotAnimations.map((anim, index) => (
                        <Animated.View
                          key={`typing-dot-${index}`}
                          style={[
                            styles.typingDot,
                            {
                              opacity: anim.interpolate({
                                inputRange: [0, 1],
                                outputRange: [0.3, 1],
                              }),
                              transform: [
                                {
                                  translateY: anim.interpolate({
                                    inputRange: [0, 1],
                                    outputRange: [0, -8],
                                  }),
                                },
                              ],
                            },
                          ]}
                        />
                      ))}
                    </View>
                  </View>
                </View>
              ) : null
            }
          />

          {activeStep && activeStep.options.length > 0 && !isTextInputQuestion && (
            <View style={styles.optionsContainer}>
              <View style={styles.optionsWrap}>
                {activeStep.options.map(option => (
                  <Pressable
                    key={option.id}
                    onPress={() => handleOptionPress(option)}
                    onHoverIn={() => setHoveredOptionId(option.id)}
                    onHoverOut={() =>
                      setHoveredOptionId(prev =>
                        prev === option.id ? null : prev,
                      )
                    }
                    onPressOut={() =>
                      setHoveredOptionId(prev =>
                        prev === option.id ? null : prev,
                      )
                    }
                    style={state => [
                      styles.optionChip,
                      (hoveredOptionId === option.id || state.pressed) &&
                        styles.optionChipHover,
                    ]}>
                    <Text style={styles.optionText}>{option.label}</Text>
                  </Pressable>
                ))}
              </View>
            </View>
          )}

          {!isTextInputQuestion && <Text style={styles.footerHint}>{FOOTER_HINT}</Text>}
        </View>

        {activeStep && !isFlowCompleted && (
          <View style={[styles.inputContainer, !isTextInputQuestion && {backgroundColor:"#F5F5F5"}]}>
            {/* <TouchableOpacity
              activeOpacity={0.85}
              style={styles.attachmentButton}
              onPress={handleAttachmentPick}>
              <Image
                source={Images.addIcon}
                style={styles.attachmentIcon}
                resizeMode="contain"
              />
            </TouchableOpacity> */}
            <TextInput
              style={[
                styles.textInput,
                !isTextInputQuestion && styles.textInputDisabled,
              ]}
              value={manualInput}
              onChangeText={setManualInput}
              placeholder={isTextInputQuestion ? "Type your answer..." : "Type your message..."}
              placeholderTextColor={Colors.grey}
              multiline
              editable={isTextInputQuestion}
              returnKeyType="send"
              onSubmitEditing={handleManualSend}
            />
            <TouchableOpacity
              activeOpacity={0.85}
              onPress={handleManualSend}
              style={[
                styles.sendButton,
                !isTextInputQuestion && styles.sendButtonDisabled,
              ]}
              disabled={!isTextInputQuestion || !manualInput.trim()}>
              <Text style={styles.sendButtonText}>Send</Text>
            </TouchableOpacity>
          </View>
        )}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

export default PostChatSceen;

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: Colors.sooprslight,
  },
  keyboardAvoider: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: wp(4),
    paddingVertical: hp(1.8),
    backgroundColor: Colors.sooprsDark,
  },
  backButton: {
    width: wp(8),
    height: wp(8),
    borderRadius: wp(4),
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: wp(2),
  },
  backIcon: {
    width: hp(4),
    height: hp(4),
    tintColor: Colors.white,
  },
  avatarPlaceholder: {
    width: wp(10),
    height: wp(10),
    borderRadius: wp(5),
    backgroundColor: 'rgba(255,255,255,0.25)',
    marginRight: wp(3),
  },
  headerTitle: {
    color: Colors.white,
    fontSize: FSize.fs15,
    fontWeight: '600',
  },
  container: {
    flex: 1,
    paddingHorizontal: wp(3),
    paddingBottom: hp(2),
  },
  listContent: {
    paddingTop: hp(2),
    paddingBottom: hp(1),
  },
  messageWrapper: {
    marginBottom: hp(1.5),
    flexDirection: 'row',
  },
  messageWrapperBot: {
    justifyContent: 'flex-start',
  },
  messageWrapperUser: {
    justifyContent: 'flex-end',
  },
  messageBubble: {
    maxWidth: '78%',
    paddingVertical: hp(1.6),
    paddingHorizontal: wp(4),
    borderRadius: wp(3.8),
    backgroundColor: Colors.white,
  },
  botBubble: {
    borderBottomLeftRadius: wp(1.8),
    backgroundColor: Colors.white,
  },
  userBubble: {
    backgroundColor: Colors.sooprsblue,
    borderBottomRightRadius: wp(1.8),
  },
  messageText: {
    fontSize: FSize.fs13,
    lineHeight: hp(2.4),
  },
  botMessageText: {
    color: Colors.darkblack,
    fontWeight: '500',
    fontSize: FSize.fs17,
  },
  userMessageText: {
    color: Colors.white,
    fontWeight: '500',
    fontSize: FSize.fs17,
  },
  attachmentBubble: {
    backgroundColor: '#F5F9FF',
    borderWidth: 1,
    borderColor: 'rgba(0,119,255,0.2)',
  },
  attachmentImage: {
    width: wp(48),
    height: wp(48),
    borderRadius: wp(3),
    marginBottom: hp(1),
  },
  attachmentDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: hp(1),
  },
  attachmentThumb: {
    width: wp(6),
    height: wp(6),
    tintColor: Colors.sooprsblue,
    marginRight: wp(2),
  },
  attachmentName: {
    flex: 1,
    fontSize: FSize.fs13,
    lineHeight: hp(2.1),
  },
  attachmentNameUser: {
    color: Colors.sooprsDark,
    fontWeight: '700',
  },
  attachmentNameBot: {
    color: Colors.darkblack,
    fontWeight: '600',
  },
  systemMessageWrapper: {
    alignItems: 'center',
    marginTop: hp(1.2),
  },
  systemMessageText: {
    fontSize: FSize.fs13,
    color: Colors.sooprsDark,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  optionsContainer: {
    marginTop: hp(1.2),
    paddingVertical: hp(0.5),
  },
  optionsWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  optionChip: {
    marginRight: wp(2.2),
    marginBottom: hp(1.1),
    borderRadius: wp(5),
    backgroundColor: Colors.white,
    paddingVertical: hp(1),
    paddingHorizontal: wp(3),
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(0,0,0,0.08)',
  },
  optionChipHover: {
    backgroundColor: '#E6F2FF',
    borderColor: 'rgba(0,119,255,0.35)',
    transform: [{scale: 1.05}],
  },
  optionText: {
    fontSize: FSize.fs15,
    color: Colors.darkblack,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  footerHint: {
    textAlign: 'center',
    color: Colors.grey,
    fontSize: FSize.fs12,
    marginTop: hp(1),
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.45)',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: wp(6),
  },
  modalContent: {
    width: '100%',
    maxWidth: wp(90),
    borderRadius: wp(5),
    backgroundColor: Colors.white,
    paddingHorizontal: wp(6),
    paddingVertical: hp(3.2),
    alignItems: 'center',
    shadowColor: '#001533',
    shadowOffset: {width: 0, height: 12},
    shadowOpacity: 0.25,
    shadowRadius: 24,
    elevation: 10,
  },
  modalVisualWrap: {
    width: '100%',
    alignItems: 'center',
    marginBottom: hp(3),
  },
  modalWaveContainer: {
    width: wp(34),
    height: wp(34),
    borderRadius: wp(17),
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalWave: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    borderRadius: wp(16),
  },
  modalLogoHolder: {
    width: wp(25),
    height: wp(16),
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalLogo: {
    width: wp(25),
    height: hp(7.6),
  },
  modalTitle: {
    fontSize: FSize.fs19,
    fontWeight: '700',
    color: Colors.darkblack,
    textAlign: 'center',
    marginBottom: hp(1.4),
  },
  modalSubtitle: {
    fontSize: FSize.fs13,
    color: Colors.grey,
    textAlign: 'center',
    lineHeight: hp(2.3),
    marginBottom: hp(2.6),
  },
  modalButton: {
    borderRadius: wp(4.5),
    backgroundColor: Colors.sooprsblue,
    paddingVertical: hp(1.2),
    paddingHorizontal: wp(6),
    shadowColor: '#1D4ED8',
    shadowOffset: {width: 0, height: 6},
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 5,
  },
  modalButtonText: {
    color: Colors.white,
    fontWeight: '600',
    fontSize: FSize.fs14,
    letterSpacing: 0.3,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: wp(4),
    marginBottom: Platform.OS === 'ios' ? hp(3) : hp(2),
    paddingHorizontal: wp(4),
    paddingVertical: Platform.OS === 'ios' ? hp(1.2) : hp(0.6),
    borderRadius: wp(5),
    backgroundColor: Colors.white,
    shadowColor: '#00336622',
    shadowOffset: {width: 0, height: 4},
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 4,
  },
  textInput: {
    flex: 1,
    fontSize: FSize.fs13,
    color: Colors.darkblack,
    paddingVertical: hp(1.2),
    paddingRight: wp(2),
  },
  textInputDisabled: {
    opacity: 0.5,
    backgroundColor: '#F5F5F5',
  },
  attachmentButton: {
    width: wp(11),
    height: wp(11),
    borderRadius: wp(5.5),
    backgroundColor: Colors.white,
    borderWidth: 1,
    borderColor: Colors.sooprsblue,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: wp(2),
  },
  attachmentIcon: {
    width: wp(5),
    height: wp(5),
    tintColor: Colors.sooprsblue,
  },
  sendButton: {
    borderRadius: wp(4),
    backgroundColor: Colors.sooprsblue,
    paddingVertical: hp(1),
    paddingHorizontal: wp(4),
  },
  sendButtonDisabled: {
    opacity: 0.5,
    backgroundColor: Colors.grey,
  },
  sendButtonText: {
    color: Colors.white,
    fontSize: FSize.fs12,
    fontWeight: '600',
  },
  typingIndicatorBubble: {
    minWidth: wp(12),
    paddingVertical: hp(1.2),
    paddingHorizontal: wp(4),
  },
  typingDotsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  typingDot: {
    width: wp(1.5),
    height: wp(1.5),
    borderRadius: wp(0.75),
    backgroundColor: Colors.darkblack,
    marginHorizontal: wp(0.8),
  },
});