import {StyleSheet, View, ActivityIndicator} from 'react-native';
import React, {useEffect, useState} from 'react';
import {wp, hp} from '../../assets/commonCSS/GlobalCSS';
import FSize from '../../assets/commonCSS/FSize';
import Colors from '../../assets/commonCSS/Colors';
import ProfileComponent from '../../components/ProfileComponent';
import ProfileTabs from '../../components/ProfileTabs';
import NewHeader from '../../components/NewHeader';
import {useSelector} from 'react-redux';

const ProfessionalProfile = ({
  navigation,
  route,
}: {
  navigation: any;
  route: any;
}) => {
  const {id, slug} = route?.params;
  const [isClient, setisClient] = useState(false);
  const tabs = ['Details', 'Portfolio', 'Gigs', 'Reviews'];
  const [loading, setLoading] = useState(true);
  const [userInformation, setUserInformation] = useState({});
  const getUserDetails = useSelector(state => state?.getUserDetails);
  const currency = getUserDetails?.country == 'IN' ? 'INR' : 'USD';
  useEffect(() => {
    getUserInformation();
  }, []);
  const getUserInformation = async () => {
    const formdata = new FormData();
    formdata.append('slug', slug);
    formdata.append('cur', currency);
    try {
      const res = await fetch(
        'https://sooprs.com/api2/public/index.php/get_user_details',
        {
          method: 'POST',
          body: formdata,
        },
      );
      const response = await res?.json();
      if (response?.status == 200) {
        setUserInformation(response?.msg[0]);
        // console.log('userInformation==>', response?.msg);
      }
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      {/* <ScrollView style={styles.profileView}> */}
      <NewHeader 
        header={'Profile'} 
        navigation={navigation}
        hideBackButton={false}
        onBackPress={() => {
          if (navigation && navigation.navigate) {
            navigation.navigate('ProfessionalsList');
          } else if (navigation && navigation.goBack) {
            navigation.goBack();
          }
        }}
      />
      {loading ? (
        <ActivityIndicator
          color={Colors.sooprsblue}
          style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}
        />
      ) : (
        <>
          <View style={{}}>
            <ProfileComponent
              navigation={navigation}
              img={userInformation?.image}
              name={userInformation?.name}
              role={
                userInformation?.services_name &&
                userInformation?.services_name[0]
              }
              // rating={4.5}
            />
          </View>
          <ProfileTabs
            tabs={tabs}
            isClient={isClient}
            portfolio={id}
            services={userInformation?.services_name}
            skills={userInformation?.skills}
            about={userInformation?.listing_about}
            education={userInformation?.education}
            experience={userInformation?.experience}
            portFolios={userInformation?.portfolios}
            reviews={userInformation?.reviews}
            gigs={userInformation?.gigs}
            currency={currency}
            navigation={navigation}
          />
        </>
      )}
    </View>
  );
};

export default ProfessionalProfile;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },

  profileView: {
    margin: wp(2),
  },

  profileSection: {
    marginHorizontal: wp(5),
    marginVertical: hp(5),
    flexDirection: 'row',
    justifyContent: 'space-between',
  },

  backArrow: {
    width: wp(8),
    height: hp(8),
  },
  profile: {
    flexDirection: 'column',
    justifyContent: 'center',
    marginRight: wp(20),
    marginVertical: hp(5),
    alignItems: 'center',
    gap: 1,
  },
  profileIcon: {
    width: wp(50),
    height: hp(25),
    borderWidth: 5,
    borderColor: '#D4E3FC',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: wp(30),
    marginBottom: wp(2),
  },
  Icon: {
    width: hp(23),
    height: hp(23),
    borderRadius: wp(50),
  },
  starIcon: {
    width: wp(3),
    height: hp(3),
  },
  rating: {
    fontSize: FSize.fs12,
    color: Colors.black,
  },
  profileName: {
    fontSize: FSize.fs24,
    fontWeight: '600',
    color: Colors.black,
  },
  profileRole: {
    fontSize: FSize.fs12,
    fontWeight: '500',
    color: Colors.gray,
  },

  ratings: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
