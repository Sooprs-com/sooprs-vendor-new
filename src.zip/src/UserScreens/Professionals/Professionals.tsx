import {
  StyleSheet,
  Text,
  View,
  Image,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import React, {useEffect, useRef, useState} from 'react';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import FSize from '../../assets/commonCSS/FSize';
import Images from '../../assets/image';
import Header from '../../components/Header';
import SearchBar from '../../components/SearchBar';
import Filter from '../../components/Filter';
import Colors from '../../assets/commonCSS/Colors';
import IntroCard from '../../components/IntroCard';
import HomeSectionTitle from '../../components/HomeSectionTitle';
import CategoriesList from '../../components/CategoriesList';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {mobile_siteConfig} from '../../services/mobile-siteConfig';
import {
  useIsFocused,
  useRoute,
  validatePathConfig,
} from '@react-navigation/native';
import AllProfessionals from '../../components/AllProfessionals';
import {useSelector} from 'react-redux';
import {getDataWithToken} from '../../services/mobile-api';
import NewHeader from '../../components/NewHeader';

const Professionals = ({navigation, route}: {navigation: any; route: any}) => {
  const {item = {}, hideBackButton = true} = route?.params || {};
  console.log('item', item);
  const ITMES_PER_LOAD = 15;
  const [professionals, setProfessionals] = useState([]);
  const [services, setServices] = useState([]);
  const [selectedService, setSelectedService] = useState({}); // New state for selected service
  const [name, setName] = useState('');
  const [profilePic, setProfilePic] = useState(null);
  const [searched, setSearched] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [allProfessionals, setAllProfessionals] = useState([]);
  const [hasMore, setHasMore] = useState(false);
  const isFocused = useIsFocused();
  const getUserDetails = useSelector(state => state?.getUserDetails);
  useEffect(() => {
    setProfilePic(getUserDetails?.image);
    setName(getUserDetails?.name);
    fetchServices();
  }, [isFocused]);
  // getCategories
  const fetchServices = async () => {
    try {
      const response = await getDataWithToken(
        mobile_siteConfig.GET_SELECTED_CATEGORIES,
      );
      if (response?.status === 'success') {
        console.log('response==>12345',response?.data)
        const services = response.data
          .map(service => ({
            label: service.service_name,
            value: service.flag,
            catId: service?.id,
          }))
          .sort((a, b) => a?.value - b?.value);
        services.unshift({label: 'All', value: 'All', catId: 0});
        if (item?.label) {
          const index = services.findIndex(val => val.catId == item?.catId);
          setSelectedService(services[index]);
          getProfessionals(item);
        } else {
          setSelectedService(services[0]);
          getProfessionals();
        }

        setServices(services);
        console.log('services==>12345',services)
      }
    } catch (error) {
      console.error('Error fetching selected services:', error);
      setLoading(false);
    }
  };
  // getProfessionals
  const getProfessionals = async item => {
    const formdata = new FormData();
    if (item?.catId) formdata.append('dataValue', item?.catId);
    const requestOptions = {
      method: 'POST',
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      ...(item?.catId && {body: formdata}),
    };
    try {
      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/filter_service_ajax',
        requestOptions,
      );
      const res = await response.json();
      if (res?.status == 200) {
        setAllProfessionals(res?.msg);
        showMore(res?.msg);
      }
    } catch (error) {
      console.error('Error fetching professionals:', error);
    } finally {
      setLoading(false);
    }
  };
  // pegination
  const showMore = data => {
    const endIndex = currentPage * ITMES_PER_LOAD;
    setProfessionals(data?.slice(0, endIndex));
    if (data?.length > ITMES_PER_LOAD * currentPage) {
      setCurrentPage(currentPage + 1);
      setHasMore(true);
    } else {
      setHasMore(false);
    }
  };
  return (
    <View style={{flex: 1}}>
      {/* <Header
        navigation={navigation}
        img={profilePic}
        name={name || 'User'}
        btnName="Post a project"
        isClient={true}
      /> */}
      <NewHeader
        header={'Professionals'}
        hideBackButton
        navigation={navigation}
      />
      <ScrollView style={styles.container}>
        <View style={styles.section}>
          <View style={styles.searchFilter}>
            <SearchBar
              placeholderName="Professionals..."
              setSearched={setSearched}
              setLoading={setLoading}
            />
          </View>
          <CategoriesList
            navigation={navigation}
            services={services}
            onSelectService={setSelectedService}
            selectedService={selectedService}
            setLoading={setLoading}
            setAllData={setAllProfessionals}
            setCurrentPage={setCurrentPage}
            showMore={showMore}
          />
          {loading ? (
            <View style={{marginTop: hp(10)}}>
              <ActivityIndicator color={Colors.sooprsblue} />
            </View>
          ) : (
            <AllProfessionals
              professionals={professionals}
              navigation={navigation}
              selectedService={selectedService}
              searched={searched}
              onShowMore={() => showMore(allProfessionals)}
              hasMore={hasMore}
            />
          )}
        </View>
      </ScrollView>
    </View>
  );
};

export default Professionals;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },

  section: {
    marginHorizontal: wp(5),
    marginVertical: hp(1),
  },
  homeInfo: {
    color: Colors.black,
    fontWeight: '600',
    fontSize: FSize.fs19,
  },

  textAlign: {
    // justifyContent:'center',
    // alignItems:'center',
    flexDirection: 'row',
    flexWrap: 'wrap',
    // width:wp(90)
  },

  profText: {
    color: Colors.sooprsblue,
    fontSize: FSize.fs19,
  },

  searchFilter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
});
