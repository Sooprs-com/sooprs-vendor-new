import React, {useEffect, useRef, useState} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  FlatList,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import {MultiSelect} from 'react-native-element-dropdown';
import CustomHeader from '../../components/CustomHeader';
import Colors from '../../assets/commonCSS/Colors';
import CustomButton from '../../components/CustomButton';
import {hp} from '../../assets/commonCSS/GlobalCSS';
import {getDataWithToken, postData} from '../../services/mobile-api';
import {mobile_siteConfig} from '../../services/mobile-siteConfig';
import {CommonActions, useNavigation} from '@react-navigation/native';
import {
  getDataFromAsyncStorage,
  storeDataToAsyncStorage,
} from '../../services/CommonFunction';
import Toast from 'react-native-toast-message';
import {useDispatch, useSelector} from 'react-redux';
import {setUserDetails} from '../../Redux/Actions';
import NewHeader from '../../components/NewHeader';
import CategoriesList from './CategoriesList';
import FSize from '../../assets/commonCSS/FSize';

const UserCategories = () => {
  const [allServices, setAllServices] = useState([]);
  const [addedServices, setAddedServices] = useState([]);
  const [dropDownItems, setDropDownItems] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const navigation = useNavigation();
  const getUserId = useSelector(state => state?.getUserId);
  const dispatch = useDispatch();
  useEffect(() => {
    initializeData();
  }, []);

  const initializeData = async () => {
    setIsLoading(true);
    try {
      await fetchSelectedServices();
      await fetchCategories();
    } catch (error) {
      console.error('Initialization Error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchSelectedServices = async () => {
    try {
      const response = await getDataWithToken(
        mobile_siteConfig.GET_SELECTED_CATEGORIES,
      );
      if (response?.status === 'success') {
        const services = response.data.map(service => ({
          label: service.service_name,
          value: service.flag,
        }));
        setDropDownItems(services);
      }
    } catch (error) {
      console.error('Error fetching selected services:', error);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await postData({}, mobile_siteConfig.GET_CATEGORIES);
      if (response?.status === 200) {
        setAllServices(response.msg);
      }
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const handleAddButton = async () => {
    if (addedServices.length === 0) {
      return Toast.show({
        type: 'error',
        text1: 'Error',
        text2: 'Please select services to proceed',
        position: 'top',
      });
    }

    setIsLoading(true);
    const payload = new URLSearchParams();
    addedServices.forEach(item => payload.append('service[]', item.id));
    payload.append('profid', getUserId);

    try {
      const response = await fetch(
        mobile_siteConfig.BASE_URL +
          mobile_siteConfig.INDEX +
          mobile_siteConfig.POST_SERVICE_ID,
        {
          method: 'POST',
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          body: payload.toString(),
        },
      );
      const data = await response.json();
      if (data?.status === 200) {
        Toast.show({
          type: 'success',
          text1: 'Success',
          text2: data.msg,
          position: 'top',
        });
        await storeDataToAsyncStorage(
          mobile_siteConfig.HAS_ADDED_SERVICES,
          'true',
        );
        // Call user-status-app API
        try {
          const token = await getDataFromAsyncStorage(mobile_siteConfig.TOKEN);
          const statusResponse = await fetch(
            'https://sooprs.com/api2/public/index.php/user-status-app',
            {
              method: 'GET',
              headers: {
                Authorization: `Bearer ${token}`,
              },
            },
          );
          const statusData = await statusResponse.json();

          if (statusResponse.ok) {
            if (statusData?.status == 'success') {
              await storeDataToAsyncStorage(
                mobile_siteConfig.IS_BUYER,
                statusData?.data?.is_buyer,
              );
              getUserData();
            }
          } else {
            throw new Error(
              statusData?.message || 'Error fetching user status',
            );
          }
        } catch (statusError) {
          console.error('Error fetching user status:', statusError);
          Toast.show({
            type: 'error',
            text1: 'Error',
            text2: 'Failed to fetch user status. Please try again.',
            position: 'top',
          });
        }
      }
    } catch (error) {
      console.error('Error posting service ID:', error);
      setIsLoading(false);
    }
  };
  // update the latest data
  const getUserData = async msg => {
    try {
      const response = await getDataWithToken(mobile_siteConfig.USER_DETAILS);
      if (response?.status == 200) {
        dispatch(setUserDetails(response?.data));
        let resetAction = CommonActions.reset({
          index: 0,
          routes: [
            {
              name: 'ProfessionalBottomTab',
            },
          ],
        });
        navigation.dispatch(resetAction);
      }
    } catch (error) {
      console.log('error in gettting user details', error);
      Toast.show({
        type: 'error',
        text1: 'Error',
        text2: 'Something went wrong',
        position: 'top',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelection = service => {
    if (!addedServices.some(added => added.id === service.id)) {
      setAddedServices([...addedServices, service]);
    } else {
      setAddedServices(addedServices.filter(item => item.id !== service.id));
    }
  };
  return (
    <SafeAreaView style={styles.container}>
      <NewHeader header={'Services'} hideBackButton />
      {isLoading ? (
        <View style={styles.loaderContainer}>
          <ActivityIndicator size="large" color={Colors.sooprsblue} />
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <Text style={styles.infoText}>
            Select your categories to add them.
          </Text>
          <CategoriesList
            data={dropDownItems}
            categories={allServices}
            handleAddCategories={handleSelection}
            selectedCategories={addedServices}
          />
        </ScrollView>
      )}
      <CustomButton
        buttonText="Add Now"
        buttonStyle={{position: 'absolute', bottom: hp(2)}}
        onButtonPress={handleAddButton}
      />
    </SafeAreaView>
  );
};

export default UserCategories;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollContainer: {
    paddingBottom: hp(10),
    padding: 16,
  },
  infoText: {
    backgroundColor: '#F3F4F6',
    padding: 10,
    borderRadius: 5,
    marginBottom: 15,
    fontSize: FSize.fs16,
    color: Colors.black,
    alignSelf: 'flex-start',
    fontWeight: 'bold',
  },
  dropdown: {
    borderWidth: 1,
    borderColor: Colors.lightGrey,
    borderRadius: 5,
    padding: 10,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginVertical: 10,
    color: Colors.black,
  },
  serviceItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.white,
    borderWidth: 1,
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
    borderColor: '#999999',
  },
  serviceText: {
    color: '#999999',
    fontSize: 16,
  },
  actionButton: {
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 12,
    backgroundColor: '#F5F5F5',
  },
  actionText: {
    color: '#999999',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
