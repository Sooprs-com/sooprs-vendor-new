import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React, {useRef, useState} from 'react';
import Images from '../../assets/image';
import Colors from '../../assets/commonCSS/Colors';
import FSize from '../../assets/commonCSS/FSize';
import Icons from 'react-native-vector-icons/MaterialCommunityIcons';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';

const CategoriesList = ({
  data = [],
  categories = [],
  handleAddCategories,
  selectedCategories = [],
}) => {
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const rotateRef = useRef(data.map(() => useSharedValue(-90)));
  const heightRef = useRef(data.map(() => useSharedValue(0)));
  const opacityRef = useRef(data.map(() => useSharedValue(0)));
  const listHeights = useRef({}); 

  const AnimatedIcons = Animated.createAnimatedComponent(Image);

  const getAnimatedStyles = index => {
    return useAnimatedStyle(() => ({
      transform: [{rotate: `${rotateRef.current[index].value}deg`}],
    }));
  };

  const getListAnimatedStyle = index => {
    return useAnimatedStyle(() => ({
      opacity: opacityRef.current[index].value,
      maxHeight: heightRef.current[index].value, // Dynamic height
      overflow: 'hidden',
    }));
  };
  const newCategories = data.map((item, index) => ({
    ...item,
    services: categories.filter(service => service?.flag === item?.value),
  }));

  const handleSelect = index => {
    if (selectedIndex !== -1) {
      rotateRef.current[selectedIndex].value = withTiming(-90, {duration: 200});
      heightRef.current[selectedIndex].value = withTiming(0, {duration: 200});
      opacityRef.current[selectedIndex].value = withTiming(0, {duration: 200});
    }

    if (selectedIndex === index) {
      setSelectedIndex(-1);
    } else {
      rotateRef.current[index].value = withTiming(90, {duration: 200});
      heightRef.current[index].value = withTiming(
        listHeights.current[index] || 100,
        {duration: 300},
      );
      opacityRef.current[index].value = withTiming(1, {duration: 300});
      setSelectedIndex(index);
    }
  };

  return newCategories.map((item, index) => (
    <View key={index}>
      <TouchableOpacity
        activeOpacity={0.7}
        style={styles.container}
        onPress={() => handleSelect(index)}>
        <Text style={styles.label}>{item?.label}</Text>
        <AnimatedIcons
          source={Images.chevRight}
          style={[styles.img, getAnimatedStyles(index)]}
        />
      </TouchableOpacity>

      {/* Measure Layout and store height dynamically */}
      <View
        style={{position: 'absolute', opacity: 0, left: -9999}}
        onLayout={event => {
          listHeights.current[index] = event.nativeEvent.layout.height;
        }}>
        {item?.services?.map((service, i) => (
          <View key={i} style={styles.subCat}>
            <Icons
              name={
                selectedCategories.some(item => item?.id === service.id)
                  ? 'checkbox-outline'
                  : 'checkbox-blank-outline'
              }
              size={22}
              color={'#444444'}
            />
            <Text style={styles.categoryText}>{service?.service_name}</Text>
          </View>
        ))}
      </View>

      <Animated.View style={getListAnimatedStyle(index)}>
        {item?.services?.map((service, i) => (
          <TouchableOpacity
            key={i}
            style={styles.subCat}
            activeOpacity={0.7}
            onPress={() => handleAddCategories(service)}>
            <Icons
              name={
                selectedCategories.some(item => item?.id === service.id)
                  ? 'checkbox-outline'
                  : 'checkbox-blank-outline'
              }
              size={22}
              color={'#444444'}
            />
            <Text style={styles.categoryText}>{service?.service_name}</Text>
          </TouchableOpacity>
        ))}
      </Animated.View>

      <View style={styles.border} />
    </View>
  ));
};

export default CategoriesList;

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 5,
  },
  img: {height: 20, width: 20},
  label: {color: Colors.black, fontSize: FSize.fs16, fontWeight: 'bold'},
  border: {
    height: 0,
    width: '100%',
    borderTopWidth: 0.5,
    borderColor: Colors.grey,
    marginVertical: 10,
  },
  categoryText: {
    color: '#444444',
    fontSize: FSize.fs14,
    marginLeft: 8,
    fontWeight: '500',
  },
  subCat: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 2,
    marginLeft: 8,
  },
});
