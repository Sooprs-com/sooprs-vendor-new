import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Image,
  FlatList,
  ActivityIndicator,
  Platform,
} from 'react-native';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import Colors from '../../assets/commonCSS/Colors';
import FSize from '../../assets/commonCSS/FSize';
import Images from '../../assets/image'; // Your image assets
import {useIsFocused} from '@react-navigation/native';
import Toast from 'react-native-toast-message';
import AsyncStorage from '@react-native-async-storage/async-storage';
// @ts-ignore
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

const ProjectBids = ({navigation, route}: {navigation: any; route: any}) => {
  // const navigation = useNavigation();
  const {id, project_status} = route?.params;
  const [bids, setBids] = useState<any[]>([]);
  const [rewardedBids, setRewardedBids] = useState<any[]>([]);
  const isFocused = useIsFocused();
  const [userId, setuserId] = useState<string | null>(null);
  const [recieverId, setrecieverId] = useState<string | null>(null);
  const [leadId, setleadId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [bidId, setbidId] = useState<string | null>(null);
  const [currentIndex, setIndex] = useState(-1);
  useEffect(() => {
    getBids();
  }, []);
  const getBids = async () => {
    let lead_id = await AsyncStorage.getItem('uid');
    // If lead_id has extra quotes, remove them
    if (lead_id) {
      lead_id = lead_id.replace(/^"|"$/g, '');
    }
    setuserId(lead_id);
    setleadId(id);
    console.log('..............', id);
    const formdata = new FormData();
    formdata.append('lead_id', id);

    const requestOptions = {
      method: 'POST',
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      body: formdata,
    };

    fetch(
      'https://sooprs.com/api2/public/index.php/query_detail',
      requestOptions,
    )
      .then(response => response.json())
      .then(res => {
        if (res.status === 200) {
          console.log('bids details:::::::', res.msg);
          setBids(res.msg);
        }
      })
      .catch(error => {
        console.error('Error fetching bids:', error);
      });
  };

  const handleReward = (id: any, index: any) => {
    setIndex(index);
    setLoading(true);
    const formdata = new FormData();
    formdata.append('lead_id', id);

    const requestOptions = {
      method: 'POST',
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      body: formdata,
    };

    fetch(
      'https://sooprs.com/api2/public/index.php/reward_project',
      requestOptions,
    )
      .then(response => response.json())
      .then(res => {
        if (res.status === 200) {
          setRewardedBids([...rewardedBids, id]);
          getBids();
          Toast.show({
            type: 'success',
            text1: 'Bid rewarded',
            text2: 'You have successfully rewarded the bid!',
            position: 'top',
            text1Style: {fontSize: 16, fontWeight: '600'},
            text2Style: {fontSize: 14, color: '#666'},
          });
        } else {
          getBids();
          Toast.show({
            type: 'info',
            text1: res?.msg,
            position: 'top',
            text1Style: {fontSize: 16, fontWeight: '600'},
            text2Style: {fontSize: 14, color: '#666'},
          });
          console.log('something went wrong...', res);
        }
      })
      .catch(error => {
        console.error('Error fetching bids:', error);
      })
      .finally(() => setLoading(false));
  };
  // Format date to "12 Nov 2025" format
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    try {
      const date = new Date(dateString);
      const months = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
      ];
      const day = date.getDate();
      const month = months[date.getMonth()];
      const year = date.getFullYear();
      return `${day} ${month} ${year}`;
    } catch (e) {
      return dateString;
    }
  };

  // Render each bid as a card
  const renderBidCard = ({item, index}: {item: any; index: number}) => {
    const isRewarded = rewardedBids.includes(item.id); // Check if this bid is rewarded
    return (
      <View style={styles.cardContainer}>
        <View style={styles.cardTopRow}>
          <View style={styles.bidderInfo}>
            <MaterialCommunityIcons 
              name="account" 
              size={wp(5)} 
              color={Colors.black} 
              style={styles.personIcon}
            />
            <Text style={styles.proName}>{item.professional_name}</Text>
          </View>
          <Text style={styles.amountText}>₹{item.amount}</Text>
        </View>
        <View style={styles.dateRow}>
          <MaterialCommunityIcons 
            name="calendar" 
            size={wp(4)} 
            color={Colors.gray} 
            style={styles.calendarIcon}
          />
          <Text style={styles.dateText}>Bid on: {item.createdDate}</Text>
        </View>
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={styles.chatButton}
            onPress={() => {
              navigation.navigate('IndividualChat', {
                name: item.professional_name,
                userId: userId,
                leadId: leadId,
                bidId: item.id,
                recieverId: item.prof_id,
                id: id,
                project_status: project_status,
              });
            }}>
            <MaterialCommunityIcons 
              name="message-text-outline" 
              size={wp(4.5)} 
              color={Colors.sooprsblue} 
            />
            
            <Text style={styles.chatButtonText}>Chat</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.rewardButton,
              isRewarded && styles.rewardedButton
            ]}
            onPress={() => handleReward(item.id, index)}
            disabled={isRewarded || (loading && index == currentIndex)}
          >
            {loading && index == currentIndex ? (
              <ActivityIndicator color={Colors.white} size="small" />
            ) : (
              <>
                {/* <MaterialCommunityIcons 
                  name="gift-outline" 
                  size={wp(4.5)} 
                  color={Colors.white} 
                /> */}
                <Text style={styles.rewardButtonText}>
                  {isRewarded ? 'Assigned' : 'Assign'}
                </Text>
              </>
            )}
          </TouchableOpacity>
        </View>
      </View>
    );
  };
  return (
    <View style={styles.section}>
      <View style={styles.headerContainer}>
        <View style={styles.headerContent}>
          <TouchableOpacity 
            onPress={() => navigation.navigate('ViewProjects')}
            style={styles.backButton}>
            <MaterialCommunityIcons 
              name="arrow-left" 
              size={wp(6)} 
              color={Colors.white} 
            />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Total Bids</Text>
          <View/>
          {/* <TouchableOpacity 
            style={styles.viewDetailsButton}
            onPress={() => {
              navigation.navigate('ClientProjectDetails', {id: id});
            }}>
            <Text style={styles.viewDetailsText}>View Details</Text>
          </TouchableOpacity> */}
        </View>
      </View>

      <FlatList
        data={bids}
        renderItem={renderBidCard}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContainer}
        ListEmptyComponent={
          <Image
            source={Images.nodata}
            style={{
              height: hp(40),
              width: wp(65),
              alignSelf: 'center',
              marginTop: hp(10),
            }}
            resizeMode="contain"
          />
        }
      />
    </View>
  );
};

export default ProjectBids;

const styles = StyleSheet.create({
  section: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  headerContainer: {
    backgroundColor: Colors.sooprsDark,
    paddingTop: Platform.OS === 'ios' ? hp(6) : hp(2),
    paddingBottom: hp(2),
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: wp(4),
    paddingTop: Platform.OS === 'ios' ? hp(1) : 0,
  },
  backButton: {
    padding: wp(2),
  },
  headerTitle: {
    color: Colors.white,
    fontWeight: '500',
    fontSize: FSize.fs18,
    flex: 1,
    textAlign: 'center',
  },
  viewDetailsButton: {
    backgroundColor: Colors.white,
    paddingVertical: hp(1),
    paddingHorizontal: wp(4),
    borderRadius: wp(2),
  },
  viewDetailsText: {
    color: Colors.sooprsDark,
    fontSize: FSize.fs13,
    fontWeight: '600',
  },
  listContainer: {
    paddingHorizontal: wp(5),
    paddingTop: hp(2),
  },
  cardContainer: {
    backgroundColor: Colors.white,
    padding: wp(4),
    borderRadius: wp(2),
    marginBottom: hp(2),
    shadowColor: Colors.black,
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 2,
  },
  cardTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: hp(1.5),
  },
  bidderInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  personIcon: {
    marginRight: wp(2),
  },
  proName: {
    fontSize: FSize.fs16,
    fontWeight: 'bold',
    color: Colors.black,
  },
  amountText: {
    fontSize: FSize.fs16,
    fontWeight: 'bold',
    color: Colors.sooprsDark,
  },
  dateRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: hp(2),
  },
  calendarIcon: {
    marginRight: wp(2),
  },
  dateText: {
    fontSize: FSize.fs13,
    color: Colors.gray,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: wp(3),
  },
  chatButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.white,
    borderWidth: 1,
    borderColor: Colors.sooprsblue,
    paddingVertical: hp(1.5),
    borderRadius: wp(2),
    gap: wp(2),
  },
  chatButtonText: {
    color: Colors.sooprsblue,
    fontSize: FSize.fs14,
    fontWeight: '600',
  },
  rewardButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.sooprsblue,
    paddingVertical: hp(1.5),
    borderRadius: wp(2),
    gap: wp(2),
  },
  rewardedButton: {
    backgroundColor: 'green',
  },
  rewardButtonText: {
    color: Colors.white,
    fontSize: FSize.fs14,
    fontWeight: '600',
  },
  noBidsContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  noBidsText: {
    fontSize: FSize.fs16,
    color: Colors.gray,
  },
});
