import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Platform,
} from 'react-native';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import Colors from '../../assets/commonCSS/Colors';
import FSize from '../../assets/commonCSS/FSize';
import Images from '../../assets/image';
import {useIsFocused} from '@react-navigation/native';
import {useSelector} from 'react-redux';
// @ts-ignore
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import he from 'he';

const ClientProjectDetails = ({navigation, route}: {navigation: any; route: any}) => {
  const {id} = route?.params || {};
  const isFocused = useIsFocused();
  const [loading, setLoading] = useState(true);
  const [projectData, setProjectData] = useState<any>(null);
  const [totalBids, setTotalBids] = useState(0);
  const getUserDetails = useSelector((state: any) => state?.getUserDetails);
  const currency = getUserDetails?.country == 'IN' ? 'INR' : 'USD';
  const symbol = getUserDetails?.country == 'IN' ? '₹' : '$';

  useEffect(() => {
    if (id) {
      fetchProjectDetails();
    }
  }, [isFocused, id]);

  const fetchProjectDetails = async () => {
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('id', id);
      formData.append('cur', currency);

      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/lead-details',
        {
          method: 'POST',
          body: formData,
        },
      );

      const result = await response.json();
      if (result.status == 200) {
        setProjectData(result.msg);
        // Get total bids count
        if (result.msg?.bids && Array.isArray(result.msg.bids)) {
          setTotalBids(result.msg.bids.length);
        }
      }
    } catch (error) {
      console.error('Error fetching project details:', error);
    } finally {
      setLoading(false);
    }
  };

  // Format time ago (e.g., "3 hrs ago")
  const getTimeAgo = (dateString: string) => {
    if (!dateString) return 'Recently';
    try {
      const date = new Date(dateString);
      const now = new Date();
      const diffInMs = now.getTime() - date.getTime();
      const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60));
      const diffInDays = Math.floor(diffInHours / 24);

      if (diffInHours < 1) {
        const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
        return diffInMinutes < 1 ? 'Just now' : `${diffInMinutes} min ago`;
      } else if (diffInHours < 24) {
        return `${diffInHours} ${diffInHours === 1 ? 'hr' : 'hrs'} ago`;
      } else {
        return `${diffInDays} ${diffInDays === 1 ? 'day' : 'days'} ago`;
      }
    } catch (e) {
      return 'Recently';
    }
  };

  // Format price range
  const getPriceRange = () => {
    if (!projectData) return `${symbol}0 - ${symbol}0`;
    const min = projectData.min_budget || 0;
    const max = projectData.max_budget_amount || 0;
    return `${symbol}${min.toLocaleString()} - ${symbol}${max.toLocaleString()}`;
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.sooprsblue} />
      </View>
    );
  }

  if (!projectData) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.errorText}>Project not found</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.headerContainer}>
        <View style={styles.headerContent}>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={styles.backButton}>
            <MaterialCommunityIcons
              name="arrow-left"
              size={wp(6)}
              color={Colors.white}
            />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Project Details</Text>
          <TouchableOpacity style={styles.shareButton}>
            <MaterialCommunityIcons
              name="share-variant"
              size={wp(5)}
              color={Colors.white}
            />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}>
        {/* Project Title Card */}
        <View style={styles.card}>
          <Text style={styles.projectTitle}>
            {projectData.project_title || 'Project Title'}
          </Text>
          {projectData.service_name && (
            <View style={styles.tagContainer}>
              <Text style={styles.tagText}>{projectData.service_name}</Text>
            </View>
          )}
        </View>

        {/* Project Overview Cards */}
        <View style={styles.metricsContainer}>
          <View style={styles.metricCard}>
            <Text style={styles.metricLabel}>Price Range</Text>
            <Text style={styles.metricValueGreen}>{getPriceRange()}</Text>
          </View>
          <View style={styles.metricCard}>
            <Text style={styles.metricLabel}>Total Bids</Text>
            <Text style={styles.metricValueBlue}>{totalBids}</Text>
          </View>
          <View style={styles.metricCard}>
            <Text style={styles.metricLabel}>Posted</Text>
            <Text style={styles.metricValueBlack}>
              {getTimeAgo(projectData.created_at || projectData.created_date)}
            </Text>
          </View>
        </View>

        {/* Client Requirements Card */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Client Requirements</Text>
          {projectData.description && (
            <Text style={styles.descriptionText}>
              {he.decode(projectData.description)}
            </Text>
          )}
          
          {/* Core Functionalities - You can add these as separate items if available in API */}
          {projectData.requirements && (
            <View style={styles.requirementsList}>
              {Array.isArray(projectData.requirements) ? (
                projectData.requirements.map((req: string, index: number) => (
                  <View key={index} style={styles.bulletItem}>
                    <Text style={styles.bullet}>•</Text>
                    <Text style={styles.bulletText}>{req}</Text>
                  </View>
                ))
              ) : (
                <Text style={styles.bulletText}>{projectData.requirements}</Text>
              )}
            </View>
          )}

          {/* Timeline note */}
          {projectData.timeline && (
            <Text style={styles.timelineText}>
              <Text style={styles.boldText}>
                We expect the project to be completed within {projectData.timeline}.{' '}
              </Text>
              Please provide relevant portfolio links in your proposal.
            </Text>
          )}
        </View>

        {/* Project Metadata Card */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Project Metadata</Text>
          
          <View style={styles.metadataItem}>
            <MaterialCommunityIcons
              name="file-document-outline"
              size={wp(5)}
              color={Colors.gray}
            />
            <Text style={styles.metadataLabel}>Project Type:</Text>
            <Text style={styles.metadataValue}>
              {projectData.project_type || 'Fixed Price'}
            </Text>
          </View>

          <View style={styles.metadataItem}>
            <MaterialCommunityIcons
              name="account-check"
              size={wp(5)}
              color={Colors.gray}
            />
            <Text style={styles.metadataLabel}>Client Status:</Text>
            <Text style={styles.metadataValueBlue}>
              {projectData.client_status || 'Verified'}
            </Text>
          </View>

          <View style={styles.metadataItem}>
            <MaterialCommunityIcons
              name="paperclip"
              size={wp(5)}
              color={Colors.gray}
            />
            <Text style={styles.metadataLabel}>Files Attached:</Text>
            <Text style={styles.metadataValue}>
              {projectData.files_count || 0} References
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* Bottom Action Button */}
      <View style={styles.bottomButtonContainer}>
        <TouchableOpacity
          style={styles.bottomButton}
          onPress={() => {
            navigation.navigate('ProjectBids', {
              id: id,
              project_status: projectData.status,
            });
          }}>
          <MaterialCommunityIcons
            name="wrench"
            size={wp(5)}
            color={Colors.white}
          />
          <Text style={styles.bottomButtonText}>View Total Bids</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default ClientProjectDetails;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.white,
  },
  errorText: {
    fontSize: FSize.fs16,
    color: Colors.gray,
  },
  headerContainer: {
    backgroundColor: Colors.sooprsDark,
    paddingTop: Platform.OS === 'ios' ? hp(6) : hp(2),
    paddingBottom: hp(2),
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: wp(4),
    paddingTop: Platform.OS === 'ios' ? hp(1) : 0,
  },
  backButton: {
    padding: wp(2),
  },
  headerTitle: {
    color: Colors.white,
    fontWeight: '700',
    fontSize: FSize.fs18,
    flex: 1,
    textAlign: 'center',
  },
  shareButton: {
    padding: wp(2),
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: wp(5),
    paddingTop: hp(2),
    paddingBottom: hp(10),
  },
  card: {
    backgroundColor: Colors.white,
    borderRadius: wp(3),
    padding: wp(4),
    marginBottom: hp(2),
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  projectTitle: {
    fontSize: FSize.fs20,
    fontWeight: '700',
    color: Colors.darkblack,
    marginBottom: hp(1),
    lineHeight: hp(3),
  },
  tagContainer: {
    alignSelf: 'flex-start',
    backgroundColor: '#E3F2FD',
    paddingHorizontal: wp(3),
    paddingVertical: hp(0.8),
    borderRadius: wp(10),
    marginTop: hp(0.5),
  },
  tagText: {
    fontSize: FSize.fs12,
    color: Colors.sooprsblue,
    fontWeight: '500',
  },
  metricsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: hp(2),
    gap: wp(2),
  },
  metricCard: {
    flex: 1,
    backgroundColor: Colors.white,
    borderRadius: wp(3),
    padding: wp(3),
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  metricLabel: {
    fontSize: FSize.fs12,
    color: Colors.gray,
    marginBottom: hp(0.5),
  },
  metricValueGreen: {
    fontSize: FSize.fs14,
    fontWeight: '600',
    color: '#4CAF50',
  },
  metricValueBlue: {
    fontSize: FSize.fs18,
    fontWeight: '700',
    color: Colors.sooprsblue,
  },
  metricValueBlack: {
    fontSize: FSize.fs14,
    fontWeight: '600',
    color: Colors.darkblack,
  },
  sectionTitle: {
    fontSize: FSize.fs18,
    fontWeight: '700',
    color: Colors.darkblack,
    marginBottom: hp(1.5),
  },
  descriptionText: {
    fontSize: FSize.fs14,
    color: Colors.gray,
    lineHeight: hp(2.5),
    marginBottom: hp(1.5),
  },
  requirementsList: {
    marginTop: hp(1),
    marginBottom: hp(1),
  },
  bulletItem: {
    flexDirection: 'row',
    marginBottom: hp(0.8),
    paddingRight: wp(2),
  },
  bullet: {
    fontSize: FSize.fs16,
    color: Colors.gray,
    marginRight: wp(2),
  },
  bulletText: {
    flex: 1,
    fontSize: FSize.fs14,
    color: Colors.gray,
    lineHeight: hp(2.2),
  },
  timelineText: {
    fontSize: FSize.fs14,
    color: Colors.gray,
    lineHeight: hp(2.5),
    marginTop: hp(1),
  },
  boldText: {
    fontWeight: '700',
  },
  metadataItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: hp(1.5),
  },
  metadataLabel: {
    flex: 1,
    fontSize: FSize.fs14,
    color: Colors.gray,
    marginLeft: wp(2),
  },
  metadataValue: {
    fontSize: FSize.fs14,
    fontWeight: '500',
    color: Colors.darkblack,
  },
  metadataValueBlue: {
    fontSize: FSize.fs14,
    fontWeight: '500',
    color: Colors.sooprsblue,
  },
  bottomButtonContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: Colors.white,
    paddingHorizontal: wp(5),
    paddingVertical: hp(2),
    paddingBottom: Platform.OS === 'ios' ? hp(3) : hp(2),
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: -2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  bottomButton: {
    backgroundColor: Colors.sooprsblue,
    borderRadius: wp(3),
    paddingVertical: hp(1.8),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: wp(2),
  },
  bottomButtonText: {
    color: Colors.white,
    fontSize: FSize.fs16,
    fontWeight: '700',
  },
});

