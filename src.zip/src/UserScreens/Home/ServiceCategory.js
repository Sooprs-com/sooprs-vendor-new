import {
  StyleSheet,
  Text,
  View,
  FlatList,
  Image,
  TouchableOpacity,
} from 'react-native';
import React from 'react';
import Images from '../../assets/image';
import Colors from '../../assets/commonCSS/Colors';
import FSize from '../../assets/commonCSS/FSize';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
const iconSize = Math.min(wp(8), hp(5));
const ServiceCategory = ({navigation}) => {
  const data = [
    {
      label: 'Website Development',
      color: "#DBE9FF",
      value: 1,
      catId: 93,
      img: Images.websideDevelopment,
    },
    {
      label: 'Mobile App Development',
      color: "#FFDDD7",
      value: 2,
      catId: 42,
      img: Images.mobileAppDevelopment,
    },
    {
      label: 'Digital Marketing',
      color: "#FFDFB8",
      value: 3,
      catId: 95,
      img: Images.digitalMarketing,
    },
    {
      label: 'UI/UX Designing',
      color: "#ECDEFF",
      value: 4,
      catId: 5,
      img: Images.uiUxDesigning,
    },
    {
      label: 'Video Editing',
      color: "#FFF5CF",
      value: 5,
      catId: 24,
      img: Images.videoEditing,
    },
    {
      label: 'Artificial Intelligence',
      color: "#D1FFF4",
      value: 6,
      catId: 25,
      img: Images.artificialIntelligence,
    },
    {
      label: 'Packers & Movers',
      color: "#FFF2CF",
      value: 11,
      catId: 50,
      img: Images.packersAndMovers,
    },
    {
      label: 'Corporate Events',
      color: "#CBECED",
      value: 9,
      catId: 99,
      img: Images.corporateEvents,
    },

    // -------------------------

    {
    label: 'Healing & Wellness',
     color: "#FFDBD5",
    value: 9,
    catId: 99,
    img: Images.healingWellness,
  },

  {
    label: 'Real Estate',
     color: "#FFEBD2",
    value: 9,
    catId: 99,
    img: Images.realEstate,
  },

  {
    label: 'Business Counselling',
     color: "#DFF7FF",
    value: 9,
    catId: 99,
    img: Images.businessCounselling,
  },

  {
    label: 'Dentist, Ent, Dermatologist',
     color: "#FFDDDF",
    value: 9,
    catId: 99,
    img: Images.dentistEntDermatologist,
  },


  ];
  const handleNavigation = (screenName, params = {}) => {
    navigation.navigate('ClientBottomTab', {screen: screenName, params});
  };
  const renderItem = ({item}) => {
    const catId = item?.catId;
    return (
      <TouchableOpacity
        style={[styles.itemContainer,]}
        activeOpacity={0.8}
        onPress={() => handleNavigation('Professionals', {item})}>
        <View style={[styles.imgContainer, {backgroundColor: item.color}]}>
          <Image
            source={item.img}
            style={styles.itemImage}
            resizeMode="contain"
          />
        </View>

        <Text style={styles.itemLabel}>{item.label}</Text>
      </TouchableOpacity>
    );
  };
  return (
    <View>
      <Text style={styles.headingText}>Service Categories</Text>
      <FlatList
        data={data}
        renderItem={renderItem}
        keyExtractor={item => item.value.toString()}
        numColumns={4} // Display 4 items per row
        contentContainerStyle={styles.listContainer}
        columnWrapperStyle={styles.row} // Style for rows
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
};

export default ServiceCategory;

const styles = StyleSheet.create({
  headingText: {
    paddingHorizontal: wp(4),
    paddingVertical: hp(1),
    color: Colors.black,
    fontWeight: '600',
    fontSize: FSize.fs20,
  },
  listContainer: {
    paddingHorizontal: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  row: {
    justifyContent: 'space-between', // Distribute items evenly
    paddingHorizontal: wp(0.5),
  },
  itemContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: 10,
    width: wp(22), // Ensure consistent width
  },
  itemImage: {
    height: iconSize,
    width: iconSize,
  },
  itemLabel: {
    textAlign: 'center',
    color: Colors.black,
    fontSize: FSize.fs12,
  },
  imgContainer: {
    backgroundColor: '#f5f5f5',
    height: iconSize * 2,
    width: iconSize * 2,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
  },
});
