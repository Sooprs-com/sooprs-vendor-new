import {
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import Colors from '../../assets/commonCSS/Colors';
import FSize from '../../assets/commonCSS/FSize';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import Images from '../../assets/image';
const imgSize = Math.min(wp(23), hp(12));
const ProfessionalsSlider = ({professionals = [], navigation}) => {
  const handleNavigation = (screenName, params = {}) => {
    navigation.navigate(screenName, params);
  };
  const renderItmes = ({item, index}) => {
    const name = item?.data?.name?.split(' ')[0];
    const img = item?.data?.image;
    const designatin = item?.services && item?.services[0];
    const slug = item?.data?.slug;
    const id = item?.data?.id;
    return (
      <TouchableOpacity
        style={styles.itemContainer}
        activeOpacity={0.8}
        onPress={() => handleNavigation('ProfessionalProfile', {id, slug})}>
        <Image
          source={{uri: img}}
          style={{height: imgSize, width: imgSize, borderRadius: imgSize / 2}}
        />
        <Text style={styles.name}>{name}</Text>
        <Text style={styles.desigantion}>{designatin}</Text>
      </TouchableOpacity>
    );
  };
  return (
    <View style={{marginBottom: hp(0)}}>
      {/* <Text style={styles.headingText}>Top Professionals</Text> */}
      {/* <FlatList
        data={professionals}
        horizontal
        renderItem={renderItmes}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{paddingHorizontal: 16, alignItems: 'center'}}
        ListFooterComponent={
          <TouchableOpacity
            style={{alignSelf: 'center', alignItems: 'center'}}
            onPress={() =>
              navigation.navigate('ProfessionalsScreen')
            }>
            <Image
              source={Images.viewAll}
              style={{height: 40, width: 40}}
              resizeMode="contain"
            />
            <Text style={{color: '#444444', fontSize: FSize.fs13}}>
              View all
            </Text>
          </TouchableOpacity>
        }
      /> */}
    </View>
  );
};

export default ProfessionalsSlider;

const styles = StyleSheet.create({
  headingText: {
    padding: 16,
    color: Colors.black,
    fontWeight: '600',
    fontSize: FSize.fs20,
  },
  itemContainer: {
    justifyContent: 'center',
    alignItems: 'center',

    marginRight: 16,
  },
  name: {
    color: Colors.black,
    fontWeight: '500',
    fontSize: FSize.fs15,
  },
  desigantion: {
    color: '#444444',
    fontSize: FSize.fs12,
  },
});
