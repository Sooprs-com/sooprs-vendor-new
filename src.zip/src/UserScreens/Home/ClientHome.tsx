import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  FlatList,
  StatusBar,
  RefreshControl,
  ActivityIndicator,
  TextInput,
  Image,
} from 'react-native';
import React, {useCallback, useEffect, useState} from 'react';
import Header from '../../components/Header';
import Images from '../../assets/image';
import Colors from '../../assets/commonCSS/Colors';
import {wp, hp} from '../../assets/commonCSS/GlobalCSS';
import SearchBar from '../../components/SearchBar';
import Filter from '../../components/Filter';
import IntroCard from '../../components/IntroCard';
import ProfessionalList from '../../components/ProfessionalList';
import HomeSectionTitle from '../../components/HomeSectionTitle';
import GigsList from '../../components/GigsList';
import FSize from '../../assets/commonCSS/FSize';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {useIsFocused} from '@react-navigation/native';
import {mobile_siteConfig} from '../../services/mobile-siteConfig';
import Carousel from '../../components/Carousel';
import ProfessionalsSlider from './ProfessionalsSlider';
import ServiceCategory from './ServiceCategory';
import GigsCategory from './GigsCategory';
import {useGigApis} from '../Gigs/GigApis';
import {useSelector} from 'react-redux';

const Home = ({navigation}: {navigation: any}) => {
  const [name, setName] = useState('');
  const [profilePic, setProfilePic] = useState(null);
  const isFocused = useIsFocused();
  const [refreshing, setRefreshing] = useState(false);
  const [professionals, setProfessionals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const {getBrowseGigs} = useGigApis();
  const getUserDetails = useSelector(state => state?.getUserDetails);
  const currency = getUserDetails?.country == 'IN' ? 'INR' : 'USD';
  const [gigData, setGigData] = useState([]);

  // Static data for Trending Services
  const trendingServicesData = [
    {
      id: 1,
      image: Images.banner1,
      title: 'Interior Design',
      provider: 'by Decor Experts',
      rating: 4.9,
      reviews: 150,
    },
    {
      id: 2,
      image: Images.banner2,
      title: 'Premium Moving',
      provider: 'by Safe Transport',
      rating: 4.8,
      reviews: 210,
    },
    {
      id: 3,
      image: Images.banner3,
      title: 'Home Cleaning',
      provider: 'by Clean Masters',
      rating: 4.7,
      reviews: 320,
    },
    {
      id: 4,
      image: Images.banner4,
      title: 'Plumbing Services',
      provider: 'by Fix It Fast',
      rating: 4.9,
      reviews: 180,
    },
    {
      id: 5,
      image: Images.banner1,
      title: 'Electrical Work',
      provider: 'by Power Solutions',
      rating: 4.6,
      reviews: 145,
    },
  ];

  const renderTrendingService = ({item}: {item: any}) => (
    <TouchableOpacity style={styles.serviceCard}>
      <Image source={item.image} style={styles.serviceImage} resizeMode="cover" />
      <View style={styles.serviceCardContent}>
        <Text style={styles.serviceTitle}>{item.title}</Text>
        <Text style={styles.serviceProvider}>{item.provider}</Text>
        <View style={styles.serviceRating}>
          <Image source={Images.starIcon} style={styles.starIcon} />
          <Text style={styles.ratingText}>{item.rating}</Text>
          <Text style={styles.reviewsText}>({item.reviews}+ Reviews)</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
  useEffect(() => {
    const fetchData = async () => {
      await getNameAndImage();
      await getProfessionals();
      await getData();
    };
    fetchData();
  }, [isFocused]);

  const getProfessionals = async () => {
    setLoading(true);
    try {
      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/filter_service_ajax',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
        },
      );
      const res = await response.json();
      if (res.status === 200) {
        // console.log('professional data:::::', res.msg);
        setProfessionals(res.msg?.slice(0, 10)); // Update the state with fetched data
      } else {
        console.error('Failed to fetch professionals:', res.message);
      }
    } catch (error) {
      console.error('Error fetching professionals:', error);
    } finally {
      setLoading(false);
    }
  };

  const getNameAndImage = async () => {
    try {
      const name = await AsyncStorage.getItem(mobile_siteConfig.NAME);
      const profilepic = await AsyncStorage.getItem(
        mobile_siteConfig.PROFILE_PIC,
      );

      const parsedName = JSON.parse(name);
      const parsedprofilepic = JSON.parse(profilepic);
      if (name !== null) {
        setName(parsedName ?? '');
      }
      setProfilePic(parsedprofilepic);
    } catch (e) {
      console.log('Error retrieving profile details:', e);
    }
  };

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    getProfessionals(); // Fetch professionals when refreshing
    setRefreshing(false); // Set refreshing to false after fetching
  }, []);

  const getData = async () => {
    try {
      const payload = new FormData();
      payload.append('offset', 0);
      payload.append('limit', 10);
      payload.append('cur', currency);
      const res = await getBrowseGigs(payload);
      setGigData(res);
    } catch (error) {
      console.error('Error fetching gigs:', error);
    }
  };
  // if (loading)
  //   return (
  //     <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
  //       <ActivityIndicator color={Colors.sooprsblue} size={35} />
  //     </View>
  //   );
  return (
    <View style={styles.container}>
      <Header
        navigation={navigation}
        img={profilePic}
        name={name || 'User'}
        btnName="Post a project"
        isClient={true}
      />
      
      {/* Search Container */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBar}>
          <Image
            source={Images.searchIcon}
            resizeMode="contain"
            style={styles.searchIcon}
          />
          <TextInput
            style={styles.searchInput}
            placeholder="Search Services, Cabs, Vendors..."
            placeholderTextColor="#999999"
            onFocus={() => {
              // Navigate to search screen or handle search
              navigation.navigate('ProfessionalsScreen');
            }}
          />
        </View>
      </View>
      
      <ScrollView
        style={styles.container}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }>
       
        <View>
          <ProfessionalsSlider
            professionals={professionals}
            navigation={navigation}
          />
          <ServiceCategory navigation={navigation} />

          <Carousel 
          carouselData={[
            {id: 1, image: Images.banner1},
            {id: 2, image: Images.banner2},
            {id: 3, image: Images.banner3},
            {id: 4, image: Images.banner4},
            ]}/>


          {/* Trending Services Section */}
          <View style={styles.trendingSection}>
            <View style={styles.trendingHeader}>
              <Text style={styles.trendingTitle}>Trending Services</Text>
              <TouchableOpacity>
                <Text style={styles.seeAllText}>See All</Text>
              </TouchableOpacity>
            </View>
            <FlatList
              data={trendingServicesData}
              renderItem={renderTrendingService}
              keyExtractor={(item, index) => index.toString()}
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.trendingList}
            />
          </View>

          {/* Invite & Earn Card */}
          <View style={styles.inviteCardContainer}>
            <TouchableOpacity 
              style={styles.inviteCard}
              onPress={() => {
                // Handle invite action
                // navigation.navigate('InviteScreen');
              }}>
              <View style={styles.inviteCardContent}>
                <Text style={styles.inviteCardTitle}>Invite & Earn</Text>
                <Text style={styles.inviteCardDescription}>
                  Get ₹100 wallet cash for every friend you invite.
                </Text>
              </View>
              <View style={styles.inviteButton}>
                <Image 
                  source={Images.rigthArrowIcon} 
                  style={styles.inviteArrowIcon}
                  resizeMode="contain"
                />
              </View>
            </TouchableOpacity>
          </View>

          {/* <GigsCategory
            data={gigData}
            navigation={navigation}
            currency={currency}
          /> */}
        </View>
      </ScrollView>
    </View>
  );
};

export default Home;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },

  section: {
    marginHorizontal: wp(5),
    marginVertical: hp(2),
  },
  homeInfo: {
    color: Colors.black,
    fontWeight: '600',
    fontSize: FSize.fs19,
  },

  textAlign: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: hp(3),
  },

  profText: {
    color: Colors.sooprsblue,
  },

  searchFilter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },

  loadingText: {
    textAlign: 'center',
    fontSize: FSize.fs16,
    color: Colors.gray,
    fontWeight: '500',
    marginVertical: hp(2), // Adjust margin for better spacing
  },
  searchContainer: {
    paddingHorizontal: wp(5),
    paddingTop: hp(0.3),
    paddingBottom: hp(0.3),
    backgroundColor: Colors.white,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    borderRadius: wp(3),
    paddingHorizontal: wp(4),
    height: hp(6),
    borderWidth: 1,
    borderColor: '#E0E0E0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  searchIcon: {
    width: wp(5),
    height: hp(2.5),
    tintColor: '#666666',
    marginRight: wp(3),
  },
  searchInput: {
    flex: 1,
    fontSize: FSize.fs14,
    color: Colors.black,
    paddingVertical: 0,
  },
  trendingSection: {
    marginTop: hp(2),
    marginBottom: hp(2),
  },
  trendingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: wp(5),
    marginBottom: hp(1.5),
  },
  trendingTitle: {
    fontSize: FSize.fs19,
    fontWeight: '700',
    color: Colors.darkblack,
  },
  seeAllText: {
    fontSize: FSize.fs14,
    color: Colors.sooprsblue,
    fontWeight: '500',
  },
  trendingList: {
    paddingLeft: wp(5),
    paddingRight: wp(2),
  },
  serviceCard: {
    width: wp(75),
    marginRight: wp(3),
    backgroundColor: Colors.white,
    borderRadius: wp(3),
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  serviceImage: {
    width: '100%',
    height: hp(20),
    borderTopLeftRadius: wp(3),
    borderTopRightRadius: wp(3),
  },
  serviceCardContent: {
    padding: wp(3),
  },
  serviceTitle: {
    fontSize: FSize.fs16,
    fontWeight: '700',
    color: Colors.darkblack,
    marginBottom: hp(0.5),
  },
  serviceProvider: {
    fontSize: FSize.fs12,
    color: Colors.gray,
    marginBottom: hp(0.8),
  },
  serviceRating: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  starIcon: {
    width: wp(4),
    height: wp(4),
    marginRight: wp(1),
    tintColor: '#FFD700',
  },
  ratingText: {
    fontSize: FSize.fs14,
    fontWeight: '600',
    color: Colors.darkblack,
    marginRight: wp(1),
  },
  reviewsText: {
    fontSize: FSize.fs12,
    color: Colors.gray,
  },
  inviteCardContainer: {
    paddingHorizontal: wp(5),
    marginTop: hp(2),
    marginBottom: hp(1),
  },
  inviteCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#E8F0F8',
    borderRadius: wp(4),
    paddingHorizontal: wp(4),
    paddingVertical: hp(2),

    // shadowColor: '#000',
    // shadowOffset: {
    //   width: 0,
    //   height: 2,
    // },
    // shadowOpacity: 0.1,
    // shadowRadius: 4,
    // elevation: 3,
    
  },
  inviteCardContent: {
    flex: 1,
    marginRight: wp(3),
  },
  inviteCardTitle: {
    fontSize: FSize.fs18,
    fontWeight: '700',
    color: '#2C3E50',
    marginBottom: hp(0.5),
  },
  inviteCardDescription: {
    fontSize: FSize.fs14,
    color: '#7F8C8D',
    fontWeight: '400',
    lineHeight: hp(2.2),
  },
  inviteButton: {
    width: wp(12),
    height: wp(12),
    borderRadius: wp(6),
    backgroundColor: Colors.sooprsblue,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: Colors.sooprsblue,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  inviteArrowIcon: {
    width: wp(5),
    height: wp(5),
    tintColor: Colors.white,
  },
});
