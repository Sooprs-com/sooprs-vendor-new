import {
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import Colors from '../../assets/commonCSS/Colors';
import FSize from '../../assets/commonCSS/FSize';
import GigCards from '../Gigs/GigCards';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import Images from '../../assets/image';

const GigsCategory = ({data = [], navigation, currency}) => {
  const handleNavigation = (screenName, params = {}) => {
    navigation.navigate('ProfessionalStack', {screen: screenName, params});
  };
  const symbol = () => {
    const symbol = currency == 'INR' ? '₹' : '$';
    return `${symbol}`;
  };
  const renderItem = ({item, index}) => {
    const professionalId = item?.professional?.id;
    const source = `https://sooprs.com/assets/files/${item?.gig_img}`;
    return (
      <TouchableOpacity
        style={styles.card}
        onPress={() => handleNavigation('GigDetails', {item, professionalId})}>
        <Image
          source={{uri: source}}
          style={{width: '100%', height: hp(18)}}
          resizeMode="stretch"
        />

        <Text style={styles.titleText}>{item?.gig_title}</Text>
        <View style={styles.ratingContainer}>
          <Image
            source={Images.star}
            style={{height: 15, width: 15, marginRight: 8}}
            resizeMode="contain"
          />
          <Text
            style={{color: 'gold', fontSize: FSize.fs16, fontWeight: '500'}}>
            {item?.gig_rating ?? 0}
          </Text>
        </View>
        <Text style={[styles.titleText, {color: Colors.sooprsblue}]}>
          {symbol()} {item?.gig_price}
        </Text>
      </TouchableOpacity>
    );
  };
  return (
    <View style={{}}>
      <View style={styles.headerContainer}>
        <Text style={styles.headingText}>Exlpore gigs</Text>
        <Text
          style={styles.viewText}
          onPress={() =>
            navigation.navigate('ClientBottomTab', {screen: 'Gig'})
          }>
          View all
        </Text>
      </View>
      <View>
        <FlatList
          data={data}
          horizontal
          showsHorizontalScrollIndicator={false}
          showsVerticalScrollIndicator={false}
          renderItem={renderItem}
          contentContainerStyle={{padding: 16, paddingBottom: hp(5)}}
        />
      </View>
    </View>
  );
};

export default GigsCategory;

const styles = StyleSheet.create({
  headingText: {
    color: Colors.black,
    fontWeight: '600',
    fontSize: FSize.fs20,
  },
  card: {
    width: wp(70),
    marginRight: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 12,
    overflow: 'hidden',
  },
  titleText: {
    color: Colors.black,
    fontSize: FSize.fs16,
    fontWeight: '500',
    padding: 8,
  },
  ratingContainer: {
    paddingHorizontal: 8,
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 16,
    marginVertical: 8,
    alignItems: 'center',
  },
  viewText: {
    color: Colors.gray,
    textDecorationLine: 'underline',
    fontWeight: '500',
    fontSize: FSize.fs15,
  },
});
