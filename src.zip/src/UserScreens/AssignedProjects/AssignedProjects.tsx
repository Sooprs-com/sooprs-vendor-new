import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Image,
  FlatList,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import React, {useEffect, useState, useCallback} from 'react';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import Images from '../../assets/image';
import Colors from '../../assets/commonCSS/Colors';
import FSize from '../../assets/commonCSS/FSize';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {useIsFocused, useNavigation} from '@react-navigation/native';
import ProjectCard from '../../components/ProjectCard';
import {useSelector} from 'react-redux';
import NewProjectCard from '../../components/NewProjectCard';

const AssignedProjects = ({navigation: navigationProp}: {navigation?: any}) => {
  const navigation = useNavigation();
  const nav = navigationProp || navigation;
  const [assignedProjects, setAssignedProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false); // State for pull-to-refresh
  const getUserId = useSelector(state => state?.getUserId);
  const isFocused = useIsFocused();
  const getUserDetails = useSelector(state => state?.getUserDetails);
  const currency = getUserDetails?.country == 'IN' ? 'INR' : 'USD';
  useEffect(() => {
    getAssignedProjects();
  }, [isFocused]);
  const getAssignedProjects = async () => {
    try {
      const formdata = new FormData();
      formdata.append('variable', getUserId);
      formdata.append('cur', currency);
      const response = await fetch(
        'https://sooprs.com/api2/public/index.php/get_projects_ajax',
        {
          method: 'POST',
          body: formdata,
          headers: {},
        },
      );
      const responseData = await response.json();
      if (responseData.status === 200) {
        setAssignedProjects(responseData.msg || []);
      } else if (responseData.status === 400) {
        console.error('An error has occurred!');
        setAssignedProjects([]);
      }
    } catch (error) {
      console.error('Error fetching projects:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Refresh handler for pull-to-refresh
  const onRefresh = useCallback(() => {
    setRefreshing(true);
    getAssignedProjects();
  }, []);
  const handleCardPress = item => {
    nav.navigate('IndividualChat', {
      name: item?.other?.name,
      cust_image: item?.other?.image,
      userId: getUserId,
      leadId: item?.id,
      bidId: item?.myLeadId,
      recieverId: item?.customer_id,
      id: item?.id,
      project_status: item?.project_status,
    });
  };
  if (loading) return <ActivityIndicator color={Colors.sooprsblue} />;
  return (
    <View style={styles.projectsList}>
      <FlatList
        data={assignedProjects}
        renderItem={({item, index}) => (
          <NewProjectCard
            index={index}
            item={item}
            hideBidCount
            hidePostedDate
            currency={currency}
            onCardPress={() => handleCardPress(item)}
          />
        )}
        keyExtractor={(item, index) => index.toString()}
        showsHorizontalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={[Colors.sooprsblue]}
          />
        }
        ListEmptyComponent={
          <Image
            source={Images.emptyChat}
            style={styles.emptyList}
            resizeMode="contain"
          />
        }
      />
    </View>
  );
};

export default AssignedProjects;

const styles = StyleSheet.create({
  projectsList: {
    flex: 1,
    backgroundColor: Colors.white,
    alignItems: 'center',
  },
  message: {
    fontSize: 18,
    color: Colors.black,
    textAlign: 'center',
    marginTop: wp(10),
  },
  emptyList: {
    height: hp(40),
    width: wp(65),
    alignSelf: 'center',
    marginTop: hp(10),
  },
});
