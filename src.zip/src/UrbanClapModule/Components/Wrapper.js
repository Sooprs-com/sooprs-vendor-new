import { StatusBar, StyleSheet, Text, View } from 'react-native'
import React  from 'react'
import Colors from '../../assets/commonCSS/Colors'

const Wrapper = ({Children}) => {
  return (
    <View style={styles.container}>
        <StatusBar backgroundColor={Colors.white} barStyle={'dark-content'}/>
      {Children}
    </View>
  )
}

export default Wrapper

const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:Colors.white
    }
})