import React, {useState, useEffect} from 'react';
import {TextInput, View, StyleSheet, Image} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  runOnJS,
} from 'react-native-reanimated';
import Colors from '../../assets/commonCSS/Colors';
import UCIcons from '../Utilities/UCIcons';
import FSize from '../../assets/commonCSS/FSize';
import { hp, wp } from '../../assets/commonCSS/GlobalCSS';

const placeholderTexts = [
  'Search here...',
  'Find anything...',
  'Type to explore...',
];

const AnimatedSearchBar = () => {
  const [index, setIndex] = useState(0);
  const opacity = useSharedValue(1);

  const updateIndex = () => {
    setIndex(prevIndex => (prevIndex + 1) % placeholderTexts.length);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      opacity.value = withTiming(0, {duration: 500}, () => {
        runOnJS(updateIndex)();
        opacity.value = withTiming(1, {duration: 500});
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
  }));

  return (
    <View style={styles.container}>
      <TextInput style={styles.input} placeholder={' '} />
      <View style={styles.searchContainer}>
        <Image
          source={UCIcons.search}
          style={{height: 18, width: 18, marginRight: 10}}
        />
        <Animated.Text style={[styles.placeholder, animatedStyle]}>
          {placeholderTexts[index]}
        </Animated.Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: wp(90),
    alignSelf: 'center',
    position: 'relative',
  },
  input: {
    borderWidth: 1.5,
    height:hp(6),
    borderColor: Colors.grey,
    borderRadius: 10,
    paddingLeft: 15,
    fontSize: FSize.fs17,
    zIndex: 999,
  },
  placeholder: {
    fontSize: 16,
    color: Colors.grey,
  },
  searchContainer: {
    position: 'absolute',
    left: 15,
    top: 15,
    flexDirection: 'row',
    alignItems: 'center',
  },
});

export default AnimatedSearchBar;
