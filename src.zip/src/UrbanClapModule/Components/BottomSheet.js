import React from 'react';
import {TouchableOpacity, StyleSheet, View, Image} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  useDerivedValue,
  withDelay,
  withTiming,
} from 'react-native-reanimated';
import Images from '../../assets/image';
import Colors from '../../assets/commonCSS/Colors';
import {hp} from '../../assets/commonCSS/GlobalCSS';

const BottomSheet = ({isOpen, toggleSheet, duration = 500, children}) => {
  const height = useSharedValue(0);
  const progress = useDerivedValue(() =>
    withTiming(isOpen.value ? 0 : 1, {duration}),
  );

  const sheetStyle = useAnimatedStyle(() => ({
    transform: [{translateY: progress.value * 2 * height.value}],
  }));

  const backdropStyle = useAnimatedStyle(() => ({
    opacity: 1 - progress.value,
    zIndex: isOpen.value
      ? 1
      : withDelay(duration, withTiming(-1, {duration: 0})),
  }));

  return (
    <>
      {/* Backdrop Layer */}
      <Animated.View style={[sheetStyles.backdrop, backdropStyle]}>
        <TouchableOpacity
          style={StyleSheet.absoluteFill}
          onPress={() => (isOpen.value = false)}
          activeOpacity={1}
        />
      </Animated.View>

      {/* Bottom Sheet */}
      <Animated.View
        onLayout={e => {
          height.value = e.nativeEvent.layout.height;
        }}
        style={[sheetStyles.sheet, sheetStyle]}>
        {/* Close button above content */}
        <TouchableOpacity
          onPress={() => (isOpen.value = false)}
          style={sheetStyles.closeButton}>
          <Image
            source={Images.crossIcon}
            style={sheetStyles.closeIcon}
            tintColor={Colors.black}
          />
        </TouchableOpacity>

        {/* Content container (non-touchable) */}
        <View style={sheetStyles.contentContainer}>{children}</View>
      </Animated.View>
    </>
  );
};

const sheetStyles = StyleSheet.create({
  sheet: {
    paddingVertical: 16,
    maxHeight: hp(80),
    width: '100%',
    position: 'absolute',
    bottom: 0,
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
    zIndex: 999,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
  },
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    zIndex: -999,
    justifyContent: 'flex-end',
  },
  closeButton: {
    position: 'absolute',
    top: -40,
    right: 10,
    zIndex: 1000,
    backgroundColor: Colors.white,
    borderRadius: 100,
  },
  closeIcon: {
    height: 28,
    width: 28,
  },
  contentContainer: {
    width: '100%',
    marginTop: 10, // Provide spacing below the close button
  },
});

export default BottomSheet;
