import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import {hp, wp} from '../../assets/commonCSS/GlobalCSS';
import Images from '../../assets/image';
import Colors from '../../assets/commonCSS/Colors';
import FSize from '../../assets/commonCSS/FSize';
import {useNavigation} from '@react-navigation/native';

const UCHeaderComponent = ({header = 'backButton', hideBackButton}) => {
  const navigation = useNavigation();
  return (
    <View style={styles.container}>
      {!hideBackButton && (
        <TouchableOpacity
          activeOpacity={0.7}
          onPress={() => navigation.goBack()}>
          <Image
            source={Images.backArrow}
            style={{height: 25, width: 25, marginRight: 10}}
          />
        </TouchableOpacity>
      )}
      <Text style={styles.t1}>{header}</Text>
    </View>
  );
};

export default UCHeaderComponent;

const styles = StyleSheet.create({
  container: {
    width: wp(100),
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'center',
    paddingVertical: 8,
    paddingHorizontal: 10,
    backgroundColor: Colors.white,
  },
  t1: {color: Colors.black, fontWeight: '500', fontSize: FSize.fs16},
});
