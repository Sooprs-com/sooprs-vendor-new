export default {
  home: require('../Icons/mage_home.png'),
  cart: require('../Icons/uccart.png'),
  orders: require('../Icons/ucorders.png'),
  account: require('../Icons/ucprofile.png'),
  notifi: require('../Icons/notifi.png'),
  backIcone: require('../Icons/BackIcone.png'),
  priceIcone: require('../Icons/PriceIcone.png'),
  crossIcone: require('../Icons/UCclose.png'),
  checkIcone: require('../Icons/CheckIcone.png'),
  pin: require('../Icons/pin.png'),
  currentLocation: require('../Icons/currentLocation.png'),
  recent: require('../Icons/recent.png'),
  search: require('../Icons/search1.png'),
  banner: require('../Icons/banner.png'),
  pen: require('../Icons/pen1.png'),
  checkMark:require('../Icons/check.png')
};
