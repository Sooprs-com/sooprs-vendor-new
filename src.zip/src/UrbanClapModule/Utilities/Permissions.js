import {
  PermissionsAndroid,
  Platform,
  Alert,
  Linking,
  AppState,
} from 'react-native';

export const requestLocationPermission = () => {
  return new Promise(async (resolve, reject) => {
    if (Platform.OS !== 'android') {
      resolve(true);
      return;
    }
    try {
      const granted = await PermissionsAndroid.check(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
      );

      if (granted) {
        console.log('Location permission already granted');
        resolve(true);
        return;
      }
      const response = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
      );

      if (response === PermissionsAndroid.RESULTS.GRANTED) {
        console.log('Location permission granted');
        resolve(true);
      } else if (response === PermissionsAndroid.RESULTS.DENIED) {
        console.log('Location permission denied');
        showPermissionAlert(resolve, reject);
      } else if (response === PermissionsAndroid.RESULTS.NEVER_ASK_AGAIN) {
        console.log('Location permission permanently denied');
        showPermissionAlert(resolve, reject);
      }
    } catch (error) {
      console.error('Error requesting location permission:', error);
      reject(error);
    }
  });
};

// Alert function to wait for user interaction
const showPermissionAlert = (resolve, reject) => {
  Alert.alert(
    'Permission Required',
    'This app needs location permission to function properly.',
    [
      {
        text: 'Open Settings',
        onPress: async () => {
          Linking.openSettings();
          const granted = await PermissionsAndroid.check(
            PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          );
          granted ? resolve(true) : reject(false);
        },
      },
    ],
  );
};
