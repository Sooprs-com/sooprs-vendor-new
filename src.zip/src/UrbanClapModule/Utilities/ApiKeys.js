export const GOOGLE_API_KEY = 'AIzaSyAhKwm-YMNb8LAAgd6qoOJFpoV6FH6hlaQ';
export const IMAGES_BASEURL = 'http://sooprs.com:3004';
export const END_POINTS = {
  BUSSINESS_SERVICES: 'user/get-all-services',
  CART_ITEMS: 'user/cart',
  ADD_TO_CART: 'user/add-to-cart',
  REMOVE_FROM_CART: 'user/remove-from-cart',
  AVAILABLE_SLOTS: 'user/get-time-slots',
  CREATE_ORDER: 'user/create-order',
  VERIFY_ORDER: 'user/verify-payment',
  PLACE_ORDER: 'user/create-user-order',
  CLEAR_CART: 'user/clear-cart',
  GET_ORDERS: 'user/all-orders',
  PRODUCT_SUB_CAT:'user/sub-sub-categories',
  PRODUCT_DETAILS:'user/product'
};
