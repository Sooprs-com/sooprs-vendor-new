import axios from 'axios';
import {getDataFromAsyncStorage} from '../../services/CommonFunction';
import {mobile_siteConfig} from '../../services/mobile-siteConfig';

export const BASE_URL = 'http://103.189.172.154:3004/api/';

const apiClient = axios.create({
  baseURL: BASE_URL,
});

export const post = async (URL, data, headers = {}) => {
  try {
    const response = await apiClient.post(URL, data, {
      headers: {'Content-Type': 'application/json', ...headers},
    });
    return response.data;
  } catch (error) {
    console.error('POST Error:', error?.response?.data || error.message);
    throw error?.response?.data || error;
  }
};

export const get = async (URL, headers = {}) => {
  try {
    const response = await apiClient.get(URL, {headers});
    return response.data;
  } catch (error) {
    console.error('GET Error:', error?.response?.data || error.message);
    throw error?.response?.data || error;
  }
};

export const getTokenData = async (URL, token) => {
  try {
    const response = await axios.get(URL, {
      headers: {
        'Content-Type': 'application/json',
        Origin: 'localhost',
        Authorization: `Bearer ${token}`,
      },
    });

    return response;
  } catch (error) {
    console.error('Failed to fetch data', error);
    throw error;
  }
};
