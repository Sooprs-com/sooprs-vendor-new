import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const UCAccount = () => {
  return (
    <View>
      <Text>UCAccount</Text>
    </View>
  )
}

export default UCAccount

const styles = StyleSheet.create({})