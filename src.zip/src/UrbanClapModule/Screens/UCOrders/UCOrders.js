import React, {useEffect, useState} from 'react';
import {StyleSheet, Text, View, FlatList, Image} from 'react-native';
import Colors from '../../../assets/commonCSS/Colors';
import {IMAGES_BASEURL} from '../../Utilities/ApiKeys';
import UCHeaderComponent from '../../Components/UCHeaderComponent';
import {wp} from '../../../assets/commonCSS/GlobalCSS';
import {useCartApis} from '../UCCart/UCCartHooks';
import {useIsFocused} from '@react-navigation/native';
import { getDataFromAsyncStorage } from '../../../services/CommonFunction';
import { mobile_siteConfig } from '../../../services/mobile-siteConfig';

const UCOrders = () => {
  const {getAllOders} = useCartApis(); // Ensure this hook is imported from your UCCartHooks
  const [orders, setOrders] = useState([]);
  const isFocused = useIsFocused();
  const [token,setToken]=useState()

    const getToken=async()=>{
        const token=await getDataFromAsyncStorage(mobile_siteConfig.TOKEN)
        setToken(token)
      }
    
      useEffect(()=>{
        getToken()
      },[])


  useEffect(() => {
    if (token) {
      fetchOrders();
    }
  }, [token,isFocused]);

  const fetchOrders = async () => {
    const response = await getAllOders(token);
    if (response?.success) {
      setOrders(response.data);
      console.log('res',response.data)
    }
  };
  // Render individual product item within an order
  const renderProduct = ({item}) => {
    return (
      <View style={styles.productContainer}>
        {item.image && (
          <Image
            source={{uri: IMAGES_BASEURL + item.image}}
            style={styles.productImage}
            resizeMode="contain"
          />
        )}
        <Text style={styles.productTitle} numberOfLines={2}>
          {item.title}
        </Text>
        <Text style={styles.productDetails}>
          ₹{item.price} x {item.quantity}
        </Text>
      </View>
    );
  };

  // Render order card containing header and products
  const renderOrderItem = ({item}) => {
    const orderDate = new Date(item.created_at);
    const formattedDate =
      orderDate.toLocaleDateString() + ' ' + orderDate.toLocaleTimeString();
    return (
      <View style={styles.orderCard}>
        <View style={styles.orderHeader}>
          <Text style={styles.orderId}>Order ID: {item.order_id}</Text>
          <Text style={styles.orderDate}>{formattedDate}</Text>
        </View>
        <FlatList
          data={item.products}
          keyExtractor={(product, index) =>
            product.product_id
              ? product.product_id.toString()
              : index.toString()
          }
          renderItem={renderProduct}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.productsList}
        />
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <UCHeaderComponent hideBackButton header="My Orders" />
      {orders.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No orders found.</Text>
        </View>
      ) : (
        <FlatList
          data={orders}
          keyExtractor={(item, index) => item.order_id + index.toString()}
          renderItem={renderOrderItem}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
};

export default UCOrders;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  listContainer: {
    padding: 16,
  },
  orderCard: {
    backgroundColor: Colors.white,
    borderRadius: 10,
    padding: 16,
    marginBottom: 16,
    elevation: 3, // Android shadow
    shadowColor: '#000', // iOS shadow
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.1,
    shadowRadius: 5,
  },
  orderHeader: {
    marginBottom: 12,
  },
  orderId: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.black,
    marginBottom: 4,
  },
  orderDate: {
    fontSize: 14,
    color: Colors.gray,
  },
  productsList: {
    paddingVertical: 4,
  },
  productContainer: {
    backgroundColor: Colors.lightgrey1,
    padding: 10,
    borderRadius: 8,
    marginRight: 8,
    width: wp(40),
    alignItems: 'center',
    justifyContent: 'center',
  },
  productImage: {
    width: 80,
    height: 80,
    marginBottom: 8,
  },
  productTitle: {
    fontSize: 14,
    color: Colors.black,
    textAlign: 'center',
    marginBottom: 4,
  },
  productDetails: {
    fontSize: 12,
    color: Colors.gray,
    textAlign: 'center',
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontSize: 18,
    color: Colors.gray,
  },
});
