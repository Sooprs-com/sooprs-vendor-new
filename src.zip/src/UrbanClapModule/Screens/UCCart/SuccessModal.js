import React from 'react';
import {View, Modal, StyleSheet, Image, TouchableOpacity} from 'react-native';
import {Text} from 'react-native-paper';
import Colors from '../../../assets/commonCSS/Colors';
import UCIcons from '../../Utilities/UCIcons';

const OrderSuccessModal = ({isVisible, onClose}) => {
  return (
    <Modal
      transparent
      visible={isVisible}
      animationType="fade"
      onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={styles.modalContainer}>
          {/* Success Checkmark */}
          <Image source={UCIcons.checkMark} style={styles.checkmark} />

          {/* Success Message */}
          <Text style={styles.title}>Order Successful!</Text>
          <Text style={styles.subtitle}>Your booking has been confirmed.</Text>

          {/* Continue Button */}
          <TouchableOpacity style={styles.button} onPress={onClose}>
            <Text style={styles.buttonText}>Continue</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

export default OrderSuccessModal;

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    backgroundColor: Colors.white,
    borderRadius: 15,
    padding: 20,
    alignItems: 'center',
    width: 300,
  },
  checkmark: {
    width: 80,
    height: 80,
    marginBottom: 15,
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
    color: Colors.black,
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 16,
    color: Colors.gray,
    textAlign: 'center',
    marginBottom: 20,
  },
  button: {
    backgroundColor: Colors.sooprsblue,
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
  },
  buttonText: {
    color: Colors.white,
    fontSize: 16,
    fontWeight: '600',
  },
});
