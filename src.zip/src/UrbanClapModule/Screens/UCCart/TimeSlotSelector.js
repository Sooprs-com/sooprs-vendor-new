import {useEffect, useState} from 'react';
import {ScrollView, StyleSheet, View} from 'react-native';
import {TouchableOpacity} from 'react-native-gesture-handler';
import {Text} from 'react-native-paper';
import Colors from '../../../assets/commonCSS/Colors';
import {wp} from '../../../assets/commonCSS/GlobalCSS';
import {useCartApis} from './UCCartHooks';

/**
 * TimeSlotSelector Component
 * Shows day tabs for [today, +1 day, +2 days] and displays
 * the given slots in 12-hour format, with selection states
 * controlled by the parent component via props.
 *
 * The "Pay Now" button is only enabled when a time slot is selected.
 */
const TimeSlotSelector = ({
  slots,
  selectedDayIndex,
  setSelectedDayIndex,
  selectedTimeSlot,
  setSelectedTimeSlot,
  slotId,
  onPayNow,
}) => {
  // We still generate the [today, +1, +2] days here locally
  const [days, setDays] = useState([]);
  useEffect(() => {
    // Generate [today, today+1, today+2]
    const today = new Date();
    const tempDays = [];
    for (let i = 0; i < 3; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() + i);
      const dayName = date.toLocaleString('default', {weekday: 'short'}); // e.g. 'Mon'
      const dayNum = date.getDate(); // e.g. 10
      tempDays.push({dayName, dayNum});
    }
    setDays(tempDays);
  }, []);

  // Convert 24-hour format (e.g. "14:00") to 12-hour format (e.g. "2:00 PM")
  const convert24To12 = time24 => {
    if (!time24) return '';
    const [hourStr, minuteStr] = time24.split(':');
    let hour = parseInt(hourStr, 10);
    const minute = parseInt(minuteStr || '0', 10);
    let suffix = 'AM';

    if (hour === 0) {
      hour = 12; // midnight is 12 AM
    } else if (hour === 12) {
      suffix = 'PM'; // noon is 12 PM
    } else if (hour > 12) {
      hour -= 12;
      suffix = 'PM';
    }

    const finalMinute = minute.toString().padStart(2, '0');
    return `${hour}:${finalMinute} ${suffix}`;
  };

  // Whether the "Pay Now" button should be enabled
  const isPayNowEnabled = !!selectedTimeSlot;

  return (
    <View style={{paddingHorizontal: 16, paddingBottom: 16}}>
      <Text style={styles.t5}>When should the professional arrive?</Text>

      {/* Days (Tabs) */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{marginVertical: 10}}>
        {days.map((day, index) => (
          <TouchableOpacity
            key={index}
            style={[
              styles.dayTab,
              selectedDayIndex === index && {
                backgroundColor: Colors.sooprslight,
              },
            ]}
            onPress={() => setSelectedDayIndex(index)}>
            <Text style={styles.dayTabText}>
              {`${day.dayName} ${day.dayNum}`}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Time Slots */}
      <View style={styles.slotContainer}>
        {slots?.length > 0 ? (
          slots.map((slot, idx) => {
            const convertedTime = convert24To12(slot?.slot_start_time);
            const isSelected = selectedTimeSlot === slot?.id;

            return (
              <TouchableOpacity
                key={idx}
                style={[
                  styles.slotButton,
                  isSelected && {backgroundColor: Colors.sooprslight},
                ]}
                onPress={() => {
                  setSelectedTimeSlot(slot?.id);
                }}>
                <Text style={styles.slotText}>{convertedTime}</Text>
              </TouchableOpacity>
            );
          })
        ) : (
          <Text style={{color: Colors.gray, marginTop: 10}}>
            No slots available
          </Text>
        )}
      </View>

      {/* Pay Now Button */}
      <View style={styles.payNowContainer}>
        <TouchableOpacity
          disabled={!isPayNowEnabled}
          style={[
            styles.payNowButton,
            !isPayNowEnabled && {backgroundColor: Colors.lightGrey},
          ]}
          activeOpacity={0.7}
          onPress={() => {
            if (isPayNowEnabled && onPayNow) {
              onPayNow();
            }
          }}>
          <Text style={styles.payNowButtonText}>Pay Now</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default TimeSlotSelector;

const styles = StyleSheet.create({
  t5: {
    color: Colors.black,
    textAlign: 'left',
    fontWeight: '500',
    fontSize: 15,
    marginBottom: 10,
  },
  dayTab: {
    backgroundColor: Colors.white,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    marginRight: 8,
    borderWidth: 0.4,
  },
  dayTabText: {
    color: Colors.black,
    fontSize: 14,
    fontWeight: '600',
  },
  slotContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  slotButton: {
    backgroundColor: Colors.white,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 8,
    margin: 4,
    borderWidth: 0.4,
  },
  slotText: {
    color: Colors.black,
    fontSize: 14,
    fontWeight: '500',
  },
  payNowContainer: {
    marginTop: 20,
    alignItems: 'center',
  },
  payNowButton: {
    backgroundColor: Colors.sooprsblue,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
    width: wp(90),
    justifyContent: 'center',
    alignItems: 'center',
  },
  payNowButtonText: {
    color: Colors.white,
    fontSize: 15,
    fontWeight: '600',
  },
});
