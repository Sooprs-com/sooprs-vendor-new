import {
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useRef, useState} from 'react';
import Colors from '../../../assets/commonCSS/Colors';
import {useCartApis} from './UCCartHooks';
import UCHeaderComponent from '../../Components/UCHeaderComponent';
import {useSelector} from 'react-redux';
import UCIcons from '../../Utilities/UCIcons';
import FSize from '../../../assets/commonCSS/FSize';
import {wp} from '../../../assets/commonCSS/GlobalCSS';
import BottomSheet from '../../Components/BottomSheet';
import {useSharedValue} from 'react-native-reanimated';
import TimeSlotSelector from './TimeSlotSelector';
import OrderSuccessModal from './SuccessModal';
import {useFocusEffect, useIsFocused} from '@react-navigation/native';
import { getDataFromAsyncStorage } from '../../../services/CommonFunction';
import { mobile_siteConfig } from '../../../services/mobile-siteConfig';

const UCCart = () => {
  const {
    getCartItems,
    addItemToCart,
    removeItemFromCart,
    getServiceTimeSlots,
    createOrder,
    sendToRazorPay,
    verifyOrder,
    placeOrder,
    clearCart,
  } = useCartApis();
  const [cartItems, setCartItems] = useState([]);
  const getUserAddress = useSelector(state => state?.getUserAddress);
  const isOpen = useSharedValue(false);
  const [slots, setSlots] = useState([]);
  const [selectedDayIndex, setSelectedDayIndex] = useState(0);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState(null);
  const {name, email, mobile} = useSelector(state => state?.getUserDetails);
  const cartId = useRef(null);
  const [successModalVisible, setSuccessModalVisible] = useState(false);
  const isFocused = useIsFocused();
  const [token,setToken]=useState()


   const getToken=async()=>{
      const token=await getDataFromAsyncStorage(mobile_siteConfig.TOKEN)
      setToken(token)
    }
  
    useEffect(()=>{
      getToken()
    },[])

  useEffect(() => {
    if (token) {
      getCart(token);
      getAvailableSlots();
    }
  },[token,isFocused]);
  // close the success modal
  const onClose = () => setSuccessModalVisible(false);
  const getCart = async (tokenData) => {
    const cartItems = await getCartItems(tokenData);
    setCartItems(cartItems.items);
    cartId.current = cartItems?.cartId;
  };

  // Add to cart
  const addItems = async itemId => {
    const res = await addItemToCart(itemId);
    if (res?.success) getCart(token);
  };

  // Remove from cart
  const removeItems = async itemId => {
    const res = await removeItemFromCart(itemId,token);
    console.log("responce of Data:::",res)
    if (res?.success) getCart(token);
  };
  // get slots
  const getAvailableSlots = async () => {
    const res = await getServiceTimeSlots();
    setSlots(res);
  };
  // create order

  // Calculate Subtotal
  const itemTotal = cartItems.reduce(
    (total, item) => total + item.quantity * item.price,
    0,
  );
  const taxesAndFee = 123;
  const total = itemTotal + taxesAndFee;
  const createPurchaseOrder = async () => {
    isOpen.value = false;
    try {
      const amountInPaise = total * 100;
      const orderId = await createOrder(amountInPaise);
      if (orderId.id) {
        const res = await sendToRazorPay(
          orderId.id,
          amountInPaise,
          email,
          mobile,
          name,
        );
        if (res?.razorpay_order_id) {
          const data = {
            razorpay_order_id: res.razorpay_order_id,
            razorpay_payment_id: res.razorpay_payment_id,
            razorpay_signature: res.razorpay_signature,
            amount: amountInPaise,
            currency: 'INR',
          };
          const verificationResponse = await verifyOrder(data);
          if (verificationResponse.success) {
            const verificationData = {
              time_slot_id: selectedTimeSlot,
              total_amount: (amountInPaise / 100).toFixed(2),
              payment_id: res.razorpay_payment_id,
              order_id: res.razorpay_order_id,
              date: selectedDayIndex,
              cart_id: cartId.current,
              address: getUserAddress,
            };
            const response = await placeOrder(verificationData);
            if (response.success) {
              await getCart(token);
              setSuccessModalVisible(true);
            }
          }
        }
      }
    } catch (error) {}
  };
  return (
    <View style={styles.container}>
      <UCHeaderComponent header={'Your cart'} hideBackButton />
      {cartItems.length < 1 ? (
        <View style={styles.container}>
          <Text style={{color: Colors.black, textAlign: 'center'}}>
            Nothing in cart
          </Text>
        </View>
      ) : (
        <>
          {/* Example banner for savings */}
          <View style={styles.savingsBanner}>
            <Text style={styles.savingsText}>Saving ₹200 on this order</Text>
          </View>

          <ScrollView contentContainerStyle={styles.scrollContainer}>
            {/* Product Listing */}
            {cartItems.map((item, index) => (
              <View style={styles.cartItemContainer} key={index}>
                <Text style={styles.itemTitle}>{item?.title}</Text>
                <View style={styles.quantityContainer}>
                  <TouchableOpacity
                    style={styles.quantityButton}
                    onPress={() => removeItems(item?.product_id)}>
                    <Text style={styles.buttonText}>-</Text>
                  </TouchableOpacity>
                  <Text style={styles.quantityText}>{item.quantity}</Text>
                  <TouchableOpacity
                    style={styles.quantityButton}
                    onPress={() => addItems(item.product_id)}>
                    <Text style={styles.buttonText}>+</Text>
                  </TouchableOpacity>
                </View>
                <Text style={styles.priceText}>{`₹${
                  item.quantity * item.price
                }`}</Text>
              </View>
            ))}

            {/* Payment Summary Section */}
            <View style={styles.paymentSummaryContainer}>
              <Text style={styles.paymentHeader}>Payment summary</Text>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryText}>Item total</Text>
                <Text style={styles.summaryText}>{`₹${itemTotal}`}</Text>
              </View>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryText}>Taxes and Fee</Text>
                <Text style={styles.summaryText}>{`₹${taxesAndFee}`}</Text>
              </View>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryText}>Total</Text>
                <Text style={styles.summaryText}>{`₹${total}`}</Text>
              </View>
            </View>
          </ScrollView>

          {/* Bottom Button */}
          <View style={styles.bottomButtonContainer}>
            <View style={styles.addressContainer}>
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <Image
                  source={UCIcons.pin}
                  style={{height: 22, width: 22, marginRight: 10}}
                />
                <Text style={styles.t4}>{getUserAddress}</Text>
              </View>
              <TouchableOpacity>
                <Image
                  source={UCIcons.pen}
                  style={{height: 20, width: 20}}
                  resizeMode="contain"
                />
              </TouchableOpacity>
            </View>
            <TouchableOpacity
              style={styles.slotButton}
              onPress={() => (isOpen.value = true)}>
              <Text style={styles.slotButtonText}>Select slot</Text>
            </TouchableOpacity>
          </View>
        </>
      )}
      <OrderSuccessModal isVisible={successModalVisible} onClose={onClose} />
      <BottomSheet isOpen={isOpen}>
        <TimeSlotSelector
          slots={slots}
          selectedDayIndex={selectedDayIndex}
          setSelectedDayIndex={setSelectedDayIndex}
          selectedTimeSlot={selectedTimeSlot}
          setSelectedTimeSlot={setSelectedTimeSlot}
          onPayNow={createPurchaseOrder}
        />
      </BottomSheet>
    </View>
  );
};

export default UCCart;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  savingsBanner: {
    backgroundColor: '#d7f3e3',
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  savingsText: {
    color: '#2e7d32',
    fontWeight: '600',
    fontSize: 14,
  },
  scrollContainer: {
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  cartItemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 15,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGrey,
  },
  itemTitle: {
    flex: 1,
    fontSize: 15,
    color: Colors.black,
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.lightGrey,
    borderRadius: 8,
    padding: 2,
    marginHorizontal: 10,
    backgroundColor: Colors.sooprslight,
  },
  quantityButton: {
    paddingHorizontal: 6,
  },
  quantityText: {
    marginHorizontal: 10,
    fontSize: 13,
    fontWeight: 'bold',
    color: Colors.black,
  },
  buttonText: {
    fontSize: 18,
    color: Colors.black,
  },
  priceText: {
    fontSize: 14,
    fontWeight: '400',
    color: Colors.black,
  },
  paymentSummaryContainer: {
    borderColor: Colors.lightGrey,
    backgroundColor: Colors.white,
  },
  paymentHeader: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.black,
    marginBottom: 10,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 5,
  },
  summaryText: {
    fontSize: 15,
    color: Colors.black,
  },
  // Tip Section
  tipContainer: {
    marginTop: 20,
    padding: 16,
    borderColor: Colors.lightGrey,
    borderRadius: 8,
    backgroundColor: Colors.white,
  },
  tipHeader: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 10,
    color: Colors.black,
  },
  tipOptions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tipButton: {
    backgroundColor: Colors.sooprslight,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    marginRight: 10,
  },
  tipButtonText: {
    color: Colors.black,
    fontWeight: '600',
  },
  // Cancellation
  cancellationContainer: {
    marginTop: 20,
    paddingHorizontal: 4,
  },
  cancellationText: {
    fontSize: 14,
    color: Colors.black,
    lineHeight: 20,
  },
  // Bottom Button
  bottomButtonContainer: {
    borderTopWidth: 1,
    borderTopColor: Colors.lightGrey,
    backgroundColor: Colors.white,
    paddingVertical: 16,
  },
  slotButton: {
    backgroundColor: Colors.sooprsblue,
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
    width: wp(95),
    alignSelf: 'center',
  },
  slotButtonText: {
    fontSize: 16,
    color: Colors.white,
    fontWeight: '600',
  },
  t4: {
    color: Colors.gray,
    fontWeight: '400',
    fontSize: FSize.fs15,
    width: '80%',
  },
  addressContainer: {
    flexDirection: 'row',
    marginBottom: 10,
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
  },
  t5: {
    color: Colors.black,
    textAlign: 'left',
    fontWeight: '500',
    fontSize: 15,
  },
});
