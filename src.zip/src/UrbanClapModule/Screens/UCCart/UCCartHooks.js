import {useEffect, useState} from 'react';
import {get, post} from '../../Utilities/Apis';
import {END_POINTS} from '../../Utilities/ApiKeys';
import {useSelector} from 'react-redux';
import RazorpayCheckout from 'react-native-razorpay';
import Toast from 'react-native-toast-message';
import { getDataFromAsyncStorage } from '../../../services/CommonFunction';
import { mobile_siteConfig } from '../../../services/mobile-siteConfig';
export const useCartApis = () => {
  const [loadingCart, setLoadingCart] = useState(false);
  const [addRemoveLoader, setAddRemoveLoader] = useState(false);
  const [purchaseLoading, setPurchaseLoading] = useState(false);
  const [getAuthToken,setAuthToken]=useState()
  // const getAuthToken = useSelector(state => state?.getAuthToken);

   const getToken=async()=>{
      const token=await getDataFromAsyncStorage(mobile_siteConfig.TOKEN)
      setAuthToken(token)
    }
  
    useEffect(()=>{
      getToken()
    },[])
  const getCartItems = async tokenData => {
    // console.log("Token Data::::",tokenData)
    try {
      const response = await get(END_POINTS.CART_ITEMS, {
        Authorization: `Bearer ${tokenData}`,
      });
      if (response.success) return response;
    } catch (error) {
      console.log('error in getting cart items', error);
    }
  };
  const addItemToCart = async (itemId,token) => {
    console.log("Token Data:::::123",token)
    const data = {product_id: itemId};
    try {
      const response = await post(END_POINTS.ADD_TO_CART, data, {
        Authorization: `Bearer ${token}`, 
        // Authorization: `Bearer ${getAuthToken}`,
      });

      return response;
    } catch (error) {
      console.log('error in adding item', error);
    }
  };
  const removeItemFromCart = async (itemId,token)=> {
    const data = {product_id: itemId};
    console.log("Token Data::::1234",token,data)
    try {
      const response = await post(END_POINTS.REMOVE_FROM_CART, data, {
        Authorization: `Bearer ${token}`,
      });
      return response;
    } catch (error) {
      console.log('error in adding item', error);
    }
  };
  const getServiceTimeSlots = async () => {
    try {
      const response = await get(END_POINTS.AVAILABLE_SLOTS, {
        Authorization: `Bearer ${getAuthToken}`,
      });
      if (response.success) return response.data;
    } catch (error) {
      console.log('error in getting cart items', error);
    }
  };
  // create order
  const createOrder = async amountInPaise => {
    const data = {amount: amountInPaise};
    try {
      const response = await post(END_POINTS.CREATE_ORDER, data, {
        Authorization: `Bearer ${getAuthToken}`,
      });
      return response;
    } catch (error) {
      console.log('error in adding item', error);
    }
  };
  const sendToRazorPay = async (orderId, amount, email, mobile, name) => {
    const options = {
      description: 'Sooprs',
      image: 'https://sooprs.com/assets/images/sooprs_logo.png',
      currency: 'INR',
      //   key: 'rzp_live_0dVc0pFpUWFAqu',
      key: 'rzp_test_eaw8FUWQWt0bHV',
      amount: amount,
      name: 'Sooprs.com',
      order_id: orderId,
      prefill: {
        email: email,
        contact: mobile,
        name: name,
      },
      theme: {
        color: '#0077FF',
      },
    };

    try {
      const res = await RazorpayCheckout.open(options);
      if (res?.razorpay_payment_id) {
        return res;
      }
    } catch (error) {
      Toast.show({
        type: 'error',
        text1: 'Payment Error',
        text2: 'Payment has been cancelled',
      });
    }
  };
  const verifyOrder = async data => {
    try {
      const response = await post(END_POINTS.VERIFY_ORDER, data, {
        Authorization: `Bearer ${getAuthToken}`,
      });
      if (response.success) return response;
      throw new Error('Error in payment verifcation.');
    } catch (error) {
      Toast.show({
        type: 'error',
        text1: 'Payment Error',
        text2:
          'If any amount has been debited. Please contact to our support team.',
      });
    }
  };
  const placeOrder = async data => {
    try {
      const response = await post(END_POINTS.PLACE_ORDER, data, {
        Authorization: `Bearer ${getAuthToken}`,
      });
      if (response.success) return response;
      throw new Error('Error in payment verifcation.');
    } catch (error) {
      Toast.show({
        type: 'error',
        text1: 'Error in placing order.',
        text2:
          'If any amount has been debited. Please contact to our support team.',
      });
    }
  };
  const clearCart = async () => {
    try {
      const response = await get(END_POINTS.CLEAR_CART, {
        Authorization: `Bearer ${getAuthToken}`,
      });
      if (response.success) return response;
      throw new Error('Something went wrong.');
    } catch (error) {
      Toast.show({
        type: 'error',
        text1: 'Something went wrong.',
      });
    }
  };
  const getAllOders = async (token) => {
    try {
      const response = await get(END_POINTS.GET_ORDERS, {
        Authorization: `Bearer ${token}`,
      });
      if (response.success) return response;
      throw new Error('Something went wrong.');
    } catch (error) {
      Toast.show({
        type: 'error',
        text1: 'Something went wrong.',
      });
    }
  };
  return {
    getCartItems,
    addItemToCart,
    removeItemFromCart,
    getServiceTimeSlots,
    createOrder,
    sendToRazorPay,
    verifyOrder,
    placeOrder,
    clearCart,
    getAllOders,
  };
};
