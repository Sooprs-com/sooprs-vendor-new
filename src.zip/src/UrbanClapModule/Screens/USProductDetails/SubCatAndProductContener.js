import { FlatList, Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React, { useState } from 'react';
import { hp, wp } from '../../../assets/commonCSS/GlobalCSS';
import FSize from '../../../assets/commonCSS/FSize';
import ProductDetailsModal from './ProductDetailsModal/ProductDetailsModal';
import { useCartApis } from '../UCCart/UCCartHooks';

const SubCatAndProductContener = ({ data,apiCall,token }) => {

  console.log("Sub Cat Data:::",data)
   const {getCartItems, addItemToCart, removeItemFromCart} = useCartApis();
  const [modalVisible, setModalVisible] = useState(false);
  const [productId, setProductId] = useState(null);

  const openModal = (id) => {
    setProductId(id); // Set selected product ID
    setModalVisible(true);
  };

  const addItems = async itemId => {
    const res = await addItemToCart(itemId,token);
    console.log("Responce Of Add ri cart:::",res)
    if (res?.success)
    {
      apiCall()
    }
      
  };

  return (
    <View>
      <FlatList
        data={data}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => {
          
          return (
            <View
              style={{
                backgroundColor: 'white',
                paddingHorizontal: wp(4),
                marginTop: hp(1),
              }}
            >
              <Text
                style={{
                  color: 'black',
                  fontWeight: '600',
                  fontSize: FSize.fs22,
                  paddingVertical: hp(3),
                }}
              >
                {item?.name}
              </Text>
              <View
                style={{
                  backgroundColor: '#999999',
                  width: '100%',
                  height: hp(20),
                  borderRadius: hp(1),
                  overflow:"hidden"
                }}
              >
                <Image
                  source={{ uri: 'http://sooprs.com:3004' + item?.image }}
                  style={{
                    height: '100%',
                    width: '100%',
                    resizeMode: "cover",
                  }}
                />
              </View>

              {/* Product Container */}
              <FlatList
                data={item?.products}
                keyExtractor={(item) => item.id}
                renderItem={({item,index}) => {
                  console.log("Product Data:::",item,index)
                  return (
                    <View>
                      <View
                        style={{
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                          marginTop: hp(2),
                          alignItems: 'center',
                          paddingBottom: hp(3),
                        }}
                      >
                        <View style={{ gap: wp(2) }}>
                          <Text
                            style={{
                              fontSize: FSize.fs18,
                              fontWeight: '600',
                              color: 'black',
                            }}
                          >
                            {item?.title}
                          </Text>
                          <View style={{ flexDirection: 'row', gap: wp(3) }}>
                            <Text
                              style={{
                                fontSize: FSize.fs16,
                                fontWeight: '400',
                                color: 'black',
                              }}
                            >
                              ₹{item?.price}{' '}
                            </Text>
                            {/* <Text
                              style={{
                                fontSize: FSize.fs16,
                                fontWeight: '300',
                                color: 'rgba(158, 158, 158, 1)',
                                textDecorationLine: 'line-through',
                              }}
                            >
                              ₹1,797
                            </Text> */}
                            <View
                              style={{
                                flexDirection: 'row',
                                alignItems: 'center',
                                justifyContent: 'center',
                              }}
                            >
                              {/* <Text
                                style={{
                                  fontSize: FSize.fs16,
                                  fontWeight: '400',
                                  color: 'rgba(158, 158, 158, 1)',
                                }}
                              >
                                2 hrs 15 mins
                              </Text> */}
                            </View>
                          </View>

                          {/* View Details Button */}
                          <TouchableOpacity onPress={() => openModal(item?.id)}>
                            <Text
                              style={{
                                fontSize: FSize.fs19,
                                fontWeight: '600',
                                color: 'rgba(0, 104, 255, 1)',
                              }}
                            >
                              View details
                            </Text>
                          </TouchableOpacity>
                        </View>

                        {/* Product Image */}
                        <View
                          style={{
                            backgroundColor: '#999999',
                            width: wp(25),
                            height: hp(12),
                            borderRadius: hp(1),
                            overflow:"hidden"
                          }}
                        >
                          <Image
                            source={{ uri: 'http://sooprs.com:3004' + item?.image }}
                            style={{
                              height: '100%',
                              width: '100%',
                              resizeMode: "cover",
                            }}
                          />
                        </View>

                        {/* Add Button */}

                      {item?.inCart===false? 
                        <TouchableOpacity
                        onPress={()=>{addItems(item.id)}}
                          style={{
                            backgroundColor: 'white',
                            width: wp(22),
                            height: hp(5),
                            borderRadius: hp(1),
                            position: 'absolute',
                            right: wp(1.5),
                            top: hp(9),
                            justifyContent: 'center',
                            alignItems: 'center',
                            borderWidth:hp(.1),
                            borderColor:"#999999"
                            // elevation: 0.5,
                          }}
                        >
                          <Text
                            style={{
                              color: 'rgba(0, 104, 255, 1)',
                              fontSize: FSize.fs17,
                              fontWeight: '500',
                            }}
                          >
                            Add
                          </Text>
                        </TouchableOpacity>
                         : 
                         <View
                           style={{
                             backgroundColor: 'white',
                             width: wp(22),
                             height: hp(5),
                             borderRadius: hp(1),
                             position: 'absolute',
                             right: wp(1.5),
                             top: hp(9),
                             justifyContent: 'center',
                             alignItems: 'center',
                              borderWidth:hp(.1),
                            borderColor:"#999999"
                            //  elevation: 0.5,
                           }}
                         >
                           <Text
                             style={{
                               color: 'rgba(0, 104, 255, 1)',
                               fontSize: FSize.fs17,
                               fontWeight: '500',
                             }}
                           >
                             {"Added"}
                           </Text>
                         </View>
                         } 

                      </View>


                      {/* Divider */}
                      <View
                        style={{
                          backgroundColor: '#999999',
                          height: hp(0.1),
                          width: '100%',
                        }}
                      />
                    </View>
                  );
                }}
              />
            </View>
          );
        }}
      />

      {/* Product Image Modal - Rendered Once */}
      {modalVisible && (
        <ProductDetailsModal
          modalVisible={modalVisible}
          setModalVisible={setModalVisible}
          productId={productId} // Correctly pass the selected productId
        />
      )}
    </View>
  );
};

export default SubCatAndProductContener;

const styles = StyleSheet.create({});
