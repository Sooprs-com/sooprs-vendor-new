import {
  FlatList,
  Image,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import Images from '../../../../assets/image';
import {hp, wp} from '../../../../assets/commonCSS/GlobalCSS';
import UCIcons from '../../../Utilities/UCIcons';
import FSize from '../../../../assets/commonCSS/FSize';
import ListViewContener from './ListViewContener';
import StepViewContener from './StepViewContener';
import {get, getTokenData} from '../../../Utilities/Apis';
import FAQ from './FAQ';
import {useCartApis} from '../../UCCart/UCCartHooks';
import OnlyImageContener from './OnlyImageContener';
import OnlyDiscriptionContener from './OnlyDiscriptionContener';
import {END_POINTS} from '../../../Utilities/ApiKeys';
import {useSelector} from 'react-redux';
import { getDataFromAsyncStorage } from '../../../../services/CommonFunction';
import { mobile_siteConfig } from '../../../../services/mobile-siteConfig';

const ProductDetailsModal = ({modalVisible, setModalVisible, productId}) => {
  const {getCartItems, addItemToCart, removeItemFromCart} = useCartApis();
  // const getAuthToken = useSelector(state => state?.getAuthToken);
  const [productData, setProductData] = useState();
  const [token,setToken]=useState()
  const getToken=async()=>{
      const token=await getDataFromAsyncStorage(mobile_siteConfig.TOKEN)
      setToken(token)
    }
    useEffect(()=>{
      getToken()
    },[])

  const productDetailsApi = async () => {
    const response = await get(`${END_POINTS.PRODUCT_DETAILS}/${productId}}`, {
      Authorization: `Bearer ${token}`,
    });
    if (response.success) {
      setProductData(response?.data);
    }
  };

  useEffect(()=>{
  console.log("Product Detail::",productData)
  },[productData])

  useEffect(() => {
    productDetailsApi();
  }, [productId,token]);

  const addItems = async itemId => {
    const res = await addItemToCart(itemId,token);
    console.log("Responce Of Add ri cart:::",res)
    if (res?.success === true) {
      productDetailsApi();
    }
    //  getCart();
  };

  return (
    <View>
      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setModalVisible(false)}>
              <Image source={UCIcons.crossIcone} style={styles.closeIcon} />
            </TouchableOpacity>

            {/* Item Container */}
            <ScrollView contentContainerStyle={{paddingBottom: hp(2)}}>
              {/* Top Container */}
              <View style={styles.topContainer}>
                <View style={{gap: wp(2)}}>
                  <Text style={styles.productTitle}>{productData?.title}</Text>
                  <View style={styles.priceContainer}>
                    <Text style={styles.productPrice}>
                      ₹{productData?.price}
                    </Text>
                    {/* <Text style={styles.productOldPrice}>
                      ₹{productData?.price}
                    </Text> */}
                    {/* <Text style={styles.productTime}>2 hrs 15 mins</Text> */}
                  </View>
                </View>
                {/* Button Container */}
                {productData?.inCart === false ? (
                  <TouchableOpacity
                    onPress={() => addItems(productData?.id)}
                    style={styles.addButton}>
                    <Text style={styles.addButtonText}>Add</Text>
                  </TouchableOpacity>
                ) : (
                  <View style={styles.addButton}>
                    <Text style={styles.addButtonText}>{'Added'}</Text>
                  </View>
                )}
              </View>

              {/* List View Container */}
              <FlatList
                // contentContainerStyle={{paddingBottom:hp(5)}}
                data={productData?.descriptions}
                // keyExtractor={(item) => item.id}
                renderItem={({item}) => (
                  <View>
                    {item?.type === 0 && (
                      <View style={styles.listContainer}>
                        <ListViewContener details={item} />
                      </View>
                    )}
                    {item?.type === 1 && (
                      <View style={styles.listContainer}>
                        <StepViewContener details={item} />
                      </View>
                    )}

                    {item?.type === 2 && item?.details.length > 0 && (
                      <View style={styles.listContainer}>
                        <OnlyImageContener data={item} />
                      </View>
                    )}

                    {item?.type === 3 && item?.details.length > 0 && (
                      <View style={styles.listContainer}>
                        <OnlyDiscriptionContener data={item} />
                      </View>
                    )}
                  </View>
                )}
                // contentContainerStyle={{ paddingBottom: hp(10) }}
                // ListFooterComponent={<View style={{ height: hp(10) }} />}
              />

              {/* FAQ Container */}
              <View
                style={{
                  backgroundColor: 'white',
                  paddingVertical: hp(1),
                  paddingHorizontal: wp(4),
                  marginTop: hp(1),
                }}>
                {productData?.faqs.length > 0 && (
                  <FAQ data={productData?.faqs} />
                )}
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
};

export default ProductDetailsModal;

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    width: '100%',
    height: '90%',
    backgroundColor: 'rgba(243, 243, 243, 1)',
    borderRadius: 10,
    marginHorizontal: 10,
  },
  closeButton: {
    position: 'absolute',
    top: hp(-5),
    right: wp(4),
    backgroundColor: 'white',
    borderRadius: hp(5),
  },
  closeIcon: {
    height: hp(4),
    width: wp(8),
    resizeMode: 'contain',
    tintColor: 'black',
  },
  topContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: 'white',
    paddingHorizontal: wp(4),
    paddingTop: hp(4),
    paddingBottom: hp(3),
  },
  productTitle: {
    fontSize: FSize.fs18,
    fontWeight: '600',
    color: 'black',
  },
  priceContainer: {
    flexDirection: 'row',
    gap: wp(3),
  },
  productPrice: {
    fontSize: FSize.fs16,
    fontWeight: '400',
    color: 'black',
  },
  productOldPrice: {
    fontSize: FSize.fs16,
    fontWeight: '300',
    color: 'rgba(158, 158, 158, 1)',
    textDecorationLine: 'line-through',
  },
  productTime: {
    fontSize: FSize.fs16,
    fontWeight: '400',
    color: 'rgba(158, 158, 158, 1)',
  },
  addButton: {
    backgroundColor: 'white',
    width: wp(20),
    height: hp(4.5),
    borderRadius: hp(1),
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: hp(0.1),
    borderColor: '#999999',
  },
  addButtonText: {
    color: 'rgba(0, 104, 255, 1)',
    fontSize: FSize.fs17,
    fontWeight: '500',
  },
  listContainer: {
    backgroundColor: 'white',
    paddingHorizontal: wp(4),
    marginTop: hp(1),
    paddingVertical: hp(2),
  },
});
