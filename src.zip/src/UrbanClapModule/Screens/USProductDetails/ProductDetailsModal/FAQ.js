import { FlatList, Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React, { useState } from 'react'
import Images from '../../../../assets/image';
import { hp, wp } from '../../../../assets/commonCSS/GlobalCSS';
import FSize from '../../../../assets/commonCSS/FSize';

const QuestionContainer = ({ item, title, isDropDownVisible, toggleDropdown,isBulletPoint }) => {
  const lines = item.split("\n");
  return (
    <TouchableOpacity onPress={toggleDropdown} style={styles.container}>
      <View style={styles.questionContainer}>
        <Text style={styles.questionText}>{title}</Text>
        <TouchableOpacity onPress={toggleDropdown}>
          <Image
            source={Images.downArrowLight}
            style={[styles.icon, { transform: [{ rotate: isDropDownVisible ? "180deg" : "0deg" }] }]}
          />
        </TouchableOpacity>
      </View>
      {/* {isDropDownVisible && <Text style={styles.item}>{item}</Text>} */}
      {isDropDownVisible && (
        <Text style={styles.item}>
          {lines[0]} {/* Display the first line normally */}

          {isBulletPoint &&
            lines.slice(1).map((line, index) => (
              <Text key={index}>{"\n"}• {line}</Text> // Bullet points from second line
            ))}

          {/* If bullet points are not needed, display the remaining lines without bullets */}
          {!isBulletPoint &&
            lines.slice(1).map((line, index) => (
              <Text key={index}>{"\n"}{line}</Text>
            ))}
        </Text>
      )}
        
    </TouchableOpacity>
  );
};

const FAQ = ({data}) => {
    console.log("FAQ Data:::",data)
     const [visibleDropdowns, setVisibleDropdowns] = useState({});
    const toggleDropdown = (index) => {
        setVisibleDropdowns((prev) => ({
          ...prev,
          [index]: !prev[index],
        }));
      };


  return (
    <View>
      <Text style={{
        color:"black",
        fontSize:FSize.fs20,
        fontWeight:"500"
      }}>Frequently asked questions</Text>
      <View>
        {/* Question */}
         <FlatList
                data={data}
                // keyExtractor={(item) => item.id}
                renderItem={({ item, index }) => (
                  <QuestionContainer
                    title={item.question}
                    item={item.answer}
                    isDropDownVisible={visibleDropdowns[index]}
                    toggleDropdown={() => toggleDropdown(index)}
                  />
                )}
              />
      </View>
    </View>
  )
}

export default FAQ

const styles = StyleSheet.create({
     container: {
        backgroundColor: "white",
        width: "100%",
      },
      questionContainer: {
        backgroundColor: "white",
        width: "100%",
        marginTop: hp(1),
        borderRadius: hp(2),
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        paddingHorizontal: hp(2),
        paddingVertical: hp(2),
      },
      questionText: {
        color: "#000",
        fontSize: FSize.fs16,
        fontWeight: "bold",
        flex: 1,
      },
      icon: {
        height: hp(2),
        width: hp(2),
      },
      item: {
        fontSize: FSize.fs15,
        color: "black",
        lineHeight: 22,
        paddingHorizontal: wp(3),
        marginVertical: 2,
      },
})