import {FlatList, Image, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {hp, wp} from '../../../../assets/commonCSS/GlobalCSS';
import FSize from '../../../../assets/commonCSS/FSize';

const StepViewContener = ({details}) => {
  return (
    <View>
      <Text
        style={{
          fontSize: FSize.fs19,
          fontWeight: '600',
          color: 'black',
        }}>
        {details?.heading}
      </Text>
      <View
        style={{
          marginTop: hp(2),
          gap: wp(2),
        }}>
        <FlatList
          data={details?.details}
          keyExtractor={item => item.toString()}
          renderItem={({item, index}) => {
            return (
              <View style={{marginBottom: hp(2)}}>
                <Text
                  style={{
                    color: 'black',
                    fontSize: FSize.fs19,
                    fontWeight: '500',
                  }}>
                  {index + 1}. {item?.title}
                </Text>
                <Text
                  style={{
                    color: 'rgba(122, 122, 122, 1)',
                    fontSize: FSize.fs18,
                    fontWeight: '400',
                    marginTop: hp(0.5),
                  }}>
                  {item?.desc}
                </Text>
                {/* Image Contener */}

                {item?.image!="" &&
                <View
                  style={{
                    backgroundColor: '#999999',
                    width: '100%',
                    height: hp(25),
                    borderRadius: hp(1),
                  }}>
                  <Image
                    source={{uri: `http://sooprs.com:3004${item?.image}`}}
                    style={{
                      height: '100%',
                      width: '100%',
                      resizeMode: 'contain',
                    }}
                  />
                </View>
          }
              </View>
            );
          }}
        />
      </View>
    </View>
  );
};

export default StepViewContener;

const styles = StyleSheet.create({});
