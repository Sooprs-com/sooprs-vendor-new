import { FlatList, Image, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { hp, wp } from '../../../../assets/commonCSS/GlobalCSS'
import FSize from '../../../../assets/commonCSS/FSize'
import UCIcons from '../../../Utilities/UCIcons'

const ListViewContener = ({details}) => {
  console.log("Details of data::::",details)
  return (
    <View>
        <Text style={{
        fontSize:FSize.fs20,
        fontWeight:"600",
        color:"black",
        marginBottom:hp(1.5)
        }}>{details?.heading}</Text>

    <FlatList 
    data={details?.details}
    keyExtractor={(item)=>item.toString()}
    renderItem={({item})=>{
      console.log("list Details detals",item)
     return(
        <View style={{
            flexDirection:"row",
            alignItems:"center",
            gap:wp(2),
            marginTop:hp(1.5),
            marginRight:wp(4)
    
        }}>
          <View style={{
            // backgroundColor:"#999999",
            width:wp(6),
            height:hp(3),
            borderRadius:hp(12)
    
          }}>
            {/* Image Contener */}
        {item?.title!="" &&  
        <Image source={UCIcons.checkIcone} 
            style={{ 
                height:"100%",
                width:"100%",
                resizeMode:"contain"
            }}/>
          }  
    
          </View>
    
          <Text style={{
            fontSize:FSize.fs17,
            fontWeight:"400",
            color:"black",
          }}>{item?.title}</Text>
    
          </View>
     )
    }}
    />

       
    </View>
  )
}

export default ListViewContener

const styles = StyleSheet.create({})