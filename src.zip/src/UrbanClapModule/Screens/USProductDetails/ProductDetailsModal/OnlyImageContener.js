import { FlatList, Image, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { hp } from '../../../../assets/commonCSS/GlobalCSS'

const OnlyImageContener = ({data}) => {
    console.log("Only Image Data Contner:::",data)
  return (
    <View>

        <FlatList data={data?.details}
        keyExtractor={(item)=>item.toString()}
        renderItem={({item})=>{
            console.log("item OF data::",item)
            return(
                <View
                style={{
                  backgroundColor: '#999999',
                  width: '100%',
                  height: hp(25),
                  borderRadius: hp(1),
                  overflow:'hidden'
                }}>
                <Image
                  source={{uri: `http://sooprs.com:3004${item?.image}`}}
                  style={{
                    height: '100%',
                    width: '100%',
                    resizeMode: "cover",
                  }}
                />
              </View>

            )
        }}
        />
 
                    
    </View>
  )
}

export default OnlyImageContener

const styles = StyleSheet.create({})