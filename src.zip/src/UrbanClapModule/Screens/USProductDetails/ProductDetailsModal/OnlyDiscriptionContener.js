import {FlatList, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import FSize from '../../../../assets/commonCSS/FSize';
import {hp} from '../../../../assets/commonCSS/GlobalCSS';

const OnlyDiscriptionContener = ({data}) => {
  return (
    <View>
        <FlatList
        data={data?.details}
        keyExtractor={(item)=>item.toString()}
        renderItem={({item})=>{
            return(
                <Text
        style={{
          color: 'rgba(122, 122, 122, 1)',
          fontSize: FSize.fs18,
          fontWeight: '400',
          marginTop: hp(0.5),
        }}>
        {item?.desc}
      </Text>
            )
        }}
        />
     
    </View>
  );
};

export default OnlyDiscriptionContener;

const styles = StyleSheet.create({});
