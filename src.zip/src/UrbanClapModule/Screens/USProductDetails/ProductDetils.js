import {
  FlatList,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import UCIcons from '../../Utilities/UCIcons';
import {hp, wp} from '../../../assets/commonCSS/GlobalCSS';
import FSize from '../../../assets/commonCSS/FSize';
import UCHeaderComponent from '../../Components/UCHeaderComponent';
import SubCategoryCard from './SubCategoryCard';
import SubCatAndProductContener from './SubCatAndProductContener';
import {get, getTokenData} from '../../Utilities/Apis';
import {getDataFromAsyncStorage} from '../../../services/CommonFunction';
import {mobile_siteConfig} from '../../../services/mobile-siteConfig';
import {getDataWithToken} from '../../../services/mobile-api';
import ProductDetailsModal from './ProductDetailsModal/ProductDetailsModal';
import {END_POINTS} from '../../Utilities/ApiKeys';
import {useSelector} from 'react-redux';

const ProductDetils = ({route, naigation}) => {
  const [token, setToken] = useState();
  const [subCatData, setSubCatData] = useState([]);
  const {itemId, itemName} = route.params;
  
  const getToken=async()=>{
    const token=await getDataFromAsyncStorage(mobile_siteConfig.TOKEN)
    setToken(token)
  }

  useEffect(()=>{
    getToken()
  },[])

  // const getAuthToken = useSelector(state => state?.getAuthToken);
  // console.log("User Token:::",getAuthToken)
  const getSubCatApi = async () => {
    console.log("Step 1:::")
    const response = await get(`${END_POINTS.PRODUCT_SUB_CAT}/${itemId}`,{
      Authorization: `Bearer ${token}`,
    });
    console.log("Valid Data:::",response)
    if (response?.success) setSubCatData(response.data.subSubCategories);
  };
  useEffect(() => {
    getSubCatApi();
  }, [token]);

  return (
    <View>
      {/* Header Component */}
      <UCHeaderComponent header={itemName} />

      {/* Top Contener */}
      <ScrollView
        nestedScrollEnabled={true}
        contentContainerStyle={{paddingBottom: hp(20)}}>
        <View
          style={{
            backgroundColor: 'white',
            paddingHorizontal: wp(4),
            paddingVertical: hp(3),
            paddingBottom: hp(6),
          }}>
          <Text
            style={{color: 'black', fontWeight: '600', fontSize: FSize.fs24}}>
            {itemName}
          </Text>
        </View>

        {/* SubCategory Contener */}
        <SubCategoryCard data={subCatData} />

        {/* Sub Category  And Product Contener */}

        <SubCatAndProductContener data={subCatData} apiCall={getSubCatApi} token={token}/>

        {/* Product Details Modal */}
      </ScrollView>
    </View>
  );
};

export default ProductDetils;

const styles = StyleSheet.create({});
