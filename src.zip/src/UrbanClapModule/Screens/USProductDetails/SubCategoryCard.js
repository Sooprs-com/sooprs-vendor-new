import { FlatList, Image, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { hp, wp } from '../../../assets/commonCSS/GlobalCSS'

const SubCategoryCard = ({data}) =>{
  return (
    <View style={{backgroundColor:"white",
        width:"100%",
        paddingVertical:hp(2.5),
        marginTop:hp(1),
        // alignItems:"center",
        // alignItems:"center",
        justifyContent:"center",
        paddingHorizontal:wp(4),
    }}>
    
    <FlatList 
    data={data}
    horizontal
    showsHorizontalScrollIndicator={false}
    keyExtractor={(item,index)=>index.toString()}
    renderItem={({item})=>{
      // console.log("Sub Car Data:::",item)
        return(
            <View style={{width:wp(25),marginRight:wp(4)}}>
            <View style={{backgroundColor:"#999999",
                width:wp(25),
                height:hp(12),
                borderRadius:hp(2),
                overflow:"hidden"
            }}>
                
              {/* Image Area */}
              <Image source={{uri:"http://sooprs.com:3004"+item?.image}} style={{ 
                height:"100%",
                width:"100%",
                resizeMode:"cover"
              }}/>
            </View>
             <Text style={{textAlign:"center",color:"#999999"}}>{item?.name}</Text>
            </View>
        )
    }}
    />
    
</View>
  )
}

export default SubCategoryCard

const styles = StyleSheet.create({})