import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import UCIcons from '../../Utilities/UCIcons';
import { wp } from '../../../assets/commonCSS/GlobalCSS';
import Colors from '../../../assets/commonCSS/Colors';
import FSize from '../../../assets/commonCSS/FSize';

const AddressComponent = ({item,handleSelection}) => {
  return (
    <View>
      <TouchableOpacity
        style={styles.placeContainer}
        activeOpacity={0.7}
        onPress={() => handleSelection(item.description)}>
        <Image source={UCIcons.pin} style={styles.pin} />
        <View>
          <Text style={styles.t1}>
            {item?.structured_formatting?.main_text}
          </Text>
          <Text style={styles.t2}>{item.description}</Text>
        </View>
      </TouchableOpacity>
      <View style={styles.border} />
    </View>
  );
};

export default AddressComponent;

const styles = StyleSheet.create({
    border: {
        height: 0,
        borderTopWidth: 1,
        width: wp(90),
        borderColor: Colors.lightGrey,
        marginVertical: 10,
      },
      t1: {
        color: Colors.black,
        fontWeight: '500',
        fontSize: FSize.fs16,
        marginBottom: 3,
      },
      t2: {
        color: Colors.gray,
        fontWeight: '400',
        fontSize: FSize.fs14,
        width: wp(85),
      },
      pin: {
        height: 20,
        width: 20,
        marginRight: 10,
        alignSelf: 'center',
      },
      placeContainer: {
        flexDirection: 'row',
        alignContent: 'center',
      },
});
