import {StatusBar, StyleSheet, Text, View} from 'react-native';
import React, {useEffect, useState} from 'react';
import {useHomeApis} from './UCHomeHooks';
import UCHomeHeader from './UCHomeHeader';
import Colors from '../../../assets/commonCSS/Colors';
import {useDispatch, useSelector} from 'react-redux';
import {setUserAddress} from '../../../Redux/Actions';
import AnimatedSearchBar from '../../Components/AnimatedSearchBar';
import Sections from './Sections';
import { mobile_siteConfig } from '../../../services/mobile-siteConfig';
import { getDataFromAsyncStorage } from '../../../services/CommonFunction';

const UCHome = ({navigation}) => {
  const {getLocation, locationLoading, getCategories,} = useHomeApis();
  // console.log("Token Data:::",token)
  const [dailyEssentials, setDailyEssentials] = useState([]);
  const [token,setToken]=useState()
  const dispatch = useDispatch();
  const getUserAddress = useSelector(state => state?.getUserAddress);

  const getToken=async()=>{
      const token=await getDataFromAsyncStorage(mobile_siteConfig.TOKEN)
      setToken(token)
    }
  
    useEffect(()=>{
      getToken()
    },[])

  useEffect(() => {
    getUsersLocation();
    getBussinessCategories(token);
  },[token]);
  const getUsersLocation = async () => {
    if (getUserAddress) return;
    const address = await getLocation();
    dispatch(setUserAddress(address?.address));
  };
  const getBussinessCategories = async (tokenData) => {
    const categories = await getCategories(tokenData);
    setDailyEssentials(categories);
    console.log(categories);
  };
  const data = [
    {
      title: 'Daily Essentials',
      data: dailyEssentials,
    },
    {
      title: 'Bussiness',
      data: [
        {
          id: 1,
          image: '/uploads/technical-support.png',
          name: 'IT & Tech',
          slug: 'electrician',
          status: 1,
          subcategories: [],
        },
        {
          id: 1,
          image: '/uploads/travel.png',
          name: 'Packers',
          slug: 'electrician',
          status: 1,
          subcategories: [],
        },
        {
          id: 1,
          image: '/uploads/event.png',
          name: 'Event',
          slug: 'electrician',
          status: 1,
          subcategories: [],
        },
        {
          id: 1,
          image: '/uploads/travel.png',
          name: 'Travel',
          slug: 'electrician',
          status: 1,
          subcategories: [],
        },
      ],
    },
  ];

  
  return (
    <View style={styles.container}>
      <StatusBar backgroundColor={Colors.white} barStyle={'dark-content'} />
      <UCHomeHeader fullAdress={getUserAddress} navigation={navigation} />

      <AnimatedSearchBar />
      <Sections data={data} navigation={navigation} />
    </View>
  );
};

export default UCHome;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
});
