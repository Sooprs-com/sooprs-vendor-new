import React, {useCallback, useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  FlatList,
  TouchableOpacity,
  Image,
  Dimensions,
} from 'react-native';
import Colors from '../../../assets/commonCSS/Colors';
import {IMAGES_BASEURL} from '../../Utilities/ApiKeys';
import {hp, wp} from '../../../assets/commonCSS/GlobalCSS';
import BottomSheet from '../../Components/BottomSheet';
import {useSharedValue} from 'react-native-reanimated';
import UCIcons from '../../Utilities/UCIcons';

const screenWidth = Dimensions.get('window').width;
const numColumns = 4;
const itemSize = (screenWidth - 10 - (numColumns - 1) * 2.5) / numColumns;

const SectionGrid = ({data = [], navigation}) => {
  const isOpen = useSharedValue(false);
  const [services, setServices] = useState([]);

  const toggleBottomSheet = useCallback(() => {
    isOpen.value = !isOpen.value;
  }, [isOpen]);

  const renderInnerItem = useCallback(
    ({item}) => (
      <TouchableOpacity
        style={styles.itemWrapper}
        onPress={() => {
          if (item.name == 'IT & Tech') {
            navigation.navigate('ClientBottomTab');
          }
          if (item.subcategories && item.subcategories.length > 0) {
            setServices(item.subcategories);
            setTimeout(() => {
              toggleBottomSheet();
            }, 100);
          } 
        }}>
        <View style={styles.itemContainer}>
          <Image
            source={{uri: IMAGES_BASEURL + item.image}}
            style={styles.image}
          />
        </View>
        <Text style={styles.itemText} numberOfLines={2}>
          {item.name}
        </Text>
      </TouchableOpacity>
    ),
    [toggleBottomSheet],
  );

  const renderSection = useCallback(
    ({item: section}) => (
      <View>
        <Text style={styles.header}>{section.title}</Text>
        <View style={styles.sectionContainer}>
          <FlatList
            data={section.data}
            numColumns={numColumns}
            scrollEnabled={false}
            keyExtractor={(item, index) =>
              item.id?.toString() || index.toString()
            }
            renderItem={renderInnerItem}
          />
        </View>
      </View>
    ),
    [renderInnerItem],
  );
  // handle navigation
  const handleNavigation = item => {
    navigation.navigate('UrbanClapStack', {
      screen: 'Products',
      params: {
        itemId: item.id,
        itemName: item.name,
      },
    });
  };
  const renderBottomSheetItem = useCallback(
    ({item}) => (
      <TouchableOpacity
        style={styles.itemWrapper}
        onPress={() => handleNavigation(item)}
        >
        <View style={styles.itemContainer}>
          <Image
            source={{uri: IMAGES_BASEURL + item.image}}
            style={styles.image}
          />
        </View>
        <Text style={styles.itemText} numberOfLines={2}>
          {item.name}
        </Text>
      </TouchableOpacity>
    ),
    [toggleBottomSheet],
  );

  return (
    <>
      <FlatList
        data={data}
        keyExtractor={(section, index) => section.title + index}
        renderItem={renderSection}
        showsVerticalScrollIndicator={false}
        ListFooterComponent={() => {
          return (
            <View style={{height: hp(18), width: wp(90), alignSelf: 'center'}}>
              <Image
                source={UCIcons.banner}
                resizeMode="contain"
                style={{height: '100%', width: '100%'}}
              />
            </View>
          );
        }}
      />

      <BottomSheet isOpen={isOpen} toggleSheet={toggleBottomSheet}>
        <View style={{flex: 1}}>
          <FlatList
            data={services}
            numColumns={numColumns}
            keyExtractor={(item, index) =>
              item.id?.toString() || index.toString()
            }
            initialNumToRender={services.length} // Prevents flickering
            scrollEnabled={false}
            renderItem={renderBottomSheetItem}
          />
        </View>
      </BottomSheet>
    </>
  );
};

export default SectionGrid;

const styles = StyleSheet.create({
  sectionContainer: {marginHorizontal: 8},
  header: {
    fontSize: 18,
    fontWeight: 'bold',
    backgroundColor: Colors.lightgrey1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    color: Colors.black,
    borderRadius: 6,
    marginVertical: 12,
    width: wp(90),
    alignSelf: 'center',
  },
  itemWrapper: {
    width: itemSize,
    alignItems: 'center',
    marginBottom: 12,
  },
  itemContainer: {
    width: itemSize * 0.8,
    height: itemSize * 0.8,
    backgroundColor: Colors.sooprslight,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    padding: 8,
  },
  image: {
    height: '50%',
    width: '50%',
    resizeMode: 'contain',
  },
  itemText: {
    fontSize: 14,
    color: Colors.black,
    textAlign: 'center',
    marginTop: 5,
    paddingHorizontal: 4,
  },
});
