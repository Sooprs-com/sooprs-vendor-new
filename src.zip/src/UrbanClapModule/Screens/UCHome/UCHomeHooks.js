import {useState} from 'react';
import {BASE_URL, get, post} from '../../Utilities/Apis';
import {END_POINTS, GOOGLE_API_KEY} from '../../Utilities/ApiKeys';
import {requestLocationPermission} from '../../Utilities/Permissions';
import {useSelector} from 'react-redux';

export const useHomeApis = () => {
  const [locationLoading, setLocationLoading] = useState(false);
  const [location, setLocation] = useState(null);
  const [error, setError] = useState(null);
  // const getAuthToken = useSelector(state => state?.getAuthToken);
  const getAuthToken=  "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NDE1OTUyNjgsImV4cCI6MTc0MjgwNDg2OCwiZGF0YSI6eyJ1c2VyX2lkIjoiMjQ3NCIsImVtYWlsIjoianNuaWtoaWwwMEBnbWFpbC5jb20ifX0.Xu6PEr5jZIHGU3LJMTJsRLhwK6dPdkeTyJKrzn_JiO0"
  console.log('getD', getAuthToken);
  const getLocation = async () => {
    setLocationLoading(true);
    setError(null);
    try {
      const permission = await requestLocationPermission();
      if (!permission) {
        await requestLocationPermission();
      }
      // Get current coordinates using Google's Geolocation API
      const coordsUrl = `https://www.googleapis.com/geolocation/v1/geolocate?key=${GOOGLE_API_KEY}`;
      const currentCoords = await post(coordsUrl);
      if (!currentCoords?.location) {
        throw new Error('Unable to retrieve coordinates from Geolocation API');
      }
      const {lat, lng} = currentCoords.location;
      // get location
      const locationStringUrl = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${GOOGLE_API_KEY}`;
      const currentLocation = await get(locationStringUrl);
      // Extract a formatted address from the first result, if available
      const address =
        currentLocation?.results && currentLocation.results.length > 0
          ? currentLocation.results[0].formatted_address
          : null;
      // Update state with coordinates and address
      return {address};
    } catch (err) {
      console.error('Error fetching location:', err);
      setError(err?.response || err);
    } finally {
      setLocationLoading(false);
    }
  };
  // api to autocomplete the locations
  const getPlaces = async query => {
    const url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodeURIComponent(
      query,
    )}&key=${GOOGLE_API_KEY}`;
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Network error: ${response.statusText}`);
      }
      const data = await response.json();
      if (data.status !== 'OK') {
        throw new Error(`API error: ${data.error_message || data.status}`);
      }
      return data.predictions;
    } catch (error) {
      console.error('Error fetching places:', error);
      throw error;
    }
  };
  // debounce function
  const debounce = (func, delay) => {
    let timer;
    const debounced = (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => func(...args), delay);
    };
    return debounced;
  };
  // get categories
  const getCategories = async (token) => {
    try {
      const response = await get(END_POINTS.BUSSINESS_SERVICES, {
        Authorization: `Bearer ${token}`,
      });
      if (response.success) {
        return response.data;
      }
    } catch (error) {}
  };
  return {
    getLocation,
    locationLoading,
    location,
    debounce,
    error,
    getPlaces,
    getCategories,
  };
};
