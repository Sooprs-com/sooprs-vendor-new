import React, {useState, useCallback} from 'react';
import {
  FlatList,
  Image,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {TextInput} from 'react-native-gesture-handler';
import Colors from '../../../assets/commonCSS/Colors';
import Images from '../../../assets/image';
import {useHomeApis} from './UCHomeHooks';
import UCIcons from '../../Utilities/UCIcons';
import FSize from '../../../assets/commonCSS/FSize';
import {wp} from '../../../assets/commonCSS/GlobalCSS';
import {useDispatch, useSelector} from 'react-redux';
import {setUserAddress} from '../../../Redux/Actions';
import AddressComponent from './AddressComponent';

const AddressSelectionScreen = ({navigation}) => {
  const [address, setAddress] = useState('');
  const {debounce, getPlaces, getLocation} = useHomeApis();
  const [places, setPlaces] = useState([]);
  const getUserAddress = useSelector(state => state?.getUserAddress);
  const dispatch = useDispatch();
  const fetchPlaces = async txt => {
    try {
      const places = await getPlaces(txt);
      setPlaces(places);
    } catch (error) {
      console.error('error while getting the location', error);
    }
  };

  const debouncedFetchPlaces = useCallback(
    debounce(text => {
      fetchPlaces(text);
    }, 2000),
    [debounce],
  );
  const handleChangeText = text => {
    setAddress(text);
    if (text.length < 2) {
      setPlaces([]);
      return;
    }
    debouncedFetchPlaces(text);
  };
  const handleSelection = add => {
    setAddress(add);
    dispatch(setUserAddress(add));
    navigation.goBack();
  };
  const getUsersLocation = async () => {
    const address = await getLocation();
    setAddress(address.address);
    dispatch(setUserAddress(address.address));
    navigation.goBack();
  };
  return (
    <View style={styles.container}>
      <StatusBar backgroundColor={Colors.white} barStyle={'dark-content'} />
      <View style={styles.inputContainer}>
        <TouchableOpacity
          activeOpacity={0.7}
          onPress={() => navigation.goBack()}>
          <Image source={Images.backArrow} style={{height: 25, width: 25}} />
        </TouchableOpacity>
        <TextInput
          value={address}
          onChangeText={handleChangeText}
          placeholder="search for your location/society."
          placeholderTextColor={Colors.grey}
          textAlign="left"
          style={{color: Colors.black}}
        />
      </View>
      <TouchableOpacity
        style={{flexDirection: 'row', marginTop: 10}}
        activeOpacity={0.7}
        onPress={getUsersLocation}>
        <Image
          source={UCIcons.currentLocation}
          style={{height: 22, width: 22}}
          tintColor={Colors.sooprsblue}
        />
        <Text style={styles.t3}>Use current location</Text>
      </TouchableOpacity>
      <View style={styles.border} />
      {places.length < 1 && getUserAddress && (
        <View>
          <Text style={styles.t5}>Saved Address</Text>
          <View style={{flexDirection: 'row', marginVertical: 10}}>
            <Image
              source={UCIcons.pin}
              style={{height: 22, width: 22, marginRight: 10}}
            />
            <Text style={styles.t4}>{getUserAddress}</Text>
          </View>
          <View style={styles.border} />
        </View>
      )}

      <FlatList
        data={places}
        renderItem={({item, index}) => {
          return (
            <View key={index}>
              <AddressComponent item={item} handleSelection={handleSelection} />
            </View>
          );
        }}
      />
    </View>
  );
};

export default AddressSelectionScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
    padding: 16,
  },
  inputContainer: {
    borderWidth: 1,
    borderColor: Colors.grey,
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 3,
    overflow: 'hidden',
  },
  border: {
    height: 0,
    borderTopWidth: 1,
    width: wp(90),
    borderColor: Colors.lightGrey,
    marginVertical: 10,
  },
  t1: {
    color: Colors.black,
    fontWeight: '500',
    fontSize: FSize.fs16,
    marginBottom: 3,
  },
  t2: {
    color: Colors.gray,
    fontWeight: '400',
    fontSize: FSize.fs14,
    width: wp(85),
  },
  pin: {
    height: 20,
    width: 20,
    marginRight: 10,
    alignSelf: 'center',
  },
  placeContainer: {
    flexDirection: 'row',
    alignContent: 'center',
  },
  t3: {
    color: Colors.sooprsblue,
    fontWeight: '500',
    fontSize: FSize.fs16,
    marginLeft: 8,
  },
  t4: {
    color: Colors.gray,
    fontWeight: '400',
    fontSize: FSize.fs15,
    width: wp(90),
  },
  t5: {
    color: Colors.black,
    fontWeight: '500',
    fontSize: FSize.fs18,
  },
});
