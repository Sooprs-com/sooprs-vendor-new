import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import Colors from '../../../assets/commonCSS/Colors';
import FSize from '../../../assets/commonCSS/FSize';
import Images from '../../../assets/image';
import UCIcons from '../../Utilities/UCIcons';
import { hp } from '../../../assets/commonCSS/GlobalCSS';

const UCHomeHeader = ({fullAdress = '', navigation}) => {
  const shortenAddress = text => {
    return text.length > 35 ? `${text.slice(0, 35)}...` : text;
  };
  const gotoAddressSelection = () => {
    navigation.navigate('UrbanClapStack');
  };
  return (
    <View style={styles.container}>
      <TouchableOpacity
        activeOpacity={0.7}
        onPress={gotoAddressSelection}
        style={{flexDirection: 'row', alignItems: 'flex-end'}}>
        <View>
          <Text style={styles.t1}>Address</Text>
          <Text style={styles.t2}>{shortenAddress(fullAdress)}</Text>
        </View>
        <Image
          source={Images.chevronRight}
          style={{height: 16, width: 16}}
          resizeMode="contain"
          tintColor={Colors.gray}
        />
      </TouchableOpacity>
      <TouchableOpacity style={styles.bellContainer}>
        <Image
          source={UCIcons.notifi}
          style={{height: 18, width: 18}}
          resizeMode="contain"
        />
      </TouchableOpacity>
    </View>
  );
};

export default UCHomeHeader;

const styles = StyleSheet.create({
  container: {
    width: '100%',
    paddingTop:hp(7),
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  t1: {
    color: Colors.black,
    fontSize: FSize.fs25,
    fontWeight: '500',
  },
  t2: {
    color: Colors.gray,
    fontSize: FSize.fs15,
    fontWeight: '400',
    // width: wp(70),
  },
  bellContainer: {
    borderWidth: 1.5,
    borderColor: Colors.grey,
    borderRadius: 100,
    padding: 6,
  },
});
