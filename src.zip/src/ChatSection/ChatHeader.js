import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import Images from '../assets/image';
import Colors from '../assets/commonCSS/Colors';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
const iconSize = Math.min(wp(10), hp(6));
const ChatHeader = ({navigation, profile, name}) => {
  return (
    <View style={styles.container}>
      <TouchableOpacity style={{}} onPress={() => navigation.goBack()}>
        <Image
          source={Images.backArrow}
          style={styles.backArrow}
          resizeMode="contain"
        />
      </TouchableOpacity>
      <Image
        source={{uri: profile}}
        style={styles.profileImg}
        resizeMode="cover"
        defaultSource={Images.defaultPicIcon}
      />
      <Text style={{color: Colors.black,fontWeight:'500'}}>{name}</Text>
    </View>
  );
};

export default ChatHeader;

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderColor: Colors.lightGrey,
  },
  profileImg: {
    height: iconSize,
    width: iconSize,
    borderRadius: iconSize / 2,
    marginHorizontal: 7,
  },
  backArrow: {height: 35, width: 35},
});
