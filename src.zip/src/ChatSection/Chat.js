import {
  StyleSheet,
  Text,
  TextInput,
  View,
  TouchableOpacity,
  FlatList,
  Image,
  ActivityIndicator,
  Linking,
} from 'react-native';
import React, {useEffect, useRef, useState} from 'react';
import DocumentPicker from 'react-native-document-picker';
import socketServices from './SocketService';
import {useSelector} from 'react-redux';
import Colors from '../assets/commonCSS/Colors';
import {useIsFocused} from '@react-navigation/native';
import ChatHeader from './ChatHeader';
import Images from '../assets/image';
import {hp, wp} from '../assets/commonCSS/GlobalCSS';
import Toast from 'react-native-toast-message';
import ImageViewing from 'react-native-image-viewing';
const sendIconSize = Math.min(wp(10), hp(5));
const Chat = ({navigation, route}) => {
  const isFocused = useIsFocused();
  const {
    gorder_id = '',
    receiver_id = '',
    name = '',
    image = '',
  } = route?.params || {};
  const [messages, setMessages] = useState([]);
  const [message, setMessage] = useState('');
  const getUserId = useSelector(state => state?.getUserId);
  const [loading, setLoading] = useState(true);
  const user_id = getUserId;
  const flatListRef = useRef(null);
  const [isImageViewerVisible, setImageViewerVisible] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);

  const openImageViewer = imageUri => {
    setSelectedImage([{uri: imageUri}]);
    setImageViewerVisible(true);
  };

  useEffect(() => {
    const connectSocket = async () => {
      console.log('⚡ Connecting socket with:', user_id, gorder_id);
      try {
        await socketServices.initializeSocket(user_id, gorder_id);
        socketServices.on('loadMessages', msg => {
          // sorting the messages on id to maintain the state
          setMessages(msg?.sort((a, b) => b.id - a.id));
          setLoading(false);
          // console.log('messages',msg)
          // console.log(msg?.sort((a, b) => b.id - a.id))
        });
      
        socketServices.on('message', data => {
          // sorting the messages on id to maintain the state

          setMessages(prev => {
            const newId = prev[0]?.id ? prev[0]?.id + 1 : 1;
            return [...prev, {...data, id: newId}].sort((a, b) => b.id - a.id);
          });
          if (data.receiver_id === user_id) {
            socketServices.emit('markAsSeen', {gorder_id, user_id});
          }
        });
      } catch (error) {
        console.error('Socket connection failed ❌', error);
      } finally {
        setLoading(false);
      }
    };

    connectSocket();

    return () => {
      socketServices.removeListener('message');
      socketServices.disconnectSocket();
    };
  }, [isFocused]);

  // Send Text Message
  const sendMessage = () => {
    if (!message.trim()) {
      Toast.show({
        type: 'info',
        text1: 'Please write/add someting to send.',
      });
      return;
    }

    socketServices.emit('chatMessage', {
      gorder_id,
      sender_id: user_id,
      receiver_id,
      message,
      type: 0,
    });
    setMessage('');
  };

  // Pick & Send File (Images / PDFs)
  const sendFile = async () => {
    try {
      const res = await DocumentPicker.pick({
        type: [DocumentPicker.types.images, DocumentPicker.types.pdf],
      });

      const fileData = {
        uri: res[0].uri,
        name: res[0].name,
        type: res[0].type,
      };
      uploadMedia(fileData);
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        console.log('User cancelled file selection');
      } else {
        console.error('File selection error:', err);
      }
    }
  };
  //upload Media
  const uploadMedia = async fileData => {
    const payload = new FormData();
    payload.append('reciver_id', receiver_id);
    payload.append('sender_id', getUserId);
    payload.append('gig_order_id', gorder_id);
    payload.append('file', fileData);
    try {
      const res = await fetch(
        'https://sooprs.com/api2/public/index.php/upload-gig-files',
        {
          method: 'POST',
          body: payload,
        },
      );

      const result = await res.json();
      if (result.status == 200) {
        socketServices.emit('chatMessage', {
          gorder_id,
          sender_id: user_id,
          receiver_id,
          message: `https://sooprs.com${result?.data}`,
          type: 1,
        });
      }
    } catch (error) {
      console.error(error);
    }
  };
  // Render Each Message
  const isValidFile = item => {
    return /\.(pdf|docx)$/i.test(item?.message);
  };
  const renderMessage = ({item}) => {
    const isSender = item.sender_id == user_id;

    if (item.type == 1) {
      return (
        <TouchableOpacity
          activeOpacity={0.8}
          onPress={() => {
            if (!isValidFile(item)) {
              openImageViewer(item.message); // Open image when tapped
            } else {
              Linking.openURL(item.message);
            }
          }}
          style={[
            styles.previeContainer,
            isSender ? styles.sender : styles.receiver,
          ]}>
          {isValidFile(item) ? (
            <Image
              source={Images.pdfPreview}
              style={{height: hp(18), width: wp(65)}}
              resizeMode="contain"
            />
          ) : (
            <Image
              source={{uri: item.message}}
              style={{height: hp(18), width: wp(65), borderRadius: 8}}
            />
          )}
        </TouchableOpacity>
      );
    }
    return (
      <View
        style={[
          styles.messageContainer,
          isSender ? styles.sender : styles.receiver,
        ]}>
        <Text style={styles.messageText}>{item.message}</Text>
      </View>
    );
  };
  return (
    <View style={styles.container}>
      <ChatHeader navigation={navigation} name={name} profile={image} />
      {loading ? (
        <ActivityIndicator
          color={Colors.darkblue}
          size={35}
          style={{marginTop: hp(15)}}
        />
      ) : (
        <>
          <FlatList
            ref={flatListRef}
            data={messages}
            keyExtractor={(item, index) => index.toString()}
            renderItem={renderMessage}
            contentContainerStyle={styles.chatContainer}
            inverted
          />

          <View style={styles.inputContainer}>
            <TouchableOpacity onPress={sendFile}>
              <Image
                source={Images.link}
                style={{height: 40, width: 40, marginRight: 10}}
              />
            </TouchableOpacity>
            <TextInput
              style={styles.input}
              placeholder="Type a message..."
              value={message}
              onChangeText={setMessage}
              placeholderTextColor={Colors.gray}
            />
            <TouchableOpacity onPress={sendMessage} style={styles.sendButton}>
              <Image
                source={Images.sendIcon}
                style={{height: sendIconSize, width: sendIconSize}}
              />
            </TouchableOpacity>
          </View>
          {selectedImage && (
            <ImageViewing
              images={selectedImage}
              imageIndex={0}
              visible={isImageViewerVisible}
              onRequestClose={() => setImageViewerVisible(false)}
            />
          )}
        </>
      )}
    </View>
  );
};

export default Chat;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  chatContainer: {
    flexGrow: 1,
    padding: 10,
    justifyContent: 'flex-end',
  },
  messageContainer: {
    maxWidth: '75%',
    padding: 10,
    borderRadius: 10,
    marginVertical: 5,
  },
  sender: {
    backgroundColor: Colors.sooprslight,
    alignSelf: 'flex-end',
  },
  receiver: {
    backgroundColor: '#E5E5EA',
    alignSelf: 'flex-start',
  },
  previeContainer: {
    maxWidth: '75%',
    padding: 4,
    borderRadius: 10,
    marginVertical: 5,
  },
  messageText: {
    fontSize: 16,
    color: '#000',
  },
  image: {
    width: 200,
    height: 200,
    borderRadius: 10,
  },
  pdfText: {
    color: 'blue',
    textDecorationLine: 'underline',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    borderTopWidth: 1,
    borderColor: '#ccc',
  },
  input: {
    flex: 1,
    padding: 10,
    fontSize: 16,
    borderWidth: 1,
    borderRadius: 12,
    borderColor: '#ccc',
    color: Colors.black,
    // marginHorizontal: 10,
  },
  fileButton: {
    padding: 10,
  },
  fileText: {
    fontSize: 22,
  },
  sendButton: {
    padding: 10,
  },
  sendText: {
    fontSize: 22,
    color: '#007AFF',
  },
});
