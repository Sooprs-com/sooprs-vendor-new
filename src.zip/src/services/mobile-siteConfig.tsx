export const mobile_siteConfig = Object.freeze({
  BASE_URL: 'https://sooprs.com/',

  BASE_URL_2:"http://sooprs.com:3004/",

  INDEX: 'api2/public/index.php/',
  FCM_TOKEN: 'fcm_token',
  // REGISTER
  REGISTER: 'customerRegistration',
  CHAT_SOCKET_URL: 'wss://sooprs.com:3000',
  // LOGIN
  LOGIN: 'login-user',
  IS_LOGIN: 'is_login',
  SOCIAL_LOGIN: 'app-google-login',
  UID: 'uid',
  IS_BUYER: 'client',
  PROFILE_PIC: 'profilepic',
  DELIVERED: 'delivered',

  // Token
  TOKEN: 'token',
  fcmToken: 'fcm_token',

  //email

  EMAIL: 'email',

  // name

  NAME: 'name',
  SLUG: 'slug',
  HAS_ADDED_SERVICES: 'hasaddedservices',
  IS_COMPANY: 'iscompany',
  FLAGS: 'flags',
  //notification

  SEEN_NOTIFICATION: 'notification',
  //
  COUNTRY_CODE: 'COUNTRY_CODE',
  //PASSWORD
  PASSWORD: 'password',
  FORGOT_PASSWORD: 'forgetpassword',
  RESET_PASSWORD: 'resetpassword',
  UPDATE_PASSWORD: 'update-password',

  //OTP
  VERIFY_OTP: 'verifyOtp',
  RESENT_OTP: 'resendOtp',

  LEADS: 'get_all_leads',
  CATEGORIES: 'sr_services_new_cat',
  LIVE_SEARCH: 'ajax-live-search',
  // Project
  GET_CATEGORIES: 'sr_services_all',
  GET_TECHNOLOGY: 'sp_skills_all',
  POST_PROJECT: 'save_post_project',
  GET_DESCRIPTION: 'post-project-description',
  GET_PROJECTS: 'get_enquiries_ajax',
  QUERY_DETAIL: 'query_detail',
  ADD_BID: 'add_bid',
  MY_BIDS: 'get_my_leads',
  FILTER_PROF: 'filter_service_ajax',
  GET_SELECTED_CATEGORIES: 'get-selected-services',
  POST_SERVICE_ID: 'addServForm',
  //profile
  USER_DETAILS: 'get-user-details',
  GET_USER_PROFILE: 'get-user-profile',
  UPDATE_PROFILE_PROFESSIONAL: 'update_profile_professional',
  UPLOAD_PICTURE: 'upload_picture',
  GET_CONTACTS: 'get-contact-list',
  VERIFY_ORDER: 'update_wallet',

  // Contect Us Api
  CONTACT_US: 'api2/public/index.php/contactUsQuery',
  CREATE_RAZORPAY_ORDER: 'https://sooprs.com/create_razr_order.php',
  GET_MEMBERSHIP: 'get-membership-plans',
  BUY_MEMBERSHIP: 'buy-membership',
  POST_GIG_REVIEW: 'post-review-for-gig',
  BUY_GIG: 'gig_order',
  GET_GIGS: 'get_all_gigs',
  SOLD_GIGS: 'my-sales-gigs',
  PURCHASED_GIGS: 'my-purchased-gigs',
  GET_FILTERED_PROJECTS: 'filter-leads-all',
  GET_POSTED_PROJECTS_ALL_CRETGORY: 'get-all-categories-full-data',
  SUBMIT_QUERY:'submit-lead-data-response',
});
