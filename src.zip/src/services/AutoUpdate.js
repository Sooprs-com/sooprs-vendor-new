import SpInAppUpdates, {
  IAUUpdateKind,
  IAUInstallStatus,
} from 'sp-react-native-in-app-updates';
import {Platform} from 'react-native';
import DeviceInfo from 'react-native-device-info';

export const checkForUpdate = async () => {
  const getDeviceVersion = DeviceInfo.getVersion();
  const inAppUpdates = new SpInAppUpdates(false);
  try {
    const result = await inAppUpdates.checkNeedsUpdate({
      curVersion: getDeviceVersion,
    });
    if (!result.shouldUpdate) return;

    let updateOptions = {};

    if (Platform.OS === 'android') {
      updateOptions = {updateType: IAUUpdateKind.IMMEDIATE};
    }

    const handleStatusUpdate = downloadStatus => {
      console.log('Download status:', downloadStatus);

      if (downloadStatus.status === IAUInstallStatus.DOWNLOADED) {
        console.log('Update downloaded. Installing...');
        inAppUpdates.installUpdate();
        inAppUpdates.removeStatusUpdateListener(handleStatusUpdate);
      }
    };

    inAppUpdates.addStatusUpdateListener(handleStatusUpdate);
    inAppUpdates.startUpdate(updateOptions);
  } catch (error) {
    console.error('Update check failed:', error);
  }
};
