export const fFamily = {
    ibmLight: 'IBMPlexSans-Light',
  
    ibmMedium: 'IBMPlexSans-Medium',
  
    ibmRegular: 'IBMPlexSans-Regular',
  
    ibmSemiBold: 'IBMPlexSans-SemiBold',
  
    ibmBold: 'IBMPlexSans-Bold',
  };